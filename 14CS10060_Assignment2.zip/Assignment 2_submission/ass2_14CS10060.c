# include "myl.h"
#include<stdio.h>

int prints(char *a)
{
	int i;
	int length=0;
	for(i=0;a[i]!='\0';++i);
	length=i;
	__asm__ __volatile__ (
	"movl $1, %%eax \n\t"
	"movq $1, %%rdi \n\t"
	"syscall \n\t"
	:
	:"S"(a), "d"(length)
	) ;

}

int printi(int n)
{
	char temp[100];int i=0;
	if(n<0)
	{
		temp[0]='-';
		n*=-1;
		i=1;
	}
	if(n==0)
	{
		temp[0]='0';
		i=1;
	}
	else
	{
		int s[100];int j=0;
		while(n>0)
		{
			s[j]=n%10;
			n/=10;
			++j;

		}
		j-=1;
		while(j>=0)
		{
			temp[i]=(char)(s[j]+'0');
			++i;--j;
		}
	}
	temp[i]='\0';
	__asm__ __volatile__ (
	"movl $1, %%eax \n\t"
	"movq $1, %%rdi \n\t"
	"syscall \n\t"
	:
	:"S"(temp), "d"(i)
	) ;

	return i;
	
}
int readi(int *eP)
{
	int i,begin,end;
	char temp[100];
	for(i=0;;++i)
	{
		__asm__ __volatile(
            "movl $0, %%eax \n\t"
            "movq $0, %%rdi \n\t"
            "syscall \n\t"
            :
            :"S"(temp+i), "d"(1)
        );
        if((temp[i]=='\n' || temp[i]=='\t' ||temp[i]==' ') & i==0)//if the first character is a newline,it starts reading from the beginning
        {
        	i=-1;continue;
        }
        if(temp[i]=='\n'|| temp[i]=='\t' || temp[i]==' ')
        	break;

	}
	end=i-1;int par;
	if(temp[end]=='-')
	{
		*eP=ERR;

		return *eP;

	}
	if(temp[0]=='-')
		begin=1;
	else begin=0;
	for(i=begin;i<=end;++i)
	{
		if(temp[i]<'0' || temp[i]>'9')
		{
			*eP=ERR;
			
			return *eP;
		}

	}
	int n=0;
	for(i=begin;i<=end;++i)
	{
		n*=10;
		n+=temp[i]-'0';
		
		
	}
	if(temp[0]=='-')
		n*=-1;
	*eP=OK;
	return n;

}
int readf(float *fP)
{
	int i,begin,end,rad;
	char temp[100];
	for(i=0;;++i)
	{
		__asm__ __volatile(
            "movl $0, %%eax \n\t"
            "movq $0, %%rdi \n\t"
            "syscall \n\t"
            :
            :"S"(temp+i), "d"(1)
        );
         if((temp[i]=='\n' || temp[i]=='\t' ||temp[i]==' ') & i==0)//if the first character is a newline,it starts reading from the beginning
        {
        	i=-1;continue;
        }
        if(temp[i]=='\n'|| temp[i]=='\t' || temp[i]==' ')
        	break;

	}

	end=i-1;int flag=0,flag1=0,ex,flag2=0;
	rad=end;ex=end;
	if(temp[0]=='-')
		begin=1;
	else begin=0;
	int par;
	if(temp[end]>'9' || temp[end]<'0')
	{

		par=ERR;
		return par;

	}
	for(i=begin;i<=end;++i)
	{
		if(temp[i]<'0' || temp[i]>'9')
		{
			if(temp[i]=='e' && flag1==0)
			{
				ex=i-1;flag1=1;flag=1;continue;
			}
			else if(temp[i]=='.' && flag==0)
			{
				flag=1;
				rad=i-1;
				
			}
			else if(temp[i]=='-' && temp[i-1]=='e')
			{
				flag2=1;continue;
			}
			else
			{
				par=ERR;
				return par;

			}
		}


	}

	int n=0;


	if(rad!=end && ex!=end)
	{

		for(i=begin;i<=rad;++i)
	{
		n*=10;
		n+=temp[i]-'0';
		
		
	}
	float ans=0;int g=0;int den=1;
	
	for(i=rad+2;i<=ex;++i)
	{
		g*=10;
		g+=temp[i]-'0';
		den*=10;
	}
	ans=(float)g/(float)den;
	(*fP)=ans+(float)n;
	if(temp[0]=='-')
		(*fP)=-1*(*fP);
	int pow=0;
	if(flag2==0)
	{
	for(i=ex+2;i<=end;++i)
	{
		pow*=10;
		pow+=temp[i]-'0';
		
		
	}
	for(i=1;i<=pow;++i)
		(*fP)=(*fP)*10.0;
	}
	else
	{
		for(i=ex+3;i<=end;++i)
	{
		pow*=10;
		pow+=temp[i]-'0';
		
		
	}
	for(i=1;i<=pow;++i)
		(*fP)=(*fP)/10.0;

	}





	}
	else if(ex!=end)
	{

	for(i=begin;i<=ex;++i)
	{
		n*=10;
		n+=temp[i]-'0';
		
		
	}
	
	*fP=(float)n;
	if(temp[0]=='-')
		(*fP)=-1*(*fP);
	int pow=0;
	if(flag2==0)
	{
	for(i=ex+2;i<=end;++i)
	{
		pow*=10;
		pow+=temp[i]-'0';
		
		
	}

	for(i=1;i<=pow;++i)
		(*fP)=(*fP)*10.0;
	}
	else
	{

		for(i=ex+3;i<=end;++i)
		{
		pow*=10;
		pow+=temp[i]-'0';
		
		
		}

	for(i=1;i<=pow;++i)
		(*fP)=(*fP)/10.0;

	}




	}

	else{
	for(i=begin;i<=rad;++i)
	{
		n*=10;
		n+=temp[i]-'0';
		
		
	}
	
	float ans=0;int g=0;int den=1;

	for(i=rad+2;i<=end;++i)
	{
		g*=10;
		g+=temp[i]-'0';
		den*=10;
	}
	ans=(float)g/(float)den;
	(*fP)=ans+(float)n;
	if(temp[0]=='-')
		(*fP)=-1*(*fP);
	}
	par=OK;
	
	return par;

}

int printd(float f)
{

	char temp[100];int i=0;
	 if(f<0)
	{
		temp[0]='-';
		f=-1*f;
		i=1;
	}
	int more=0;
	if(f>1e18)
	{
		f=f*1e-18;
		more=1;
	}
	long long int ing=(long long int)f;

	float frc=f-(float)ing;
	if(ing==0)
	{
		temp[i]='0';
		i++;
	}
	else
	{
		
		int s[100];int j=0;
		while(ing>0)
		{
			s[j]=ing%10;
			ing/=10;
			++j;

		}
		j-=1;
		while(j>=0)
		{
			temp[i]=(char)(s[j]+'0');
			++i;--j;
		}
	}
	temp[i]='.';
	++i;
	
	if(frc==0.0)
	{
		if(more==0)
		{
			temp[i]='0';
			++i;
		}
		else
		{
			
			int i2=0;
			while(i2<18)
			{
				temp[i-1]='0';
				++i2;++i;
			}
			temp[i-1]='.';
			temp[i]='0';
			i+=1;

		}

			
	}
	else
	{
		float fr=frc;int dec=0;
		if(more==0)
		{
		while(fr>0.0 && dec<6 )
		{
			++dec;
			float f4=fr*10;

			float f5=f4-(int )f4;
			int k=(int)f4;
			
			temp[i]=(char)('0'+k);
			fr=f5;
			++i;
		}
		}
		else
		{
			int dec=0;
			while(fr>0.0 && dec<24 )
			{
				++dec;
				float f4=fr*10;

				float f5=f4-(int )f4;
				int k=(int)f4;
			
				temp[i]=(char)('0'+k);
				fr=f5;
				++i;
		 	}
		}
		
		if(more==1)
		{
			int i2=0;
			while(temp[i2]!='.')
				++i2;
			int fl1=0;
			while(fl1<18)
			{
				++fl1;
				temp[i2]=temp[i2+1];
				++i2;
			}
			temp[i2]='.';
		}
	}
	temp[i]='\0';
	__asm__ __volatile__ (
	"movl $1, %%eax \n\t"
	"movq $1, %%rdi \n\t"
	"syscall \n\t"
	:
	:"S"(temp), "d"(i)
	) ;

	return i;
}

