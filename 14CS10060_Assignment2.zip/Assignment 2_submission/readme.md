Assignment 2

Name:Ashrujit Ghoshal
Roll No-14CS10060

myl.h is the header file and its implementation is in ass2_14CS10060.c 
test.c is for testing the library
A makefile has been included to automate compilation
The library generated is in libmyl.a