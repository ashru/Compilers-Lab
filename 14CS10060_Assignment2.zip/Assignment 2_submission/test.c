# include "myl.h"
int main(){
  prints("Testing prints()\n");
  int no_of_chars =prints("Hello World!!");
  prints("\nThe no of characters is : ");
  printi(no_of_chars);
  prints("\n");
  char ch;
  int i = 0;
  
  prints("\nTesting readi() and printi()\nEnter an integer: \n");
  int n;
  int t;
  n = readi(&t);

  if(t==ERR)
     prints("Invalid Input\n");
  else{
      prints("The number  you entered : \n");
      no_of_chars = printi(n);
      prints("\nThe number of characters :");
      printi(no_of_chars);
      prints("\n");
  }
  prints("\nEnter a floating point number\n");
  float num;
  t = readf(&num);

  if(t==ERR)
     prints("Invalid Input\n");
  else{
      prints("The number you entered : \n");
     
      no_of_chars = printd(num);
      prints("\nThe number of characters :");
      printi(no_of_chars);
      prints("\n");
  }

  return 0;
}
