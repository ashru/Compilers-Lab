//handling 2d arrays

int main()
{

	int a[10][10];
	int b[10][10];
	int p, n, x, i, y, z,j,m;
	prints("Enter the number of rows of 2D array  ");	
	n = readi(&p);
	prints("Enter the number of columns of 2D array  ");	
	m = readi(&p);
	//prints("\n");
	//n=4;
	
	for(i = 0; i < n; i++ )
	{
		prints("Enter the elements of array row:");
		printi(i);
		prints("\n");
		for(j=0;j<m;++j)
		{
		x = readi(&p);
		a[i][j] = x;
	}
	}
	//prints("\n");
	int sum;
	sum=0;
	prints("The sum of all elements of array:\n");
	for( i = 0; i < n; i++ )
	{
		for(j=0;j<m;++j)
		{
		x=a[i][j];
		y=sum+x;
		sum=y;
		}
	}
	printi(sum);
	prints("\n");
	return 0;
}
