/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.4"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* Copy the first part of user declarations.  */
#line 1 "ass6_14CS10060.y" /* yacc.c:339  */

#include <string.h>
#include <stdio.h>
#include "ass6_14CS10060_translator.h"


 
//Global Declarations.
extern int yylex();

symboltable* Global_symb_table = new symboltable; // Global Symboltable.
symboltable* current_symb_table = Global_symb_table; // Current symboltable initialize to global symboltable.
Quad* Quad_array[MAX_SIZE]; // Quad Array of size MAX_SIZE.
int nextinstr = 1; // Global variable nextinstr storing the count of Quads in Quad Array.
_type* global_type; // Global variable global_type used for storing type while declaration.
int global_width; // Global variable global_width used for storing width while declaration.
int unary_operator_type; // stores the type of unary operator.
int line_num = 1; // stores the line number for debugging reasons.
int flag_return_type = 0; // flag for obtaining the return type of a function to check its type with returned variable.
_type* return_type; // stores the return type of a function.
int return_width = 0; // stores the size of the return type of a function.

void yyerror(char s[]);


#line 92 "y.tab.c" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "y.tab.h".  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    KEYWORD_AUTO = 258,
    KEYWORD_BREAK = 259,
    KEYWORD_CASE = 260,
    KEYWORD_CHAR = 261,
    KEYWORD_CONST = 262,
    KEYWORD_CONTINUE = 263,
    KEYWORD_DEFAULT = 264,
    KEYWORD_DO = 265,
    KEYWORD_DOUBLE = 266,
    KEYWORD_ELSE = 267,
    KEYWORD_ENUM = 268,
    KEYWORD_EXTERN = 269,
    KEYWORD_FLOAT = 270,
    KEYWORD_FOR = 271,
    KEYWORD_GOTO = 272,
    KEYWORD_IF = 273,
    KEYWORD_INLINE = 274,
    KEYWORD_INT = 275,
    KEYWORD_LONG = 276,
    KEYWORD_REGISTER = 277,
    KEYWORD_RESTRICT = 278,
    KEYWORD_RETURN = 279,
    KEYWORD_SHORT = 280,
    KEYWORD_SIGNED = 281,
    KEYWORD_SIZEOF = 282,
    KEYWORD_STATIC = 283,
    KEYWORD_STRUCT = 284,
    KEYWORD_SWITCH = 285,
    KEYWORD_TYPEDEF = 286,
    KEYWORD_UNION = 287,
    KEYWORD_UNSIGNED = 288,
    KEYWORD_VOID = 289,
    KEYWORD_VOLATILE = 290,
    KEYWORD_WHILE = 291,
    KEYWORD_BOOL = 292,
    KEYWORD_COMPLEX = 293,
    KEYWORD_IMAGINARY = 294,
    ARROW = 295,
    PLUS_PLUS = 296,
    MINUS_MINUS = 297,
    SHIFT_LEFT = 298,
    SHIFT_RIGHT = 299,
    LESS_EQUAL = 300,
    GREATER_EQUAL = 301,
    IS_EQUAL = 302,
    NOT_EQUAL = 303,
    LOGICAL_AND = 304,
    LOGICAL_OR = 305,
    ELLIPSIS = 306,
    STAR_EQUAL = 307,
    DIVIDE_EQUAL = 308,
    MODULO_EQUAL = 309,
    PLUS_EQUAL = 310,
    MINUS_EQUAL = 311,
    SHIFT_LEFT_EQUAL = 312,
    SHIFT_RIGHT_EQUAL = 313,
    AND_EQUAL = 314,
    XOR_EQUAL = 315,
    OR_EQUAL = 316,
    identifier = 317,
    integer_constant = 318,
    floating_constant = 319,
    character_constant = 320,
    string_literal = 321,
    IFEND = 322,
    ELSE = 323
  };
#endif
/* Tokens.  */
#define KEYWORD_AUTO 258
#define KEYWORD_BREAK 259
#define KEYWORD_CASE 260
#define KEYWORD_CHAR 261
#define KEYWORD_CONST 262
#define KEYWORD_CONTINUE 263
#define KEYWORD_DEFAULT 264
#define KEYWORD_DO 265
#define KEYWORD_DOUBLE 266
#define KEYWORD_ELSE 267
#define KEYWORD_ENUM 268
#define KEYWORD_EXTERN 269
#define KEYWORD_FLOAT 270
#define KEYWORD_FOR 271
#define KEYWORD_GOTO 272
#define KEYWORD_IF 273
#define KEYWORD_INLINE 274
#define KEYWORD_INT 275
#define KEYWORD_LONG 276
#define KEYWORD_REGISTER 277
#define KEYWORD_RESTRICT 278
#define KEYWORD_RETURN 279
#define KEYWORD_SHORT 280
#define KEYWORD_SIGNED 281
#define KEYWORD_SIZEOF 282
#define KEYWORD_STATIC 283
#define KEYWORD_STRUCT 284
#define KEYWORD_SWITCH 285
#define KEYWORD_TYPEDEF 286
#define KEYWORD_UNION 287
#define KEYWORD_UNSIGNED 288
#define KEYWORD_VOID 289
#define KEYWORD_VOLATILE 290
#define KEYWORD_WHILE 291
#define KEYWORD_BOOL 292
#define KEYWORD_COMPLEX 293
#define KEYWORD_IMAGINARY 294
#define ARROW 295
#define PLUS_PLUS 296
#define MINUS_MINUS 297
#define SHIFT_LEFT 298
#define SHIFT_RIGHT 299
#define LESS_EQUAL 300
#define GREATER_EQUAL 301
#define IS_EQUAL 302
#define NOT_EQUAL 303
#define LOGICAL_AND 304
#define LOGICAL_OR 305
#define ELLIPSIS 306
#define STAR_EQUAL 307
#define DIVIDE_EQUAL 308
#define MODULO_EQUAL 309
#define PLUS_EQUAL 310
#define MINUS_EQUAL 311
#define SHIFT_LEFT_EQUAL 312
#define SHIFT_RIGHT_EQUAL 313
#define AND_EQUAL 314
#define XOR_EQUAL 315
#define OR_EQUAL 316
#define identifier 317
#define integer_constant 318
#define floating_constant 319
#define character_constant 320
#define string_literal 321
#define IFEND 322
#define ELSE 323

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 27 "ass6_14CS10060.y" /* yacc.c:355  */

	struct expression_attributes expression_attr;
  int int_val;
  double double_val;
  char* string_text;

#line 275 "y.tab.c" /* yacc.c:355  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */

/* Copy the second part of user declarations.  */

#line 292 "y.tab.c" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  34
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1538

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  94
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  65
/* YYNRULES -- Number of rules.  */
#define YYNRULES  215
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  379

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   323

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    55,     2,    86,     2,    57,    50,     2,
      42,    43,    51,    52,    85,    53,    46,    56,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    71,    72,
      60,    74,    61,    70,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    40,     2,    41,    66,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    44,    67,    45,    54,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    47,    48,    49,    58,    59,
      62,    63,    64,    65,    68,    69,    73,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    87,    88,    89,
      90,    91,    92,    93
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   197,   197,   200,   205,   206,   210,   241,   278,   279,
     282,   295,   313,   332,   351,   371,   409,   414,   559,   600,
     768,   769,   770,   842,   911,   912,   915,   933,   953,   976,
    1026,  1076,  1179,  1180,  1183,  1186,  1189,  1192,  1195,  1198,
    1203,  1207,  1294,  1305,  1341,  1384,  1433,  1436,  1480,  1528,
    1531,  1573,  1617,  1620,  1666,  1712,  1758,  1806,  1809,  1855,
    1903,  1906,  1949,  1952,  1997,  2000,  2043,  2046,  2072,  2075,
    2102,  2107,  2110,  2141,  2144,  2258,  2259,  2260,  2261,  2262,
    2263,  2264,  2265,  2266,  2267,  2268,  2271,  2274,  2277,  2280,
    2281,  2284,  2285,  2286,  2301,  2302,  2303,  2304,  2305,  2309,
    2313,  2318,  2410,  2600,  2601,  2602,  2603,  2606,  2612,  2618,
    2619,  2626,  2627,  2628,  2634,  2635,  2636,  2637,  2638,  2639,
    2642,  2645,  2646,  2647,  2650,  2651,  2652,  2653,  2654,  2657,
    2658,  2661,  2662,  2665,  2670,  2671,  2672,  2675,  2678,  2682,
    2704,  2713,  2716,  2723,  2724,  2774,  2775,  2776,  2777,  2778,
    2779,  2780,  2793,  2806,  2809,  2825,  2826,  2842,  2845,  2846,
    2849,  2852,  2857,  2863,  2871,  2903,  2908,  2911,  2916,  2921,
    2924,  2925,  2928,  2931,  2932,  2933,  2936,  2939,  2940,  2943,
    2944,  2947,  2948,  2951,  2954,  2957,  2960,  2965,  2968,  2969,
    2972,  2973,  2978,  2981,  2989,  2993,  2998,  2999,  3017,  3025,
    3045,  3071,  3074,  3098,  3108,  3128,  3129,  3130,  3131,  3134,
    3137,  3142,  3143,  3144,  3145,  3160
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "KEYWORD_AUTO", "KEYWORD_BREAK",
  "KEYWORD_CASE", "KEYWORD_CHAR", "KEYWORD_CONST", "KEYWORD_CONTINUE",
  "KEYWORD_DEFAULT", "KEYWORD_DO", "KEYWORD_DOUBLE", "KEYWORD_ELSE",
  "KEYWORD_ENUM", "KEYWORD_EXTERN", "KEYWORD_FLOAT", "KEYWORD_FOR",
  "KEYWORD_GOTO", "KEYWORD_IF", "KEYWORD_INLINE", "KEYWORD_INT",
  "KEYWORD_LONG", "KEYWORD_REGISTER", "KEYWORD_RESTRICT", "KEYWORD_RETURN",
  "KEYWORD_SHORT", "KEYWORD_SIGNED", "KEYWORD_SIZEOF", "KEYWORD_STATIC",
  "KEYWORD_STRUCT", "KEYWORD_SWITCH", "KEYWORD_TYPEDEF", "KEYWORD_UNION",
  "KEYWORD_UNSIGNED", "KEYWORD_VOID", "KEYWORD_VOLATILE", "KEYWORD_WHILE",
  "KEYWORD_BOOL", "KEYWORD_COMPLEX", "KEYWORD_IMAGINARY", "'['", "']'",
  "'('", "')'", "'{'", "'}'", "'.'", "ARROW", "PLUS_PLUS", "MINUS_MINUS",
  "'&'", "'*'", "'+'", "'-'", "'~'", "'!'", "'/'", "'%'", "SHIFT_LEFT",
  "SHIFT_RIGHT", "'<'", "'>'", "LESS_EQUAL", "GREATER_EQUAL", "IS_EQUAL",
  "NOT_EQUAL", "'^'", "'|'", "LOGICAL_AND", "LOGICAL_OR", "'?'", "':'",
  "';'", "ELLIPSIS", "'='", "STAR_EQUAL", "DIVIDE_EQUAL", "MODULO_EQUAL",
  "PLUS_EQUAL", "MINUS_EQUAL", "SHIFT_LEFT_EQUAL", "SHIFT_RIGHT_EQUAL",
  "AND_EQUAL", "XOR_EQUAL", "OR_EQUAL", "','", "'#'", "identifier",
  "integer_constant", "floating_constant", "character_constant",
  "string_literal", "IFEND", "ELSE", "$accept", "translation_unit",
  "external_declaration", "function_definition", "declaration_list",
  "primary_expression", "postfix_expression", "argument_expression_list",
  "unary_expression", "unary_operator", "cast_expression",
  "multiplicative_expression", "additive_expression", "shift_expression",
  "relational_expression", "equality_expression", "AND_expression",
  "exclusive_OR_expression", "inclusive_OR_expression",
  "logical_AND_expression", "logical_OR_expression", "M",
  "conditional_expression", "assignment_expression", "assignment_operator",
  "expression", "constant_expression", "declaration",
  "declaration_specifiers", "init_declarator_list", "init_declarator",
  "storage_class_specifier", "type_specifier", "specifier_qualifier_list",
  "enum_specifier", "enumerator_list", "enumerator",
  "enumeration_constant", "type_qualifier", "function_specifier",
  "declarator", "direct_declarator", "pointer", "type_qualifier_list",
  "parameter_type_list", "parameter_list", "parameter_declaration",
  "identifier_list", "typename", "initializer", "initializer_list",
  "designation", "designator_list", "designator", "statement",
  "labeled_statement", "compound_statement", "block_item_list",
  "block_item", "expression_statement", "N", "selection_statement",
  "iteration_statement", "expression_opt", "jump_statement", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
      91,    93,    40,    41,   123,   125,    46,   295,   296,   297,
      38,    42,    43,    45,   126,    33,    47,    37,   298,   299,
      60,    62,   300,   301,   302,   303,    94,   124,   304,   305,
      63,    58,    59,   306,    61,   307,   308,   309,   310,   311,
     312,   313,   314,   315,   316,    44,    35,   317,   318,   319,
     320,   321,   322,   323
};
# endif

#define YYPACT_NINF -317

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-317)))

#define YYTABLE_NINF -199

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    1465,  -317,  -317,  -317,  -317,   -14,  -317,  -317,  -317,  -317,
    -317,  -317,  -317,  -317,  -317,  -317,  -317,  -317,  -317,  -317,
    -317,  -317,  1428,  -317,  -317,  -317,   -28,  1465,  1465,  -317,
    1465,  1465,   -46,    38,  -317,  -317,    -9,    29,  -317,  -317,
      80,  -317,   918,    71,   -27,  -317,  -317,  -317,  -317,  -317,
      31,  -317,   -29,   -46,    58,  -317,  -317,    29,  -317,    -9,
     302,  1050,  1388,  -317,   -28,  -317,   728,   711,    71,  -317,
     -25,  1249,    32,  -317,  -317,  -317,  -317,    49,    53,  1249,
      57,    76,  -317,   107,    92,   130,  1079,  1280,   146,   152,
     622,  -317,  1299,  1299,  -317,  -317,  -317,  -317,  -317,  -317,
    -317,   132,  -317,  -317,  -317,  -317,  -317,   207,   284,  1249,
    -317,   120,    22,   116,   139,   118,   161,   151,   145,   155,
     117,  -317,  -317,    85,  -317,  -317,  -317,  -317,   185,  -317,
    -317,  -317,  -317,  -317,  1021,  -317,  -317,  -317,  -317,  -317,
     829,  -317,   190,   192,   779,  -317,  -317,    -9,   191,   154,
    -317,     6,  -317,  -317,  -317,  -317,  -317,  -317,     2,  -317,
     165,  -317,   536,   536,   480,   169,  1249,  -317,    95,   622,
    -317,  1249,  -317,     8,  1499,  -317,  1499,   194,   622,  -317,
    -317,   536,  1249,  1129,   156,   157,  -317,  -317,  -317,  -317,
    -317,  -317,  -317,  -317,  -317,  -317,  -317,  -317,  -317,  1249,
    -317,  1249,  1249,  1249,  1249,  1249,  1249,  1249,  1249,  1249,
    1249,  1249,  1249,  1249,  1249,  1249,  1249,  -317,  -317,   178,
    -317,  1249,  -317,   391,  1249,   173,  -317,    34,  1050,    81,
    -317,   211,   829,  -317,  -317,  1249,  -317,   221,   222,  -317,
    -317,   960,  -317,   177,  -317,   536,  -317,   229,   181,  1149,
     197,  -317,   181,  -317,   227,    11,  1249,  -317,  -317,  -317,
    1180,   228,  -317,   -24,  -317,    15,  -317,  -317,  -317,  -317,
    -317,  -317,  -317,   120,   120,    22,    22,   116,   116,   116,
     116,   139,   139,   118,   161,   151,  1249,  1249,  -317,  -317,
    -317,   231,  -317,  -317,   962,  -317,  -317,  -317,  -317,   233,
     234,  -317,  -317,  -317,  -317,  -317,  -317,  -317,  1199,    96,
    -317,   236,   232,   536,   181,  1021,  -317,   232,  -317,  -317,
    1249,   145,   155,  1249,  -317,  -317,  -317,  1050,  -317,  -317,
     235,   536,    23,  1230,  1249,  -317,  -317,   237,    39,  -317,
     181,  -317,  1249,  -317,   536,   536,    24,  -317,   536,  -317,
    -317,   992,   210,    27,  -317,  -317,   536,   212,  -317,   536,
    -317,  -317,   213,  -317,  -317,   270,  -317,  1249,  -317,  1249,
    -317,  -317,  -317,   536,   244,  -317,  -317,   536,  -317
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,   105,   108,   134,   113,     0,   103,   112,   137,   110,
     111,   106,   135,   109,   114,   104,   115,   107,   136,   116,
     117,   118,     0,     2,     4,     5,     0,    91,    93,   119,
      95,    97,     0,   128,     1,     3,     0,   154,    89,   140,
       0,    99,   101,   138,     0,    92,    94,    96,    98,   133,
       0,   129,   131,     0,     0,   158,   156,   155,    90,     0,
       0,     0,     0,     8,     0,     6,     0,     0,   139,   124,
       0,     0,     0,   141,   159,   157,   100,   101,     0,     0,
       0,     0,    70,     0,     0,     0,     0,     0,     0,     0,
       0,   190,     0,     0,    34,    35,    36,    37,    38,    39,
     196,    10,    11,    12,    13,    14,    16,    28,    40,     0,
      42,    46,    49,    52,    57,    60,    62,    64,    66,    68,
      71,    73,    86,     0,   194,   195,   181,   182,    70,   192,
     183,   184,   185,   186,     0,    10,   169,   102,     9,     7,
       0,   142,    35,     0,     0,   152,   166,   165,     0,   160,
     162,     0,   126,   130,    40,    88,   132,   125,     0,   213,
       0,   212,     0,     0,   209,     0,     0,   214,     0,     0,
      32,     0,    70,     0,   120,   168,   122,     0,     0,    29,
      30,     0,     0,     0,     0,     0,    22,    23,    75,    76,
      77,    78,    79,    80,    81,    82,    83,    84,    85,     0,
      31,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    70,    70,     0,
     197,     0,   191,     0,     0,     0,   172,     0,     0,     0,
     177,     0,     0,   149,   144,     0,   143,    35,     0,   164,
     151,     0,   153,     0,   127,     0,   189,     0,   210,     0,
       0,   211,   198,   215,     0,     0,     0,    15,   121,   123,
       0,     0,   187,     0,    18,     0,    26,    20,    21,    74,
      43,    44,    45,    47,    48,    50,    51,    53,    54,    55,
      56,    58,    59,    61,    63,    65,     0,     0,    70,    87,
     193,     0,   180,   170,     0,   173,   176,   178,   146,     0,
       0,   150,   145,   161,   163,   167,   188,    70,     0,     0,
      70,     0,    33,     0,   198,     0,    41,     0,    17,    19,
       0,    67,    69,     0,   179,   171,   174,     0,   147,   148,
       0,     0,     0,     0,   209,    70,   201,     0,     0,    27,
     198,   175,     0,   205,     0,     0,     0,   198,     0,    70,
      24,     0,     0,     0,   207,   206,     0,     0,   198,     0,
      25,    70,     0,   208,    70,   199,   202,     0,   203,   209,
      70,    72,   198,     0,     0,   200,    70,     0,   204
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -317,  -317,   266,  -317,  -317,  -317,  -317,  -317,   -71,  -317,
     -97,   -12,    -1,    18,     7,    75,    78,    79,     5,    12,
    -317,  -103,   -70,   -37,  -317,   -83,   -74,    -5,     4,  -317,
     239,  -317,   -84,   -56,  -317,   241,   -60,  -317,   -18,  -317,
      14,   256,    91,   -53,  -317,  -317,    60,  -317,  -113,   -59,
     -13,  -283,  -317,    74,  -135,  -317,     1,  -317,   108,  -317,
    -150,  -317,  -317,  -316,  -317
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    22,    23,    24,    62,   106,   107,   265,   108,   109,
     110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
     120,   163,   121,   122,   199,   123,   156,    25,    64,    40,
      41,    27,    28,   175,    29,    50,    51,    52,    30,    31,
      77,    43,    44,    57,   148,   149,   150,   151,   177,   226,
     227,   228,   229,   230,   125,   126,   127,   128,   129,   130,
     219,   131,   132,   250,   133
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     154,   155,   137,   168,    26,   160,   174,   173,   154,   155,
     153,   327,   200,   144,    36,    36,   170,   318,   347,    55,
     152,   179,   180,    37,   136,   223,    26,   246,   247,   143,
      32,    45,    46,    36,    47,    48,     3,    63,   154,    74,
      42,    49,    37,    65,    38,    71,   262,   244,    55,   242,
      54,   257,    12,   372,   313,   124,   254,   138,   319,    39,
      39,   221,    49,   139,    18,   261,   344,   356,   327,   256,
     362,   147,   176,    33,   204,   205,    69,   157,    39,   293,
      37,   248,    53,   252,   350,   174,   173,   232,   255,    49,
     174,   243,   174,   221,   174,   173,   221,   136,   153,   263,
     320,    73,   311,   231,   270,   271,   272,   238,   221,   221,
     306,    66,   221,    67,   286,   287,    70,   158,   258,   294,
     259,   224,    55,    61,   351,   159,    74,   225,    56,   161,
     154,   154,   154,   154,   154,   154,   154,   154,   154,   154,
     154,   154,   154,   154,   154,   154,   266,   162,    75,   164,
     291,   176,    58,   154,   155,   296,   176,   220,   176,   249,
     176,   239,   269,   316,   337,    59,   309,   253,   333,   295,
     221,   201,   166,   314,   206,   207,   202,   203,   336,   165,
     221,   221,   212,   213,   289,   323,   218,  -198,   171,   154,
     352,   136,   273,   274,   172,   299,   343,   357,   300,   208,
     209,   210,   211,   181,   330,   275,   276,   334,   365,   354,
     355,   214,   216,   358,    74,   154,   154,   215,   124,   281,
     282,   363,   374,   217,   366,   332,   277,   278,   279,   280,
     222,   233,   348,   234,   240,   326,   245,   260,   375,   241,
     340,   251,   378,   267,   268,   147,   359,   182,   288,   183,
     346,   248,   298,   184,   185,   186,   187,   136,   367,   353,
     292,   369,   301,   302,   305,   307,   221,   373,   341,   310,
     312,   317,   324,   377,   328,   329,   315,   342,   136,   335,
     349,   361,   370,   339,   364,   368,   248,   376,    35,   283,
     136,   321,   326,   284,    72,   285,   154,   371,    76,   322,
      68,   304,   338,   297,     0,     1,    78,    79,     2,     3,
      80,    81,    82,     4,   136,     5,     6,     7,    83,    84,
      85,     8,     9,    10,    11,    12,    86,    13,    14,    87,
      15,   290,    88,     0,     0,    16,    17,    18,    89,    19,
      20,    21,     0,     0,    90,     0,    60,    91,     0,     0,
      92,    93,    94,    95,    96,    97,    98,    99,   188,   189,
     190,   191,   192,   193,   194,   195,   196,   197,   198,     0,
       0,     0,     0,     0,   100,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   101,
     102,   103,   104,   105,     1,    78,    79,     2,     3,    80,
      81,    82,     4,     0,     5,     6,     7,    83,    84,    85,
       8,     9,    10,    11,    12,    86,    13,    14,    87,    15,
       0,    88,     0,     0,    16,    17,    18,    89,    19,    20,
      21,     0,     0,    90,     0,    60,     0,     0,     0,    92,
      93,    94,    95,    96,    97,    98,    99,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   100,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   101,   102,
     103,   104,   105,     1,     0,     0,     2,     3,     0,     0,
       0,     4,     0,     5,     6,     7,     0,     0,     0,     8,
       9,    10,    11,    12,     0,    13,    14,    87,    15,     0,
       0,     0,     0,    16,    17,    18,     0,    19,    20,    21,
       0,     0,    90,     0,     0,     0,     0,     0,    92,    93,
      94,    95,    96,    97,    98,    99,     0,     0,     0,     0,
      78,    79,     0,     0,    80,    81,    82,     0,     0,     0,
       0,     0,    83,    84,    85,     0,     0,     0,     0,     0,
      86,     0,     0,    87,     0,     0,    88,   135,   102,   103,
     104,   105,    89,     0,     0,     0,     0,     0,    90,     0,
      60,     0,     0,     0,    92,    93,    94,    95,    96,    97,
      98,    99,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   100,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   101,   102,   103,   104,   105,     2,     3,
       0,     0,     0,     4,     0,     5,     0,     7,     0,     0,
       0,     0,     9,    10,     0,    12,     0,    13,    14,    87,
       0,     0,     0,     0,     0,    16,    17,    18,     0,    19,
      20,    21,     0,     0,    90,     0,     0,     0,     0,     0,
      92,    93,    94,    95,    96,    97,    98,    99,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   135,
     102,   103,   104,   105,     1,     0,     0,     2,     3,     0,
       0,     0,     4,     0,     5,     6,     7,     0,     0,     0,
       8,     9,    10,    11,    12,     3,    13,    14,     0,    15,
       0,     0,     0,     0,    16,    17,    18,     0,    19,    20,
      21,    12,     0,     0,   145,    87,   140,     0,     0,     0,
       0,     0,     0,    18,     0,     0,     0,     0,     0,   141,
      90,     0,     0,     0,     0,     0,    92,    93,    94,   142,
      96,    97,    98,    99,     0,     0,     3,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   146,     0,
       0,     0,    12,     0,     0,     0,    87,   235,     0,     0,
       0,     0,     0,     0,    18,   135,   102,   103,   104,   105,
     236,    90,     0,     0,     0,     0,     0,    92,    93,    94,
     237,    96,    97,    98,    99,     0,     3,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    12,     0,     0,     0,    87,     0,     0,     0,
       0,     0,     0,     0,    18,     0,   135,   102,   103,   104,
     105,    90,     0,     0,     0,     0,     0,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   135,   102,   103,   104,
     105,     1,     0,     0,     2,     3,     0,     0,     0,     4,
       0,     5,     6,     7,     0,     0,     0,     8,     9,    10,
      11,    12,     0,    13,    14,     0,    15,     0,     0,     0,
       0,    16,    17,    18,     0,    19,    20,    21,     0,     0,
       0,     0,    60,     1,     0,     0,     2,     3,     0,     0,
       0,     4,     0,     5,     6,     7,     0,     0,     0,     8,
       9,    10,    11,    12,     0,    13,    14,     0,    15,    87,
       0,     0,    61,    16,    17,    18,     0,    19,    20,    21,
       0,     0,   224,     0,    90,     0,   134,   325,   225,     0,
      92,    93,    94,    95,    96,    97,    98,    99,     0,    87,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   224,   303,    90,     0,   134,   360,   225,     0,
      92,    93,    94,    95,    96,    97,    98,    99,    87,   135,
     102,   103,   104,   105,     0,     0,     0,     0,     0,     0,
       0,   224,     0,    90,     0,   134,     0,   225,     0,    92,
      93,    94,    95,    96,    97,    98,    99,    87,     0,   135,
     102,   103,   104,   105,     0,     0,     0,     0,     0,     0,
       0,     0,    90,     0,   134,     0,     0,     0,    92,    93,
      94,    95,    96,    97,    98,    99,    87,     0,   135,   102,
     103,   104,   105,     0,     0,     0,     0,     0,     0,     0,
       0,    90,     0,     0,     0,     0,     0,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,   135,   102,   103,
     104,   105,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   167,     0,     0,     0,     0,    87,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   135,   102,   103,   104,
     105,    90,   264,     0,     0,     0,    87,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,     0,     0,     0,
       0,    90,     0,     0,     0,     0,     0,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,    87,     0,     0,
       0,     0,     0,     0,     0,     0,   135,   102,   103,   104,
     105,   308,    90,     0,   315,     0,    87,     0,    92,    93,
      94,    95,    96,    97,    98,    99,   135,   102,   103,   104,
     105,    90,   331,     0,     0,     0,     0,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,    87,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   135,   102,   103,
     104,   105,    90,   345,     0,     0,    87,     0,    92,    93,
      94,    95,    96,    97,    98,    99,   135,   102,   103,   104,
     105,    90,     0,     0,     0,     0,     0,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,    87,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   135,   102,   103,
     104,   105,   169,     0,     0,     0,    87,     0,    92,    93,
      94,    95,    96,    97,    98,    99,   135,   102,   103,   104,
     105,   178,     0,     0,     0,     0,     0,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   135,   102,   103,
     104,   105,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   135,   102,   103,   104,
     105,     1,     0,     0,     2,     3,     0,     0,     0,     4,
       0,     5,     6,     7,     0,     0,     0,     8,     9,    10,
      11,    12,     0,    13,    14,     0,    15,     0,     0,     0,
       0,    16,    17,    18,     0,    19,    20,    21,    34,     0,
       0,     1,    60,     0,     2,     3,     0,     0,     0,     4,
       0,     5,     6,     7,     0,     0,     0,     8,     9,    10,
      11,    12,     0,    13,    14,     0,    15,     0,     0,     0,
       0,    16,    17,    18,     0,    19,    20,    21,     1,     0,
       0,     2,     3,     0,     0,     0,     4,     0,     5,     6,
       7,     0,     0,     0,     8,     9,    10,    11,    12,     0,
      13,    14,     0,    15,     0,     0,     0,     0,    16,    17,
      18,     0,    19,    20,    21,     2,     3,     0,     0,     0,
       4,     0,     5,     0,     7,     0,     0,     0,     0,     9,
      10,     0,    12,     0,    13,    14,     0,     0,     0,     0,
       0,     0,    16,    17,    18,     0,    19,    20,    21
};

static const yytype_int16 yycheck[] =
{
      71,    71,    61,    86,     0,    79,    90,    90,    79,    79,
      70,   294,   109,    66,    42,    42,    87,    41,   334,    37,
      45,    92,    93,    51,    61,   128,    22,   162,   163,    66,
      44,    27,    28,    42,    30,    31,     7,    42,   109,    57,
      26,    87,    51,    42,    72,    74,   181,    45,    66,    43,
      36,    43,    23,   369,    43,    60,   169,    62,    43,    87,
      87,    85,    87,    62,    35,   178,    43,    43,   351,   172,
      43,    67,    90,    87,    52,    53,    45,    45,    87,    45,
      51,   164,    44,   166,    45,   169,   169,   140,   171,    87,
     174,    85,   176,    85,   178,   178,    85,   134,   158,   182,
      85,    43,   252,   140,   201,   202,   203,   144,    85,    85,
     245,    40,    85,    42,   217,   218,    85,    85,   174,    85,
     176,    40,   140,    74,    85,    72,   144,    46,    37,    72,
     201,   202,   203,   204,   205,   206,   207,   208,   209,   210,
     211,   212,   213,   214,   215,   216,   183,    71,    57,    42,
     224,   169,    72,   224,   224,    74,   174,    72,   176,   164,
     178,   147,   199,   260,   314,    85,   249,    72,    72,   228,
      85,    51,    42,   256,    58,    59,    56,    57,   313,    87,
      85,    85,    64,    65,   221,   288,    69,    70,    42,   260,
     340,   228,   204,   205,    42,   232,   331,   347,   235,    60,
      61,    62,    63,    71,   307,   206,   207,   310,   358,   344,
     345,    50,    67,   348,   232,   286,   287,    66,   223,   212,
     213,   356,   372,    68,   359,   308,   208,   209,   210,   211,
      45,    41,   335,    41,    43,   294,    71,    43,   373,    85,
     323,    72,   377,    87,    87,   241,   349,    40,    70,    42,
     333,   334,    41,    46,    47,    48,    49,   294,   361,   342,
      87,   364,    41,    41,    87,    36,    85,   370,   327,    72,
      43,    43,    41,   376,    41,    41,    44,    42,   315,    43,
      43,    71,    12,   320,    72,    72,   369,    43,    22,   214,
     327,   286,   351,   215,    53,   216,   367,   367,    59,   287,
      44,   241,   315,   229,    -1,     3,     4,     5,     6,     7,
       8,     9,    10,    11,   351,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,   223,    30,    -1,    -1,    33,    34,    35,    36,    37,
      38,    39,    -1,    -1,    42,    -1,    44,    45,    -1,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    -1,
      -1,    -1,    -1,    -1,    72,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    87,
      88,    89,    90,    91,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    -1,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      -1,    30,    -1,    -1,    33,    34,    35,    36,    37,    38,
      39,    -1,    -1,    42,    -1,    44,    -1,    -1,    -1,    48,
      49,    50,    51,    52,    53,    54,    55,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    72,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    87,    88,
      89,    90,    91,     3,    -1,    -1,     6,     7,    -1,    -1,
      -1,    11,    -1,    13,    14,    15,    -1,    -1,    -1,    19,
      20,    21,    22,    23,    -1,    25,    26,    27,    28,    -1,
      -1,    -1,    -1,    33,    34,    35,    -1,    37,    38,    39,
      -1,    -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    -1,    -1,    -1,    -1,
       4,     5,    -1,    -1,     8,     9,    10,    -1,    -1,    -1,
      -1,    -1,    16,    17,    18,    -1,    -1,    -1,    -1,    -1,
      24,    -1,    -1,    27,    -1,    -1,    30,    87,    88,    89,
      90,    91,    36,    -1,    -1,    -1,    -1,    -1,    42,    -1,
      44,    -1,    -1,    -1,    48,    49,    50,    51,    52,    53,
      54,    55,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    72,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    87,    88,    89,    90,    91,     6,     7,
      -1,    -1,    -1,    11,    -1,    13,    -1,    15,    -1,    -1,
      -1,    -1,    20,    21,    -1,    23,    -1,    25,    26,    27,
      -1,    -1,    -1,    -1,    -1,    33,    34,    35,    -1,    37,
      38,    39,    -1,    -1,    42,    -1,    -1,    -1,    -1,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    87,
      88,    89,    90,    91,     3,    -1,    -1,     6,     7,    -1,
      -1,    -1,    11,    -1,    13,    14,    15,    -1,    -1,    -1,
      19,    20,    21,    22,    23,     7,    25,    26,    -1,    28,
      -1,    -1,    -1,    -1,    33,    34,    35,    -1,    37,    38,
      39,    23,    -1,    -1,    43,    27,    28,    -1,    -1,    -1,
      -1,    -1,    -1,    35,    -1,    -1,    -1,    -1,    -1,    41,
      42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,    51,
      52,    53,    54,    55,    -1,    -1,     7,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    87,    -1,
      -1,    -1,    23,    -1,    -1,    -1,    27,    28,    -1,    -1,
      -1,    -1,    -1,    -1,    35,    87,    88,    89,    90,    91,
      41,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,     7,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    23,    -1,    -1,    -1,    27,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    35,    -1,    87,    88,    89,    90,
      91,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    87,    88,    89,    90,
      91,     3,    -1,    -1,     6,     7,    -1,    -1,    -1,    11,
      -1,    13,    14,    15,    -1,    -1,    -1,    19,    20,    21,
      22,    23,    -1,    25,    26,    -1,    28,    -1,    -1,    -1,
      -1,    33,    34,    35,    -1,    37,    38,    39,    -1,    -1,
      -1,    -1,    44,     3,    -1,    -1,     6,     7,    -1,    -1,
      -1,    11,    -1,    13,    14,    15,    -1,    -1,    -1,    19,
      20,    21,    22,    23,    -1,    25,    26,    -1,    28,    27,
      -1,    -1,    74,    33,    34,    35,    -1,    37,    38,    39,
      -1,    -1,    40,    -1,    42,    -1,    44,    45,    46,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    -1,    27,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    40,    73,    42,    -1,    44,    45,    46,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    27,    87,
      88,    89,    90,    91,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    40,    -1,    42,    -1,    44,    -1,    46,    -1,    48,
      49,    50,    51,    52,    53,    54,    55,    27,    -1,    87,
      88,    89,    90,    91,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    42,    -1,    44,    -1,    -1,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    27,    -1,    87,    88,
      89,    90,    91,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    87,    88,    89,
      90,    91,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    72,    -1,    -1,    -1,    -1,    27,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    87,    88,    89,    90,
      91,    42,    43,    -1,    -1,    -1,    27,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    -1,    -1,    -1,
      -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    27,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    87,    88,    89,    90,
      91,    72,    42,    -1,    44,    -1,    27,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    87,    88,    89,    90,
      91,    42,    43,    -1,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    27,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    87,    88,    89,
      90,    91,    42,    43,    -1,    -1,    27,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    87,    88,    89,    90,
      91,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    27,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    87,    88,    89,
      90,    91,    42,    -1,    -1,    -1,    27,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    87,    88,    89,    90,
      91,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    87,    88,    89,
      90,    91,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    87,    88,    89,    90,
      91,     3,    -1,    -1,     6,     7,    -1,    -1,    -1,    11,
      -1,    13,    14,    15,    -1,    -1,    -1,    19,    20,    21,
      22,    23,    -1,    25,    26,    -1,    28,    -1,    -1,    -1,
      -1,    33,    34,    35,    -1,    37,    38,    39,     0,    -1,
      -1,     3,    44,    -1,     6,     7,    -1,    -1,    -1,    11,
      -1,    13,    14,    15,    -1,    -1,    -1,    19,    20,    21,
      22,    23,    -1,    25,    26,    -1,    28,    -1,    -1,    -1,
      -1,    33,    34,    35,    -1,    37,    38,    39,     3,    -1,
      -1,     6,     7,    -1,    -1,    -1,    11,    -1,    13,    14,
      15,    -1,    -1,    -1,    19,    20,    21,    22,    23,    -1,
      25,    26,    -1,    28,    -1,    -1,    -1,    -1,    33,    34,
      35,    -1,    37,    38,    39,     6,     7,    -1,    -1,    -1,
      11,    -1,    13,    -1,    15,    -1,    -1,    -1,    -1,    20,
      21,    -1,    23,    -1,    25,    26,    -1,    -1,    -1,    -1,
      -1,    -1,    33,    34,    35,    -1,    37,    38,    39
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     3,     6,     7,    11,    13,    14,    15,    19,    20,
      21,    22,    23,    25,    26,    28,    33,    34,    35,    37,
      38,    39,    95,    96,    97,   121,   122,   125,   126,   128,
     132,   133,    44,    87,     0,    96,    42,    51,    72,    87,
     123,   124,   134,   135,   136,   122,   122,   122,   122,    87,
     129,   130,   131,    44,   134,   132,   136,   137,    72,    85,
      44,    74,    98,   121,   122,   150,    40,    42,   135,    45,
      85,    74,   129,    43,   132,   136,   124,   134,     4,     5,
       8,     9,    10,    16,    17,    18,    24,    27,    30,    36,
      42,    45,    48,    49,    50,    51,    52,    53,    54,    55,
      72,    87,    88,    89,    90,    91,    99,   100,   102,   103,
     104,   105,   106,   107,   108,   109,   110,   111,   112,   113,
     114,   116,   117,   119,   121,   148,   149,   150,   151,   152,
     153,   155,   156,   158,    44,    87,   117,   143,   121,   150,
      28,    41,    51,   117,   137,    43,    87,   122,   138,   139,
     140,   141,    45,   130,   102,   116,   120,    45,    85,    72,
     120,    72,    71,   115,    42,    87,    42,    72,   119,    42,
     102,    42,    42,   119,   126,   127,   132,   142,    42,   102,
     102,    71,    40,    42,    46,    47,    48,    49,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,   118,
     104,    51,    56,    57,    52,    53,    58,    59,    60,    61,
      62,    63,    64,    65,    50,    66,    67,    68,    69,   154,
      72,    85,    45,   115,    40,    46,   143,   144,   145,   146,
     147,   117,   137,    41,    41,    28,    41,    51,   117,   134,
      43,    85,    43,    85,    45,    71,   148,   148,   119,   121,
     157,    72,   119,    72,   142,   119,   115,    43,   127,   127,
      43,   142,   148,   119,    43,   101,   117,    87,    87,   117,
     104,   104,   104,   105,   105,   106,   106,   107,   107,   107,
     107,   108,   108,   109,   110,   111,   115,   115,    70,   117,
     152,   120,    87,    45,    85,   143,    74,   147,    41,   117,
     117,    41,    41,    73,   140,    87,   148,    36,    72,   119,
      72,   154,    43,    43,   119,    44,   104,    43,    41,    43,
      85,   112,   113,   115,    41,    45,   143,   145,    41,    41,
     115,    43,   119,    72,   115,    43,   148,   154,   144,   117,
     119,   143,    42,   148,    43,    43,   119,   157,   115,    43,
      45,    85,   154,   119,   148,   148,    43,   154,   148,   115,
      45,    71,    43,   148,    72,   154,   148,   115,    72,   115,
      12,   116,   157,   115,   154,   148,    43,   115,   148
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    94,    95,    95,    96,    96,    97,    97,    98,    98,
      99,    99,    99,    99,    99,    99,   100,   100,   100,   100,
     100,   100,   100,   100,   100,   100,   101,   101,   102,   102,
     102,   102,   102,   102,   103,   103,   103,   103,   103,   103,
     104,   104,   105,   105,   105,   105,   106,   106,   106,   107,
     107,   107,   108,   108,   108,   108,   108,   109,   109,   109,
     110,   110,   111,   111,   112,   112,   113,   113,   114,   114,
     115,   116,   116,   117,   117,   118,   118,   118,   118,   118,
     118,   118,   118,   118,   118,   118,   119,   119,   120,   121,
     121,   122,   122,   122,   122,   122,   122,   122,   122,   123,
     123,   124,   124,   125,   125,   125,   125,   126,   126,   126,
     126,   126,   126,   126,   126,   126,   126,   126,   126,   126,
     127,   127,   127,   127,   128,   128,   128,   128,   128,   129,
     129,   130,   130,   131,   132,   132,   132,   133,   134,   134,
     135,   135,   135,   135,   135,   135,   135,   135,   135,   135,
     135,   135,   135,   135,   136,   136,   136,   136,   137,   137,
     138,   138,   139,   139,   140,   140,   141,   141,   142,   143,
     143,   143,   144,   144,   144,   144,   145,   146,   146,   147,
     147,   148,   148,   148,   148,   148,   148,   149,   149,   149,
     150,   150,   151,   151,   152,   152,   153,   153,   154,   155,
     155,   155,   156,   156,   156,   156,   156,   156,   156,   157,
     157,   158,   158,   158,   158,   158
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     2,     1,     1,     3,     4,     1,     2,
       1,     1,     1,     1,     1,     3,     1,     4,     3,     4,
       3,     3,     2,     2,     6,     7,     1,     3,     1,     2,
       2,     2,     2,     4,     1,     1,     1,     1,     1,     1,
       1,     4,     1,     3,     3,     3,     1,     3,     3,     1,
       3,     3,     1,     3,     3,     3,     3,     1,     3,     3,
       1,     3,     1,     3,     1,     3,     1,     4,     1,     4,
       0,     1,     9,     1,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     3,     1,     2,
       3,     1,     2,     1,     2,     1,     2,     1,     2,     1,
       3,     1,     3,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     1,     2,     4,     5,     5,     6,     2,     1,
       3,     1,     3,     1,     1,     1,     1,     1,     1,     2,
       1,     3,     3,     4,     4,     5,     5,     6,     6,     4,
       5,     4,     3,     4,     1,     2,     2,     3,     1,     2,
       1,     3,     1,     3,     2,     1,     1,     3,     1,     1,
       3,     4,     1,     2,     3,     4,     2,     1,     2,     3,
       2,     1,     1,     1,     1,     1,     1,     3,     4,     3,
       2,     3,     1,     3,     1,     1,     1,     2,     0,     8,
      11,     5,     8,     9,    14,     6,     7,     7,     8,     0,
       1,     3,     2,     2,     2,     3
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 197 "ass6_14CS10060.y" /* yacc.c:1646  */
    {

          }
#line 1904 "y.tab.c" /* yacc.c:1646  */
    break;

  case 3:
#line 200 "ass6_14CS10060.y" /* yacc.c:1646  */
    {

          }
#line 1912 "y.tab.c" /* yacc.c:1646  */
    break;

  case 6:
#line 210 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //if the return type is not a pointer, then enter ret_val into the symboltable.

              if(((yyvsp[-1].expression_attr)._type_ == NULL || !strcmp((yyvsp[-1].expression_attr)._type_->variable_data_type,"function"))){
                char str[] = "ret_val";

                (yyvsp[-1].expression_attr).symbol_table_->insert(str,(yyvsp[-2].expression_attr)._type_,(yyvsp[-2].expression_attr).width);
              }
		 
		
                            //if return type is a pointer, then update the type of return value obtained from declaration_specifiers and declarator
              //and insert ret_val into the symboltable.
              else {
                _type* t;
                t = (yyvsp[-2].expression_attr)._type_;
                while(t->_next_ != NULL){
                 t = t->_next_;
                }
                t->_next_ = (yyvsp[-1].expression_attr)._type_;
                char str[] = "ret_val";
                (yyvsp[-1].expression_attr).symbol_table_->insert(str,(yyvsp[-2].expression_attr)._type_,4);
              }         
              //change current symboltable to global symboltable as function scope has finished.
              current_symb_table = Global_symb_table; 
              if((yyvsp[0].expression_attr).nextlist != NULL){
                backpatch((yyvsp[0].expression_attr).nextlist,nextinstr);
              }    
              flag_return_type = 0;
              return_width = 0;
              emit(_FUNCTION_END,(yyvsp[-1].expression_attr).string_text);
          }
#line 1948 "y.tab.c" /* yacc.c:1646  */
    break;

  case 7:
#line 241 "ass6_14CS10060.y" /* yacc.c:1646  */
    {

                //if the return type is not a pointer, then enter ret_val into the symboltable.

              if((yyvsp[-2].expression_attr)._type_ == NULL || !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"function"))
              {
                char str[] = "ret_val";

                (yyvsp[-2].expression_attr).symbol_table_->insert(str,(yyvsp[-3].expression_attr)._type_,(yyvsp[-3].expression_attr).width);
                //printf("%s\n",str);

              }
                  //if return type is a pointer, then update the type of return value obtained from declaration_specifiers and declarator
              //and insert ret_val into the symboltable.
                          
              else {
                _type* t;
                t = (yyvsp[-3].expression_attr)._type_;
                while(t->_next_ != NULL){
                 t = t->_next_;
                }
                t->_next_ = (yyvsp[-2].expression_attr)._type_;
                char str[] = "ret_val";
                (yyvsp[-2].expression_attr).symbol_table_->insert(str,(yyvsp[-3].expression_attr)._type_,4);

              }     
              //change current symboltable to global symboltable as function scope has finished.
              current_symb_table = Global_symb_table; 
              if((yyvsp[0].expression_attr).nextlist != NULL){
                backpatch((yyvsp[0].expression_attr).nextlist,nextinstr);
              }
              flag_return_type = 0; 
              return_width = 0;
              emit(_FUNCTION_END,(yyvsp[-2].expression_attr).string_text);
          }
#line 1988 "y.tab.c" /* yacc.c:1646  */
    break;

  case 10:
#line 282 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr).string_text = strdup((yyvsp[0].string_text));  
              (yyval.expression_attr).int_val = 0;
              (yyval.expression_attr).loc = NULL;
              (yyval.expression_attr).array = NULL;
              (yyval.expression_attr).pointer = NULL;
              (yyval.expression_attr).truelist = NULL;
              (yyval.expression_attr).falselist = NULL;
              (yyval.expression_attr).is_l_val = 0;
              (yyval.expression_attr).double_val = 0;
              (yyval.expression_attr).char_val = NULL;
              (yyval.expression_attr).is_pointer_type = 0;
          }
#line 2006 "y.tab.c" /* yacc.c:1646  */
    break;

  case 11:
#line 295 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //create a temporary and emit temporary assigned integer_constant and update the type and width attributes.
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              _type* t = new _type;
              t->variable_data_type = strdup("int");
              t->_next_ = NULL;
              current_symb_table->update((yyval.expression_attr).loc,t,4,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + 4;
              (yyval.expression_attr)._type_ = t;
              (yyval.expression_attr).width = 4;
              emit((yyval.expression_attr).loc->_name_,(yyvsp[0].int_val));
              (yyval.expression_attr).int_val = (yyvsp[0].int_val);
              (yyval.expression_attr).truelist = NULL;
              (yyval.expression_attr).falselist = NULL;
              (yyval.expression_attr).string_text = strdup((yyval.expression_attr).loc->_name_);
              (yyval.expression_attr).is_l_val = 1;
              (yyval.expression_attr).is_pointer_type = 0;
          }
#line 2029 "y.tab.c" /* yacc.c:1646  */
    break;

  case 12:
#line 313 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //create a temporary and emit temporary assigned floating_constant and update the type and width attributes.
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              _type* t = new _type;
              t->variable_data_type = strdup("double");
              t->_next_ = NULL;
              current_symb_table->update((yyval.expression_attr).loc,t,8,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + 8;
              (yyval.expression_attr)._type_ = t;
              (yyval.expression_attr).width = 8;
              emit((yyval.expression_attr).loc->_name_,(yyvsp[0].double_val));
              (yyval.expression_attr).double_val = (yyvsp[0].double_val);
              (yyval.expression_attr).truelist = NULL;
              (yyval.expression_attr).falselist = NULL;
              (yyval.expression_attr).int_val = 0;
              (yyval.expression_attr).string_text = strdup((yyval.expression_attr).loc->_name_);
              (yyval.expression_attr).is_l_val = 1;
              (yyval.expression_attr).is_pointer_type = 0;
          }
#line 2053 "y.tab.c" /* yacc.c:1646  */
    break;

  case 13:
#line 332 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //create a temporary and emit temporary assigned character_constant and update the type and width attributes.
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              _type* t = new _type;
              t->variable_data_type = strdup("char");
              t->_next_ = NULL;
              current_symb_table->update((yyval.expression_attr).loc,t,1,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + 1;
              (yyval.expression_attr)._type_ = t;
              (yyval.expression_attr).width = 1;
              emit((yyval.expression_attr).loc->_name_,(yyvsp[0].string_text));
              (yyval.expression_attr).int_val = 0;
              (yyval.expression_attr).truelist = NULL;
              (yyval.expression_attr).falselist = NULL;
              (yyval.expression_attr).string_text = strdup((yyval.expression_attr).loc->_name_);
              (yyval.expression_attr).is_l_val = 1;
              (yyval.expression_attr).char_val = strdup((yyvsp[0].string_text));
              (yyval.expression_attr).is_pointer_type = 0;
          }
#line 2077 "y.tab.c" /* yacc.c:1646  */
    break;

  case 14:
#line 351 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //create a variable and emit variable assigned string_literal and update the type and width attributes.
              char* s = current_symb_table->generate_constant_label((yyvsp[0].string_text));
              (yyval.expression_attr).loc = current_symb_table->lookup(s);
              _type* t = new _type;
              t->variable_data_type = strdup("ptr");
              t->_next_ = new _type;
              t->_next_->variable_data_type = strdup("char");
              t->_next_->_next_ = NULL;
              (yyval.expression_attr)._type_ = t;
              current_symb_table->update((yyval.expression_attr).loc,t,8,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + 8;
              (yyval.expression_attr).int_val = 0;
              (yyval.expression_attr).string_text = strdup((yyval.expression_attr).loc->_name_);
              (yyval.expression_attr).is_l_val = 1;
              (yyval.expression_attr).char_val = strdup((yyvsp[0].string_text));
              (yyval.expression_attr).truelist = NULL;
              (yyval.expression_attr).falselist = NULL;
              (yyval.expression_attr).is_pointer_type = 0;
          }
#line 2102 "y.tab.c" /* yacc.c:1646  */
    break;

  case 15:
#line 371 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //Assign the attributes of parameter expression as expression.
              (yyval.expression_attr) = (yyvsp[-1].expression_attr);
              _list* l = (yyvsp[-1].expression_attr).falselist;
              if(l != NULL){
                (yyval.expression_attr).falselist = new _list;
                _list* l2 = (yyval.expression_attr).falselist;
                for(;l->_next_ != NULL;){
                  l2->_index_ = l->_index_;
                  l2->_next_ = new _list;
                  l2 = l2->_next_;
                  l = l->_next_;
                }
                l2->_index_ = l->_index_;
                l2->_next_ = NULL;
              }
              else {
                (yyval.expression_attr).falselist = NULL;
              }
              _list* l1 = (yyvsp[-1].expression_attr).truelist;
              if(l1 != NULL){
                (yyval.expression_attr).truelist = new _list;
                _list* l2 = (yyval.expression_attr).truelist;
                for(;l1->_next_ != NULL;){
                  l2->_index_ = l1->_index_;
                  l2->_next_ = new _list;
                  l2 = l2->_next_;
                  l1 = l1->_next_;
                }
                l2->_index_ = l1->_index_;
                l2->_next_ = NULL;
              } 
              else {
                (yyval.expression_attr).truelist = NULL;
              }
          }
#line 2143 "y.tab.c" /* yacc.c:1646  */
    break;

  case 16:
#line 409 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
              (yyval.expression_attr).array = NULL;
              (yyval.expression_attr).is_array_id = 0;
          }
#line 2153 "y.tab.c" /* yacc.c:1646  */
    break;

  case 17:
#line 414 "ass6_14CS10060.y" /* yacc.c:1646  */
    { 
        	    //If it is the first dimension of array, then get the array from the symboltable entry.
              if((yyvsp[-3].expression_attr).array == NULL){
                (yyvsp[-3].expression_attr).loc = current_symb_table->lookup((yyvsp[-3].expression_attr).string_text);
                /*int flag8=0;
                if($1.loc == NULL && current_symb_table!=Global_symb_table)
                {
                  $1.loc = Global_symb_table->lookup_check($1.string_text);
                  if($1.loc!=NULL)
                  flag8=1;

                }
                if(flag8==1)
                $1.loc = Global_symb_table->lookup($1.string_text);
                else
                $1.loc = current_symb_table->lookup($1.string_text);
                */
                (yyvsp[-3].expression_attr)._type_ = obtain_data_type((yyvsp[-3].expression_attr).loc);
                (yyvsp[-3].expression_attr).width = getwidth((yyvsp[-3].expression_attr).loc);
                (yyvsp[-3].expression_attr).array = (yyvsp[-3].expression_attr).loc;
              }
              (yyval.expression_attr).array = (yyvsp[-3].expression_attr).array;
              //If the expression variable has not been declared then print error message.
              if((yyvsp[-1].expression_attr)._type_ == NULL){
                char str[] = "Identifier not declared at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              }
              //Array indices cannot be negative.
              if((yyvsp[-1].expression_attr).int_val < 0){
                char s[] = "Array index cannot be negative at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1);   
              }
              //If the expression which is array index is boolean or char, convert it into integer.
              if(!strcmp((yyvsp[-1].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-1].expression_attr)));
              }
              if(!strcmp((yyvsp[-1].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[-1].expression_attr)));
              }
              //Only integer/character or boolean expressions allowed as indices of an array.
              if(strcmp((yyvsp[-1].expression_attr)._type_->variable_data_type,"int")){
                char s[] = "Array indices should be an integer at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1);
              }
              if((yyvsp[-3].expression_attr)._type_ == NULL){
                char s[] = "Array not declared before at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1);
              }
              else if(!strcmp((yyvsp[-3].expression_attr)._type_->variable_data_type,"ptr")){
                 if(!strcmp((yyvsp[-3].expression_attr)._type_->_next_->variable_data_type,"int")){
                    (yyval.expression_attr).width = 4;
                 }
                 else if(!strcmp((yyvsp[-3].expression_attr)._type_->_next_->variable_data_type,"char")){
                    (yyval.expression_attr).width = 1;
                 } 
                 else if(!strcmp((yyvsp[-3].expression_attr)._type_->_next_->variable_data_type,"double")){
                    (yyval.expression_attr).width = 4;
                 }
              }
              //If the array has not been declared then print error message.
              else if(strcmp((yyvsp[-3].expression_attr)._type_->variable_data_type,"array")){
                char s[] = "Array not declared before at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1);
              }
              if((yyvsp[-3].expression_attr)._type_->size == 0 && strcmp((yyvsp[-3].expression_attr)._type_->_next_->variable_data_type,"array")){
                if(!strcmp((yyvsp[-3].expression_attr)._type_->_next_->variable_data_type,"int")){
                    (yyval.expression_attr).width = 4;
                 }
                 else if(!strcmp((yyvsp[-3].expression_attr)._type_->_next_->variable_data_type,"char")){
                    (yyval.expression_attr).width = 1;
                 } 
                 else if(!strcmp((yyvsp[-3].expression_attr)._type_->_next_->variable_data_type,"double")){
                    (yyval.expression_attr).width = 4;
                 }
              }
              else if((yyvsp[-3].expression_attr)._type_->size == 0 && !strcmp((yyvsp[-3].expression_attr)._type_->_next_->variable_data_type,"array")){
                char s[] = "Array size not declared before at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1);
              }
              else {
                //Calculate new size of the array after indexing.
                (yyval.expression_attr).width = (yyvsp[-3].expression_attr).width / ((yyvsp[-3].expression_attr)._type_->size);
              }  
		
              //If its not the first dimension of the array, then generate a temporary and store the index of the array which is 
              //sum of the previous dimension of array's width and the product of the expression's integer value and width of array.
             
              if((yyvsp[-3].expression_attr).is_array_id != 0){
                (yyval.expression_attr).loc = current_symb_table->gentemp();
                symb_table* temp;
                temp = current_symb_table->gentemp();
                _type t;
                t.variable_data_type = strdup("int");
                t._next_ = NULL;
                current_symb_table->update((yyval.expression_attr).loc,&t,4,current_symb_table->offset);
                current_symb_table->offset = current_symb_table->offset + 4;
                current_symb_table->update(temp,&t,4,current_symb_table->offset);
                current_symb_table->offset = current_symb_table->offset + 4;
                char s1[65];
                sprintf(s1,"%d",(yyval.expression_attr).width);
                emit(temp->_name_,(yyvsp[-1].expression_attr).loc->_name_,_PRODUCT,s1);
                emit((yyval.expression_attr).loc->_name_,(yyvsp[-3].expression_attr).loc->_name_,_ADD,temp->_name_);
              } 
		//If its the first dimension of array,then generate a temporary and store the index of the array which is product
              //of expression's integer value and the width of the array.
              else{
                (yyval.expression_attr).loc = current_symb_table->gentemp();
                _type t;
                t.variable_data_type = strdup("int");
                t._next_ = NULL;
                current_symb_table->update((yyval.expression_attr).loc,&t,4,current_symb_table->offset);
                current_symb_table->offset = current_symb_table->offset + 4;
                char s5[65];
                sprintf(s5,"%d",(yyval.expression_attr).width);
                emit((yyval.expression_attr).loc->_name_,(yyvsp[-1].expression_attr).loc->_name_,_PRODUCT,s5);
              } 
              //Assign the new type after array indexing.
              (yyval.expression_attr)._type_ = (yyvsp[-3].expression_attr)._type_->_next_;
              (yyval.expression_attr).is_array_id = 1;
              (yyval.expression_attr).is_l_val = 0;
          }
#line 2303 "y.tab.c" /* yacc.c:1646  */
    break;

  case 18:
#line 559 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //Get the function symboltable entry by looking up in the Global Symboltable.
              (yyvsp[-2].expression_attr).loc = Global_symb_table->lookup((yyvsp[-2].expression_attr).string_text);
              (yyvsp[-2].expression_attr)._type_ = obtain_data_type((yyvsp[-2].expression_attr).loc);
              symboltable* symbol_table = (yyvsp[-2].expression_attr).loc->_nested_table_;
              //If the function has not been declared then the nested table entry will be NULL, print error message.
              if(symbol_table == NULL){
                char s[] = "Function has not been defined at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1); 
              }
              //Get the return value type from the symbol table of the function.
              //Create a new temporary variable for storing the return value after the function call.
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              current_symb_table->update((yyval.expression_attr).loc,return_type,return_width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + return_width;
              _type *p,*q;
              //Equate the type of return variable as the type of temporary variable.
              (yyval.expression_attr)._type_ = new _type;
              p = (yyval.expression_attr)._type_;
              q = return_type;
              while(q->_next_ != NULL){
                p->variable_data_type = strdup(q->variable_data_type);
                p->size = q->size;
                p->_next_ = new _type;
                q = q->_next_;
                p = p->_next_;
              }
              p->variable_data_type = strdup(q->variable_data_type);
              p->size = q->size;
              p->_next_ = NULL;          
              (yyval.expression_attr).width = return_width;
              char s2[2];
              sprintf(s2,"0");
              //Call the function and store the return value in the temporary variable.
              emit((yyval.expression_attr).loc->_name_,(yyvsp[-2].expression_attr).loc->_name_,_CALL,s2);
              (yyval.expression_attr).is_l_val = 1;
          }
#line 2349 "y.tab.c" /* yacc.c:1646  */
    break;

  case 19:
#line 600 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //Get the function symboltable entry by looking up in the Global Symboltable.
              (yyvsp[-3].expression_attr).loc = Global_symb_table->lookup((yyvsp[-3].expression_attr).string_text);
              (yyvsp[-3].expression_attr)._type_ = obtain_data_type((yyvsp[-3].expression_attr).loc);
              symboltable* symbol_table = (yyvsp[-3].expression_attr).loc->_nested_table_;
              //If the function has not been declared then the nested table entry will be NULL, print error message.
              if(symbol_table == NULL){
                char s[] = "Function has not been defined at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1); 
              }
              //If the number of parameters between declaration and function call are different, print an error message.
              if((yyvsp[-3].expression_attr).loc->num_params != (yyvsp[-1].expression_attr).num_params){
                char s[] = "Mismatch in number of parameters at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1);               
              }
              int i;
              function_list* f = (yyvsp[-1].expression_attr).parameter_list;
              //For each parameter in the function call, check if it's type matches with the parameter in the function declaration. 
              for(i = 0;i < (yyvsp[-1].expression_attr).num_params;i++){
                  _type* t1 = symbol_table->_symboltable_[i]._type_;
                  if(!strcmp(symbol_table->_symboltable_[i]._name_,"ret_val")){
                    char s[] = "More function parameters than expected at line ";
                    char temporary_string[50];
                    sprintf(temporary_string,"%d",line_num);
                    strcat(s,temporary_string);
                    yyerror(s);
                    exit(1);
                  }
                  _type* t2 = f->_type_;
                  //Check if the implicit type conversion between parameter in the function call and the parameter in the 
                  //function declaration is possible or not. If possible, do the conversion.
                  //Implicit type conversion is implemented for fundamental datatypes.
                  if(t1->_next_ == NULL && t2->_next_ == NULL){
                    if(!strcmp(t1->variable_data_type,"char")){
                      if(!strcmp(t2->variable_data_type,"int")){
                        symb_table* temp = current_symb_table->gentemp();
                        t2->variable_data_type = strdup("char");                        
                        current_symb_table->update(temp,t2,1,current_symb_table->offset);
                        current_symb_table->offset = current_symb_table->offset + 1;
                        emit(temp->_name_,f->loc->_name_,_INT_TO_CHAR);
                        f->loc = temp;
                        f->width = 1;
                      }
                      else if(!strcmp(t2->variable_data_type,"double")){
                        symb_table* temp = current_symb_table->gentemp();
                        t2->variable_data_type = strdup("int");                        
                        current_symb_table->update(temp,t2,4,current_symb_table->offset);
                        current_symb_table->offset = current_symb_table->offset + 4;
                        emit(temp->_name_,f->loc->_name_,_DOUBLE_TO_INT);
                        f->loc = temp;
                        temp = current_symb_table->gentemp();
                        t2->variable_data_type = strdup("char");                        
                        current_symb_table->update(temp,t2,1,current_symb_table->offset);
                        current_symb_table->offset = current_symb_table->offset + 1;
                        emit(temp->_name_,f->loc->_name_,_INT_TO_CHAR);
                        f->loc = temp;
                        f->width = 1;
                      }
                    }
                    else if(!strcmp(t1->variable_data_type,"int")){
                      if(!strcmp(t2->variable_data_type,"char")){
                        symb_table* temp = current_symb_table->gentemp();
                        t2->variable_data_type = strdup("int");                        
                        current_symb_table->update(temp,t2,4,current_symb_table->offset);
                        current_symb_table->offset = current_symb_table->offset + 4;
                        emit(temp->_name_,f->loc->_name_,_CHAR_TO_INT);
                        f->loc = temp;
                        f->width = 4;
                      }
                      else if(!strcmp(t2->variable_data_type,"double")){
                        symb_table* temp = current_symb_table->gentemp();
                        t2->variable_data_type = strdup("int");                        
                        current_symb_table->update(temp,t2,4,current_symb_table->offset);
                        current_symb_table->offset = current_symb_table->offset + 4;
                        emit(temp->_name_,f->loc->_name_,_DOUBLE_TO_INT);
                        f->loc = temp;
                        f->width = 8;
                      }
                    }
                    else if(!strcmp(t1->variable_data_type,"double")){
                      if(!strcmp(t2->variable_data_type,"int")){
                        symb_table* temp = current_symb_table->gentemp();
                        t2->variable_data_type = strdup("double");                        
                        current_symb_table->update(temp,t2,8,current_symb_table->offset);
                        current_symb_table->offset = current_symb_table->offset + 8;
                        emit(temp->_name_,f->loc->_name_,_INT_TO_DOUBLE);
                        f->loc = temp;
                        f->width = 4;
                      }
                      else if(!strcmp(t2->variable_data_type,"char")){
                        symb_table* temp = current_symb_table->gentemp();
                        t2->variable_data_type = strdup("int");                        
                        current_symb_table->update(temp,t2,4,current_symb_table->offset);
                        current_symb_table->offset = current_symb_table->offset + 4;
                        emit(temp->_name_,f->loc->_name_,_CHAR_TO_INT);
                        f->loc = temp;
                        temp = current_symb_table->gentemp();
                        t2->variable_data_type = strdup("double");                        
                        current_symb_table->update(temp,t2,8,current_symb_table->offset);
                        current_symb_table->offset = current_symb_table->offset + 8;
                        emit(temp->_name_,f->loc->_name_,_INT_TO_DOUBLE);
                        f->loc = temp;
                        f->width = 8;
                      }
                    }
                  }
                  //Check if the function parameter types are same or not after implicit type conversion.
                  for(;t1 != NULL && t2 != NULL;){
                    if((!strcmp(t1->variable_data_type,"ptr") && !strcmp(t2->variable_data_type,"array")) || (!strcmp(t1->variable_data_type,"array") && !strcmp(t2->variable_data_type,"ptr"))){

                    }
                    else if(strcmp(t1->variable_data_type,t2->variable_data_type)){
                      char s[] = "Function parameters type mismatch at line ";
                      char temporary_string[50];
                      sprintf(temporary_string,"%d",line_num);
                      strcat(s,temporary_string);
                      yyerror(s);
                      exit(1);
                    }
                    t1 = t1->_next_;
                    t2 = t2->_next_;
                  }
                  //If the types are not same, print error message.
                  if(t1 != NULL || t2 != NULL){
                    char s[] = "Function parameters type mismatch at line ";
                    char temporary_string[50];
                    sprintf(temporary_string,"%d",line_num);
                    strcat(s,temporary_string);
                    yyerror(s);
                    exit(1);
                  }
                  //If this parameter has same type as function declaration then emit this as a parameter of the function.
                  emit(_PARAM,f->loc->_name_);
                  //Check for next parameter.
                  f = f->_next_;
              }
              //Get the return value type from the symbol table of the function.
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              current_symb_table->update((yyval.expression_attr).loc,return_type,return_width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + return_width;
              //Equate the type of return variable as the type of temporary variable.
              _type *p,*q;
              (yyval.expression_attr)._type_ = new _type;
              p = (yyval.expression_attr)._type_;
              q = return_type;
              while(q->_next_ != NULL){
                p->variable_data_type = strdup(q->variable_data_type);
                p->_next_ = new _type;
                q = q->_next_;
                p = p->_next_;
              }
              p->variable_data_type = strdup(q->variable_data_type);
              p->_next_ = NULL;          
              (yyval.expression_attr).width = return_width;
              char s3[33];
              sprintf(s3,"%d",(yyvsp[-1].expression_attr).num_params);
              //Call the function and store the return value in the temporary variable.
              emit((yyval.expression_attr).loc->_name_,(yyvsp[-3].expression_attr).loc->_name_,_CALL,s3);
              (yyval.expression_attr).is_l_val = 1;   
          }
#line 2522 "y.tab.c" /* yacc.c:1646  */
    break;

  case 22:
#line 770 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             //If it is a l-value then this operation is valid else it is invalid.
             char *strr;
             if((yyvsp[-1].expression_attr).is_l_val == 0){
               (yyval.expression_attr) = (yyvsp[-1].expression_attr);
               //Get the variable from the symboltable.
               if((yyvsp[-1].expression_attr).is_array_id != 1){
                (yyvsp[-1].expression_attr).loc = current_symb_table->lookup((yyvsp[-1].expression_attr).string_text);
                /*int flag8=0;
                if($1.loc == NULL && current_symb_table!=Global_symb_table)
                {
                  $1.loc = Global_symb_table->lookup_check($1.string_text);
                  if($1.loc!=NULL)
                  {flag8=1;
                  }


                }
                if(flag8==1)
                $1.loc = Global_symb_table->lookup($1.string_text);
                else
                  $1.loc = current_symb_table->lookup($1.string_text);
                  */
                  (yyvsp[-1].expression_attr)._type_ = obtain_data_type((yyvsp[-1].expression_attr).loc);
                  (yyvsp[-1].expression_attr).width = getwidth((yyvsp[-1].expression_attr).loc);
               }   
               else {
                  symb_table* temp = current_symb_table->gentemp();
                  strr = strdup((yyvsp[-1].expression_attr).loc->_name_);
                  emit(temp->_name_,(yyvsp[-1].expression_attr).array->_name_,_ARRAY_DEREFERENCE,(yyvsp[-1].expression_attr).loc->_name_);
                  (yyvsp[-1].expression_attr).loc = temp;
                  current_symb_table->update((yyvsp[-1].expression_attr).loc,(yyvsp[-1].expression_attr)._type_,(yyvsp[-1].expression_attr).width,current_symb_table->offset);
                  current_symb_table->offset = current_symb_table->offset + (yyvsp[-1].expression_attr).width;
               }
               (yyval.expression_attr).loc = current_symb_table->gentemp();
               if((yyvsp[-1].expression_attr)._type_ == NULL){
                 char str[] = "Identifier not declared at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(str,temporary_string);
                 yyerror(str);
                 exit(1);
               }
               //If it is a boolean type, then convert into int.
               if((yyvsp[-1].expression_attr)._type_ != NULL && !strcmp((yyvsp[-1].expression_attr)._type_->variable_data_type,"bool")){
                  convert_bool_to_int(&((yyvsp[-1].expression_attr)));
               }
               //Assign this value to a temporary variable and then increment the value of the variable.
               current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-1].expression_attr)._type_,(yyvsp[-1].expression_attr).width,current_symb_table->offset);
               current_symb_table->offset = current_symb_table->offset + (yyvsp[-1].expression_attr).width;
               emit((yyval.expression_attr).loc->_name_,(yyvsp[-1].expression_attr).loc->_name_);
               emit(_INCREMENT,(yyvsp[-1].expression_attr).loc->_name_);
               if((yyvsp[-1].expression_attr).is_array_id == 1){
                  emit((yyvsp[-1].expression_attr).array->_name_,strr,_ARRAY_ACCESS,(yyvsp[-1].expression_attr).loc->_name_);
                  (yyvsp[-1].expression_attr).is_array_id = 0;
               }
               (yyval.expression_attr).is_array_id = 0;
               (yyval.expression_attr)._type_ = (yyvsp[-1].expression_attr)._type_;
               (yyval.expression_attr).width = (yyvsp[-1].expression_attr).width;
               (yyval.expression_attr).int_val = (yyvsp[-1].expression_attr).int_val;
               (yyval.expression_attr).is_l_val = 1;
               (yyval.expression_attr).is_array_id = 0;
            } 
            else {
                 char str[] = "Invalid operation at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(str,temporary_string);
                 yyerror(str);
                 exit(1);
             }  
          }
#line 2599 "y.tab.c" /* yacc.c:1646  */
    break;

  case 23:
#line 842 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             //If it is a l-value then this operation is valid else it is invalid.
             char *strr;
             if((yyvsp[-1].expression_attr).is_l_val == 0){
               (yyval.expression_attr) = (yyvsp[-1].expression_attr);
               //Get the variable from the symboltable.
               if((yyvsp[-1].expression_attr).is_array_id != 1){
                (yyvsp[-1].expression_attr).loc = current_symb_table->lookup((yyvsp[-1].expression_attr).string_text);
                /*int flag8=0;
                if($1.loc == NULL && current_symb_table!=Global_symb_table)
                {
                  $1.loc = Global_symb_table->lookup_check($1.string_text);
                  if($1.loc!=NULL)
                  flag8=1;

                }
                if(flag8==1)
                $1.loc = Global_symb_table->lookup($1.string_text);
                else
                  $1.loc = current_symb_table->lookup($1.string_text);
                  */
                  (yyvsp[-1].expression_attr)._type_ = obtain_data_type((yyvsp[-1].expression_attr).loc);
                  (yyvsp[-1].expression_attr).width = getwidth((yyvsp[-1].expression_attr).loc);
               }   
               else {
                  symb_table* temp = current_symb_table->gentemp();
                  strr = strdup((yyvsp[-1].expression_attr).loc->_name_);
                  emit(temp->_name_,(yyvsp[-1].expression_attr).array->_name_,_ARRAY_DEREFERENCE,(yyvsp[-1].expression_attr).loc->_name_);
                  (yyvsp[-1].expression_attr).loc = temp;
                  current_symb_table->update((yyvsp[-1].expression_attr).loc,(yyvsp[-1].expression_attr)._type_,(yyvsp[-1].expression_attr).width,current_symb_table->offset);
                  current_symb_table->offset = current_symb_table->offset + (yyvsp[-1].expression_attr).width;
               }
               (yyval.expression_attr).loc = current_symb_table->gentemp();
               if((yyvsp[-1].expression_attr)._type_ == NULL){
                 char str[] = "Identifier not declared at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(str,temporary_string);
                 yyerror(str);
                 exit(1);
               }
               //If it is a boolean type, then convert into int.
               if((yyvsp[-1].expression_attr)._type_ != NULL && !strcmp((yyvsp[-1].expression_attr)._type_->variable_data_type,"bool")){
                  convert_bool_to_int(&((yyvsp[-1].expression_attr)));
               }
               current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-1].expression_attr)._type_,(yyvsp[-1].expression_attr).width,current_symb_table->offset);
               current_symb_table->offset = current_symb_table->offset + (yyvsp[-1].expression_attr).width;
               //Assign this value to a temporary variable and then decrement the value of the variable.
               emit((yyval.expression_attr).loc->_name_,(yyvsp[-1].expression_attr).loc->_name_);
               emit(_DECREMENT,(yyvsp[-1].expression_attr).loc->_name_);
               if((yyvsp[-1].expression_attr).is_array_id == 1){
                  emit((yyvsp[-1].expression_attr).array->_name_,strr,_ARRAY_ACCESS,(yyvsp[-1].expression_attr).loc->_name_);
                  (yyvsp[-1].expression_attr).is_array_id = 0;
                  (yyval.expression_attr).is_array_id = 0;
               }
               (yyval.expression_attr)._type_ = (yyvsp[-1].expression_attr)._type_;
               (yyval.expression_attr).width = (yyvsp[-1].expression_attr).width;
               (yyval.expression_attr).int_val = (yyvsp[-1].expression_attr).int_val;
               (yyval.expression_attr).is_l_val = 1;
             }
             else {
                 char str[] = "Invalid operation at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(str,temporary_string);
                 yyerror(str);
                 exit(1);
             }  
          }
#line 2673 "y.tab.c" /* yacc.c:1646  */
    break;

  case 26:
#line 915 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             (yyval.expression_attr) = (yyvsp[0].expression_attr);
             if((yyvsp[0].expression_attr)._type_ == NULL){
                char str[] = "Parameter variable not declared at line "; 
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
             }
             //If the parameter is a boolean expression convert it into an integer expression.
             if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
               convert_bool_to_int(&((yyvsp[0].expression_attr)));
             }
             //Add this parameter to the parameter list of the function.
             (yyval.expression_attr).parameter_list = make_function_list((yyvsp[0].expression_attr).loc,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width);
             (yyval.expression_attr).num_params = 1;
          }
#line 2696 "y.tab.c" /* yacc.c:1646  */
    break;

  case 27:
#line 933 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             (yyval.expression_attr) = (yyvsp[0].expression_attr);
             if((yyvsp[0].expression_attr)._type_ == NULL){
                char str[] = "Parameter variable not declared at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
             }
             //If the parameter is a boolean expression convert it into an integer expression.           
             if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
               convert_bool_to_int(&((yyvsp[0].expression_attr)));
             }
             //Add this parameter to the parameter list of the function.
             (yyval.expression_attr).parameter_list = merge_function_list((yyvsp[-2].expression_attr).parameter_list,make_function_list((yyvsp[0].expression_attr).loc,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width));
             (yyval.expression_attr).num_params = (yyvsp[-2].expression_attr).num_params + 1;
          }
#line 2719 "y.tab.c" /* yacc.c:1646  */
    break;

  case 28:
#line 953 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //If the variable has not been obtained from symboltable, then obtain the symboltable entry for the variable.
              if((yyvsp[0].expression_attr).loc == NULL){
               (yyvsp[0].expression_attr).loc = current_symb_table->lookup((yyvsp[0].expression_attr).string_text);
                /*int flag8=0;
                if($1.loc == NULL && current_symb_table!=Global_symb_table)
                {
                  $1.loc = Global_symb_table->lookup_check($1.string_text);
                  if($1.loc!=NULL)
                  {flag8=1;
                   }

                }
                if(flag8==1)
                $1.loc = Global_symb_table->lookup($1.string_text);
                else
                $1.loc = current_symb_table->lookup($1.string_text);
                */
                (yyvsp[0].expression_attr)._type_ = obtain_data_type((yyvsp[0].expression_attr).loc);
                (yyvsp[0].expression_attr).width = getwidth((yyvsp[0].expression_attr).loc);
              }
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 2747 "y.tab.c" /* yacc.c:1646  */
    break;

  case 29:
#line 976 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             //If it is a l-value then this operation is valid else it is invalid.
             char* strr;
             if((yyvsp[0].expression_attr).is_l_val == 0){
               (yyval.expression_attr) = (yyvsp[0].expression_attr);
               (yyval.expression_attr).loc = current_symb_table->gentemp();
               if((yyvsp[0].expression_attr).is_array_id == 1){
                 symb_table* temp = current_symb_table->gentemp();
                 strr = strdup((yyvsp[0].expression_attr).loc->_name_);
                 emit(temp->_name_,(yyvsp[0].expression_attr).array->_name_,_ARRAY_DEREFERENCE,(yyvsp[0].expression_attr).loc->_name_);
                 (yyvsp[0].expression_attr).loc = temp;
                 current_symb_table->update((yyvsp[0].expression_attr).loc,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width,current_symb_table->offset);
                 current_symb_table->offset = current_symb_table->offset + (yyvsp[0].expression_attr).width;
               }
               if((yyvsp[0].expression_attr)._type_ == NULL){
                 char str[] = "Identifier not declared at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(str,temporary_string);
                 yyerror(str);
                 exit(1);
               }
               //If it is a boolean type, then convert into int.
               if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                 convert_bool_to_int(&((yyvsp[0].expression_attr)));
               } 
               current_symb_table->update((yyval.expression_attr).loc,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width,current_symb_table->offset);
               current_symb_table->offset = current_symb_table->offset + (yyvsp[0].expression_attr).width;
               //Increment the value of the variable and then assign this value to a temporary variable.
               emit(_INCREMENT,(yyvsp[0].expression_attr).loc->_name_);
               emit((yyval.expression_attr).loc->_name_,(yyvsp[0].expression_attr).loc->_name_);
               if((yyvsp[0].expression_attr).is_array_id == 1){
                  emit((yyvsp[0].expression_attr).array->_name_,strr,_ARRAY_ACCESS,(yyvsp[0].expression_attr).loc->_name_);
                  (yyvsp[0].expression_attr).is_array_id = 0;
                  (yyval.expression_attr).is_array_id = 0;
               }
               (yyval.expression_attr)._type_ = (yyvsp[0].expression_attr)._type_;
               (yyval.expression_attr).width = (yyvsp[0].expression_attr).width;
               (yyval.expression_attr).int_val = (yyvsp[0].expression_attr).int_val + 1;
               (yyval.expression_attr).is_l_val = 1;
            }
            else {
                 char str[] = "Invalid operation at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(str,temporary_string);
                 yyerror(str);
                 exit(1);
             }   
          }
#line 2802 "y.tab.c" /* yacc.c:1646  */
    break;

  case 30:
#line 1026 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             //If it is a l-value then this operation is valid else it is invalid.
             char *strr;
             if((yyvsp[0].expression_attr).is_l_val == 0){
               (yyval.expression_attr) = (yyvsp[0].expression_attr);
               (yyval.expression_attr).loc = current_symb_table->gentemp();
               if((yyvsp[0].expression_attr).is_array_id == 1){
                 symb_table* temp = current_symb_table->gentemp();
                 strr = strdup((yyvsp[0].expression_attr).loc->_name_);
                 emit(temp->_name_,(yyvsp[0].expression_attr).array->_name_,_ARRAY_DEREFERENCE,(yyvsp[0].expression_attr).loc->_name_);
                 (yyvsp[0].expression_attr).loc = temp;
                 current_symb_table->update((yyvsp[0].expression_attr).loc,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width,current_symb_table->offset);
                 current_symb_table->offset = current_symb_table->offset + (yyvsp[0].expression_attr).width;
               }
               if((yyvsp[0].expression_attr)._type_ == NULL){
                 char str[] = "Identifier not declared at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(str,temporary_string);
                 yyerror(str);
                 exit(1);
               }
               //If it is a boolean type, then convert into int.
               if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                 convert_bool_to_int(&((yyvsp[0].expression_attr)));
               }
               current_symb_table->update((yyval.expression_attr).loc,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width,current_symb_table->offset);
               current_symb_table->offset = current_symb_table->offset + (yyvsp[0].expression_attr).width;
               //Decrement the value of the variable and then assign this value to a temporary variable.
               emit(_DECREMENT,(yyvsp[0].expression_attr).loc->_name_);
               emit((yyval.expression_attr).loc->_name_,(yyvsp[0].expression_attr).loc->_name_);
               if((yyvsp[0].expression_attr).is_array_id == 1){
                  emit((yyvsp[0].expression_attr).array->_name_,strr,_ARRAY_ACCESS,(yyvsp[0].expression_attr).loc->_name_);
                  (yyvsp[0].expression_attr).is_array_id = 0;
                  (yyval.expression_attr).is_array_id = 0;
               }
               (yyval.expression_attr)._type_ = (yyvsp[0].expression_attr)._type_;
               (yyval.expression_attr).width = (yyvsp[0].expression_attr).width;
               (yyval.expression_attr).int_val = (yyvsp[0].expression_attr).int_val - 1;
               (yyval.expression_attr).is_l_val = 1;
            }
            else {
                 char str[] = "Invalid operation at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(str,temporary_string);
                 yyerror(str);
                 exit(1);
             }   
          }
#line 2857 "y.tab.c" /* yacc.c:1646  */
    break;

  case 31:
#line 1076 "ass6_14CS10060.y" /* yacc.c:1646  */
    { 
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              //If it is a boolean type, then convert into int.
              if((yyvsp[0].expression_attr).is_array_id == 1){
                 symb_table* temp = current_symb_table->gentemp();
                 emit(temp->_name_,(yyvsp[0].expression_attr).array->_name_,_ARRAY_DEREFERENCE,(yyvsp[0].expression_attr).loc->_name_);
                 (yyvsp[0].expression_attr).loc = temp;
                 (yyvsp[0].expression_attr).is_array_id = 0;
                 current_symb_table->update((yyvsp[0].expression_attr).loc,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width,current_symb_table->offset);
                 current_symb_table->offset = current_symb_table->offset + (yyvsp[0].expression_attr).width;
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ == NULL){
                char str[] = "Identifier not declared at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              }
              current_symb_table->update((yyval.expression_attr).loc,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + (yyvsp[0].expression_attr).width;
              switch(unary_operator_type){
                case 1 : {
                  //If the operation is referencing then the new type will be a pointer to the old type.
                  emit((yyval.expression_attr).loc->_name_,(yyvsp[0].expression_attr).loc->_name_,_REFERENCE);
                  _type* t = new _type;
                  t->variable_data_type = strdup("ptr");
                  t->_next_ = (yyvsp[0].expression_attr)._type_;
                  (yyval.expression_attr)._type_ = t;
                  (yyval.expression_attr).width = 8;
                  (yyval.expression_attr).is_l_val = 1;
                  break;
                }
                case 2 : {
                  //This unary operatiom is valid for pointer type only.
                  if(strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"ptr")){
                    char str[] = "Operator should be a pointer at line ";
                    char temporary_string[50];
                    sprintf(temporary_string,"%d",line_num);
                    strcat(str,temporary_string);
                    yyerror(str);
                    exit(1);
                  }
                  //If the operation is dereferencing then the new type will be dereferenced type of the old type.
                  (yyval.expression_attr)._type_ = (yyvsp[0].expression_attr)._type_->_next_;
                  (yyval.expression_attr).pointer = (yyvsp[0].expression_attr).loc;
                  (yyval.expression_attr).is_pointer_type = 1;
                  if(!strcmp((yyval.expression_attr)._type_->variable_data_type,"double")){
                    (yyval.expression_attr).width = 8;
                  }
                  else if(!strcmp((yyval.expression_attr)._type_->variable_data_type,"ptr")){
                    (yyval.expression_attr).width = 8;
                  }
                  else if(!strcmp((yyval.expression_attr)._type_->variable_data_type,"int")){
                    (yyval.expression_attr).width = 4;
                  }
                  else if(!strcmp((yyval.expression_attr)._type_->variable_data_type,"char")){
                    (yyval.expression_attr).width = 1;
                  }
                  (yyval.expression_attr).is_l_val = 0;
                  emit((yyval.expression_attr).loc->_name_,(yyvsp[0].expression_attr).loc->_name_,_DEREFERENCE);
                  break;
                }
                case 3 : {
                  //Assign the type to be same as the cast expression.
                  (yyval.expression_attr)._type_ = (yyvsp[0].expression_attr)._type_;
                  (yyval.expression_attr).width = (yyvsp[0].expression_attr).width;
                  (yyval.expression_attr).is_l_val = 1;
                  emit((yyval.expression_attr).loc->_name_,(yyvsp[0].expression_attr).loc->_name_,_UNARY_ADD);
                  break;
                }
                case 4 : {
                  //Assign the type to be same as the cast expression.
                  (yyval.expression_attr)._type_ = (yyvsp[0].expression_attr)._type_;
                  (yyval.expression_attr).width = (yyvsp[0].expression_attr).width;
                  (yyval.expression_attr).is_l_val = 1;
                  emit((yyval.expression_attr).loc->_name_,(yyvsp[0].expression_attr).loc->_name_,_UNARY_SUBTRACT);
                  (yyval.expression_attr).int_val = -(yyvsp[0].expression_attr).int_val;
                  break;
                }
                case 5 : {
                  //Assign the type to be same as the cast expression.
                  (yyval.expression_attr)._type_ = (yyvsp[0].expression_attr)._type_;
                  (yyval.expression_attr).width = (yyvsp[0].expression_attr).width;
                  (yyval.expression_attr).is_l_val = 1;
                  emit((yyval.expression_attr).loc->_name_,(yyvsp[0].expression_attr).loc->_name_,_COMPLEMENT);
                  (yyval.expression_attr).int_val = ~((yyvsp[0].expression_attr).int_val);
                  break;
                }
                case 6 : {
                  //Assign the type to be same as the cast expression.
                  (yyval.expression_attr)._type_ = (yyvsp[0].expression_attr)._type_;
                  (yyval.expression_attr).width = (yyvsp[0].expression_attr).width;
                  (yyval.expression_attr).is_l_val = 1;
                  emit((yyval.expression_attr).loc->_name_,(yyvsp[0].expression_attr).loc->_name_,_NOT);
                  (yyval.expression_attr).int_val = !((yyvsp[0].expression_attr).int_val);
                  break;
                }
              }
          }
#line 2965 "y.tab.c" /* yacc.c:1646  */
    break;

  case 34:
#line 1183 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              unary_operator_type = 1;
          }
#line 2973 "y.tab.c" /* yacc.c:1646  */
    break;

  case 35:
#line 1186 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              unary_operator_type = 2;
          }
#line 2981 "y.tab.c" /* yacc.c:1646  */
    break;

  case 36:
#line 1189 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              unary_operator_type = 3;
          }
#line 2989 "y.tab.c" /* yacc.c:1646  */
    break;

  case 37:
#line 1192 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              unary_operator_type = 4;
          }
#line 2997 "y.tab.c" /* yacc.c:1646  */
    break;

  case 38:
#line 1195 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              unary_operator_type = 5;
          }
#line 3005 "y.tab.c" /* yacc.c:1646  */
    break;

  case 39:
#line 1198 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              unary_operator_type = 6;
          }
#line 3013 "y.tab.c" /* yacc.c:1646  */
    break;

  case 40:
#line 1203 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
              (yyval.expression_attr).is_pointer_type = 0;
          }
#line 3022 "y.tab.c" /* yacc.c:1646  */
    break;

  case 41:
#line 1207 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //If cast expression is a boolean expression , then convert it into an integer expression.
              if((yyvsp[0].expression_attr).is_array_id == 1){
                symb_table* temp = current_symb_table->gentemp();
                emit(temp->_name_,(yyvsp[0].expression_attr).array->_name_,_ARRAY_DEREFERENCE,(yyvsp[0].expression_attr).loc->_name_);
                (yyvsp[0].expression_attr).loc = temp;
                (yyvsp[0].expression_attr).is_array_id = 0;
                current_symb_table->update((yyvsp[0].expression_attr).loc,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width,current_symb_table->offset);
                current_symb_table->offset = current_symb_table->offset + (yyvsp[0].expression_attr).width;
              } 
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Typename/Casting can only be done to fundamental data types like int,char or double.
              //Valid casting are int to double/char,char to double/int and double to char/int.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"int")){
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                   convert_char_to_int(&((yyvsp[0].expression_attr)));
                } 
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")){
                   convert_double_to_int(&((yyvsp[0].expression_attr)));
                }
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                   
                }
                else {
                  char str[] = "Invalid cast operation at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
                }
              }
              else if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"char")){
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                   convert_int_to_char(&((yyvsp[0].expression_attr)));
                } 
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")){
                   convert_double_to_int(&((yyvsp[0].expression_attr)));
                   convert_int_to_char(&((yyvsp[0].expression_attr)));
                }
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                   
                }
                else {
                  char str[] = "Invalid cast operation at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
                }
              }
              else if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"double")){
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                   convert_int_to_double(&((yyvsp[0].expression_attr)));
                } 
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                   convert_char_to_int(&((yyvsp[0].expression_attr)));
                   convert_int_to_double(&((yyvsp[0].expression_attr)));
                }
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")){
                   
                }
                else {
                  char str[] = "Invalid cast operation at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
                }
              }
              else {
                  char str[] = "Invalid cast operation at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
              }
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
              (yyval.expression_attr).is_pointer_type = 0;
          }
#line 3112 "y.tab.c" /* yacc.c:1646  */
    break;

  case 42:
#line 1294 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              if((yyvsp[0].expression_attr).is_array_id == 1){
                symb_table* temp = current_symb_table->gentemp();
                emit(temp->_name_,(yyvsp[0].expression_attr).array->_name_,_ARRAY_DEREFERENCE,(yyvsp[0].expression_attr).loc->_name_);
                (yyvsp[0].expression_attr).loc = temp;
                (yyvsp[0].expression_attr).is_array_id = 0;
                current_symb_table->update((yyvsp[0].expression_attr).loc,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width,current_symb_table->offset);
                current_symb_table->offset = current_symb_table->offset + (yyvsp[0].expression_attr).width;
              }
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 3128 "y.tab.c" /* yacc.c:1646  */
    break;

  case 43:
#line 1305 "ass6_14CS10060.y" /* yacc.c:1646  */
    { 
              //Multiplication operation is not valid for pointers.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr")){
                char s[] = "Invalid operation on pointer type variable at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1); 
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"ptr")){
                char s[] = "Invalid operation on pointer type variable at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1); 
              }
              //Convert boolean expression into an integer expression.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Check type of two operands and do implicit type casting if allowed.
              typecheck(&((yyvsp[-2].expression_attr)),&((yyvsp[0].expression_attr)));
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              (yyval.expression_attr).width = (yyvsp[-2].expression_attr).width;
              current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-2].expression_attr)._type_,(yyvsp[-2].expression_attr).width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + (yyvsp[-2].expression_attr).width;
              //Create a temporary and emit the product into the temporary variable.
              emit((yyval.expression_attr).loc->_name_,(yyvsp[-2].expression_attr).loc->_name_,_PRODUCT,(yyvsp[0].expression_attr).loc->_name_);
              (yyval.expression_attr).int_val = (yyvsp[-2].expression_attr).int_val * (yyvsp[0].expression_attr).int_val;
              (yyval.expression_attr)._type_ = (yyvsp[-2].expression_attr)._type_;
          }
#line 3169 "y.tab.c" /* yacc.c:1646  */
    break;

  case 44:
#line 1341 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //Division operation is not valid for pointers.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr")){
                char s[] = "Invalid operation on pointer type variable at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1); 
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"ptr")){
                char s[] = "Invalid operation on pointer type variable at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1); 
              }
              //Convert boolean expression into an integer expression.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Check type of two operands and do implicit type casting if allowed.
              typecheck(&((yyvsp[-2].expression_attr)),&((yyvsp[0].expression_attr)));
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              (yyval.expression_attr).width = (yyvsp[-2].expression_attr).width;
              current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-2].expression_attr)._type_,(yyvsp[-2].expression_attr).width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + (yyvsp[-2].expression_attr).width;
              //Create a temporary and emit the result into the temporary variable.
              emit((yyval.expression_attr).loc->_name_,(yyvsp[-2].expression_attr).loc->_name_,_DIVIDE,(yyvsp[0].expression_attr).loc->_name_);
              //As division by zero is not allowed, the int_val which is required for index of an array is made negative 
              //which is not allowed.
              if((yyvsp[0].expression_attr).int_val == 0){
                (yyval.expression_attr).int_val = -1;
              }
              else {
                (yyval.expression_attr).int_val = (yyvsp[-2].expression_attr).int_val / (yyvsp[0].expression_attr).int_val;
              }
              (yyval.expression_attr)._type_ = (yyvsp[-2].expression_attr)._type_;
          }
#line 3217 "y.tab.c" /* yacc.c:1646  */
    break;

  case 45:
#line 1384 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //Print error if the identifiers have not been declared.
              if((yyvsp[-2].expression_attr)._type_ == NULL || (yyvsp[0].expression_attr)._type_ == NULL){
                 char str[] = "Variable has not been declared at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(str,temporary_string);
                 yyerror(str);
                 exit(1);
              }
              //Convert boolean expression into an integer expression.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Convert character expression into an integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[-2].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[0].expression_attr)));
              }
              //Modulus operation is defined for integer/character/boolean operations only.
              if(strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"int") || strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                 char s[] = "Operands for modulus should be integer at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(s,temporary_string);
                 yyerror(s);
                 exit(1);
              }
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              (yyval.expression_attr).width = (yyvsp[-2].expression_attr).width;
              current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-2].expression_attr)._type_,(yyvsp[-2].expression_attr).width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + (yyvsp[-2].expression_attr).width;
              //Create a temporary and emit the result into the temporary variable.
              emit((yyval.expression_attr).loc->_name_,(yyvsp[-2].expression_attr).loc->_name_,_MODULO,(yyvsp[0].expression_attr).loc->_name_);
              if((yyvsp[0].expression_attr).int_val == 0){
                (yyval.expression_attr).int_val = -1;
              }
              else {
                (yyval.expression_attr).int_val = (yyvsp[-2].expression_attr).int_val % (yyvsp[0].expression_attr).int_val;
              }
              (yyval.expression_attr)._type_ = (yyvsp[-2].expression_attr)._type_;
          }
#line 3269 "y.tab.c" /* yacc.c:1646  */
    break;

  case 46:
#line 1433 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 3277 "y.tab.c" /* yacc.c:1646  */
    break;

  case 47:
#line 1436 "ass6_14CS10060.y" /* yacc.c:1646  */
    { 
              //Addition operation is not valid if both operands are pointers.
              if(((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr")) && ((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"ptr"))){
                char s[] = "Invalid operation on pointer type variable at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1); 
              }
              //Convert boolean expression into an integer expression.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Check type of two operands and do implicit type casting if allowed.
              typecheck(&((yyvsp[-2].expression_attr)),&((yyvsp[0].expression_attr)));
              //Addition operation is not valid if one operand is pointer and another is double expression.
              if((!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr") && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")) || (!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"ptr") && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"double"))){
                char s[] = "Invalid operation on pointer type variable at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1);
              }
              //Addition operation is valid if one operand is pointer and another is character/integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr") && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[0].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"ptr") && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[-2].expression_attr)));
              }
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              (yyval.expression_attr).width = (yyvsp[-2].expression_attr).width;
              current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-2].expression_attr)._type_,(yyvsp[-2].expression_attr).width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + (yyvsp[-2].expression_attr).width;
              //Create a temporary and emit the sum into the temporary variable.
              emit((yyval.expression_attr).loc->_name_,(yyvsp[-2].expression_attr).loc->_name_,_ADD,(yyvsp[0].expression_attr).loc->_name_);
              (yyval.expression_attr).int_val = (yyvsp[-2].expression_attr).int_val + (yyvsp[0].expression_attr).int_val;
              (yyval.expression_attr)._type_ = (yyvsp[-2].expression_attr)._type_;
          }
#line 3326 "y.tab.c" /* yacc.c:1646  */
    break;

  case 48:
#line 1480 "ass6_14CS10060.y" /* yacc.c:1646  */
    { 
              //Subtraction operation is not valid if both operands are pointers.
              if(((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr")) && ((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"ptr"))){
                char s[] = "Invalid operation on pointer type variable at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1); 
              }
              //Convert boolean expression into an integer expression.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Check type of two operands and do implicit type casting if allowed.
              typecheck(&((yyvsp[-2].expression_attr)),&((yyvsp[0].expression_attr)));
              //Subtraction operation is not valid if one operand is pointer and another is double expression.
              if((!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr") && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")) || (!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"ptr") && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"double"))){
                char s[] = "Invalid operation on pointer type variable at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1);
              }
              //Subtraction operation is valid if one operand is pointer and another is character/integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr") && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[0].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"ptr") && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[-2].expression_attr)));
              }
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              (yyval.expression_attr).width = (yyvsp[-2].expression_attr).width;
              current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-2].expression_attr)._type_,(yyvsp[-2].expression_attr).width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + (yyvsp[-2].expression_attr).width;
              //Create a temporary and emit the difference into the temporary variable.
              emit((yyval.expression_attr).loc->_name_,(yyvsp[-2].expression_attr).loc->_name_,_SUBTRACT,(yyvsp[0].expression_attr).loc->_name_);
              if((yyval.expression_attr).int_val != 0){
                (yyval.expression_attr).int_val = (yyvsp[-2].expression_attr).int_val - (yyvsp[0].expression_attr).int_val;
              } 
              (yyval.expression_attr)._type_ = (yyvsp[-2].expression_attr)._type_;
          }
#line 3377 "y.tab.c" /* yacc.c:1646  */
    break;

  case 49:
#line 1528 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 3385 "y.tab.c" /* yacc.c:1646  */
    break;

  case 50:
#line 1531 "ass6_14CS10060.y" /* yacc.c:1646  */
    { 
              //This operation requires both types to be either boolean or character or integer expressions.
              if((yyvsp[-2].expression_attr)._type_ == NULL || (yyvsp[0].expression_attr)._type_ == NULL){
                 char str[] = "Variable has not been declared at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(str,temporary_string);
                 yyerror(str);
                 exit(1);
              }
              //Convert boolean expression into an integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Convert character expression into an integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[-2].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[0].expression_attr)));
              }
              //Both operands have to be of integer type at this point for shift operation to be valid.
              if(strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"int") || strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                 char s[] = "Shift amount and value to be shifted should be integer at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(s,temporary_string);
                 yyerror(s);
                 exit(1);
              }
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              (yyval.expression_attr).width = (yyvsp[-2].expression_attr).width;
              current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-2].expression_attr)._type_,(yyvsp[-2].expression_attr).width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + (yyvsp[-2].expression_attr).width;
              //Create a temporary and emit the result into the temporary variable.
              emit((yyval.expression_attr).loc->_name_,(yyvsp[-2].expression_attr).loc->_name_,_SHIFT_LEFT,(yyvsp[0].expression_attr).loc->_name_);
              (yyval.expression_attr).int_val = (yyvsp[-2].expression_attr).int_val << (yyvsp[0].expression_attr).int_val;
              (yyval.expression_attr)._type_ = (yyvsp[-2].expression_attr)._type_;
          }
#line 3432 "y.tab.c" /* yacc.c:1646  */
    break;

  case 51:
#line 1573 "ass6_14CS10060.y" /* yacc.c:1646  */
    { 
              //This operation requires both types to be either boolean or character or integer expressions.
              if((yyvsp[-2].expression_attr)._type_ == NULL || (yyvsp[0].expression_attr)._type_ == NULL){
                 char str[] = "Variable has not been declared at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(str,temporary_string);
                 yyerror(str);
                 exit(1);
              }
              //Convert boolean expression into an integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Convert character expression into an integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[-2].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[0].expression_attr)));
              }
              //Both operands have to be of integer type at this point for shift operation to be valid.
              if(strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"int") || strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                 char s[] = "Shift amount and value to be shifted should be integer at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(s,temporary_string);
                 yyerror(s);
                 exit(1);
              }
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              (yyval.expression_attr).width = (yyvsp[-2].expression_attr).width;
              current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-2].expression_attr)._type_,(yyvsp[-2].expression_attr).width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + (yyvsp[-2].expression_attr).width;
              //Create a temporary and emit the result into the temporary variable.
              emit((yyval.expression_attr).loc->_name_,(yyvsp[-2].expression_attr).loc->_name_,_SHIFT_RIGHT,(yyvsp[0].expression_attr).loc->_name_);
              (yyval.expression_attr).int_val = (yyvsp[-2].expression_attr).int_val >> (yyvsp[0].expression_attr).int_val;
              (yyval.expression_attr)._type_ = (yyvsp[-2].expression_attr)._type_;
          }
#line 3479 "y.tab.c" /* yacc.c:1646  */
    break;

  case 52:
#line 1617 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 3487 "y.tab.c" /* yacc.c:1646  */
    break;

  case 53:
#line 1620 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //Convert boolean expression into an integer expression.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Check type of two operands and do implicit type casting if allowed.
              typecheck(&((yyvsp[-2].expression_attr)),&((yyvsp[0].expression_attr)));
              _type *p = (yyvsp[-2].expression_attr)._type_;
              _type *q = (yyvsp[0].expression_attr)._type_;
              //Check if the types of the two expression are same or not after implicit type casting.
              while(p != NULL && q != NULL){
                if(strcmp(p->variable_data_type,q->variable_data_type) || p->size != q->size){
                  char str[] = "Incompatible types for operation at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
                }
                p = p->_next_;
                q = q->_next_;
              }
              if(p != NULL || q != NULL){
                char str[] = "Incompatible types for operation at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              } 
              //Make truelist as nextinstr where if E1 < E2 is emitted with a dangling goto.       
              (yyval.expression_attr).truelist = makelist(nextinstr);
              //Make falselist as nextinstr + 1 where a dangling goto is emitted.
              (yyval.expression_attr).falselist = makelist(nextinstr + 1);
              //Make the type of the expression as boolean expression.
              _type* t = new _type;
              t->variable_data_type = strdup("bool");
              t->_next_ = NULL;
              (yyval.expression_attr)._type_ = t;
              char str[] = "...";
              emit(str,(yyvsp[-2].expression_attr).loc->_name_,_CONDITIONAL_LESS,(yyvsp[0].expression_attr).loc->_name_);
              emit(_GOTO,str);
          }
#line 3538 "y.tab.c" /* yacc.c:1646  */
    break;

  case 54:
#line 1666 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //Convert boolean expression into an integer expression.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Check type of two operands and do implicit type casting if allowed.
              typecheck(&((yyvsp[-2].expression_attr)),&((yyvsp[0].expression_attr)));
              _type *p = (yyvsp[-2].expression_attr)._type_;
              _type *q = (yyvsp[0].expression_attr)._type_;
              //Check if the types of the two expression are same or not after implicit type casting.
              for(;p != NULL && q != NULL;){
                if(strcmp(p->variable_data_type,q->variable_data_type)){
                  char str[] = "Incompatible types for operation at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
                }
                p = p->_next_;
                q = q->_next_;
              }
              if(p != NULL || q != NULL){
                char str[] = "Incompatible types for operation at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              }
              //Make truelist as nextinstr where if E1 > E2 is emitted with a dangling goto.
              (yyval.expression_attr).truelist = makelist(nextinstr);
              //Make falselist as nextinstr + 1 where a dangling goto is emitted.
              (yyval.expression_attr).falselist = makelist(nextinstr + 1);
              //Make the type of the expression as boolean expression.
              _type* t = new _type;
              t->variable_data_type = strdup("bool");
              t->_next_ = NULL;
              (yyval.expression_attr)._type_ = t;
              char str[] = "...";
              emit(str,(yyvsp[-2].expression_attr).loc->_name_,_CONDITIONAL_GREATER,(yyvsp[0].expression_attr).loc->_name_);
              emit(_GOTO,str);
          }
#line 3589 "y.tab.c" /* yacc.c:1646  */
    break;

  case 55:
#line 1712 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //Convert boolean expression into an integer expression.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Check type of two operands and do implicit type casting if allowed.
              typecheck(&((yyvsp[-2].expression_attr)),&((yyvsp[0].expression_attr)));
              _type *p = (yyvsp[-2].expression_attr)._type_;
              _type *q = (yyvsp[0].expression_attr)._type_;
              //Check if the types of the two expression are same or not after implicit type casting.
              while(p != NULL && q != NULL){
                if(strcmp(p->variable_data_type,q->variable_data_type)){
                  char str[] = "Incompatible types for operation at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
                }
                p = p->_next_;
                q = q->_next_;
              }
              if(p != NULL || q != NULL){
                char str[] = "Incompatible types for operation at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              }
              //Make truelist as nextinstr where if E1 <= E2 is emitted with a dangling goto.
              (yyval.expression_attr).truelist = makelist(nextinstr);
              //Make falselist as nextinstr + 1 where a dangling goto is emitted.
              (yyval.expression_attr).falselist = makelist(nextinstr + 1);
              //Make the type of the expression as boolean expression.
              _type* t = new _type;
              t->variable_data_type = strdup("bool");
              t->_next_ = NULL;
              (yyval.expression_attr)._type_ = t;
              char str[] = "...";
              emit(str,(yyvsp[-2].expression_attr).loc->_name_,_CONDITIONAL_LESS_EQUAL,(yyvsp[0].expression_attr).loc->_name_);
              emit(_GOTO,str);
          }
#line 3640 "y.tab.c" /* yacc.c:1646  */
    break;

  case 56:
#line 1758 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //Convert boolean expression into an integer expression.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Check type of two operands and do implicit type casting if allowed.
              typecheck(&((yyvsp[-2].expression_attr)),&((yyvsp[0].expression_attr)));
              _type *p = (yyvsp[-2].expression_attr)._type_;
              _type *q = (yyvsp[0].expression_attr)._type_;
              //Check if the types of the two expression are same or not after implicit type casting.
              while(p != NULL && q != NULL){
                if(strcmp(p->variable_data_type,q->variable_data_type)){
                  char str[] = "Incompatible types for operation at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
                }
                p = p->_next_;
                q = q->_next_;
              }
              if(p != NULL || q != NULL){
                char str[] = "Incompatible types for operation at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              }
              //Make truelist as nextinstr where if E1 >= E2 is emitted with a dangling goto.
              (yyval.expression_attr).truelist = makelist(nextinstr);
              //Make falselist as nextinstr + 1 where a dangling goto is emitted.
              (yyval.expression_attr).falselist = makelist(nextinstr + 1);
              //Make the type of the expression as boolean expression.
              _type* t = new _type;
              t->variable_data_type = strdup("bool");
              t->_next_ = NULL;
              (yyval.expression_attr)._type_ = t;
              char str[] = "...";
              emit(str,(yyvsp[-2].expression_attr).loc->_name_,_CONDITIONAL_GREATER_EQUAL,(yyvsp[0].expression_attr).loc->_name_);
              emit(_GOTO,str);
          }
#line 3691 "y.tab.c" /* yacc.c:1646  */
    break;

  case 57:
#line 1806 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 3699 "y.tab.c" /* yacc.c:1646  */
    break;

  case 58:
#line 1809 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //Convert boolean expression into an integer expression.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Check type of two operands and do implicit type casting if allowed.
              typecheck(&((yyvsp[-2].expression_attr)),&((yyvsp[0].expression_attr)));
              _type *p = (yyvsp[-2].expression_attr)._type_;
              _type *q = (yyvsp[0].expression_attr)._type_;
              //Check if the types of the two expression are same or not after implicit type casting.
              while(p != NULL && q != NULL){
                if(strcmp(p->variable_data_type,q->variable_data_type)){
                  char str[] = "Incompatible types for operation at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
                }
                p = p->_next_;
                q = q->_next_;
              }
              if(p != NULL || q != NULL){
                char str[] = "Incompatible types for operation at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              }
              //Make truelist as nextinstr where if E1 == E2 is emitted with a dangling goto.
              (yyval.expression_attr).truelist = makelist(nextinstr);
              //Make falselist as nextinstr + 1 where a dangling goto is emitted.
              (yyval.expression_attr).falselist = makelist(nextinstr + 1);
              //Make the type of the expression as boolean expression.
              _type* t = new _type;
              t->variable_data_type = strdup("bool");
              t->_next_ = NULL;
              (yyval.expression_attr)._type_ = t;
              char str[] = "...";
              emit(str,(yyvsp[-2].expression_attr).loc->_name_,_CONDITIONAL_IS_EQUAL,(yyvsp[0].expression_attr).loc->_name_);
              emit(_GOTO,str);
          }
#line 3750 "y.tab.c" /* yacc.c:1646  */
    break;

  case 59:
#line 1855 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              //Convert boolean expression into an integer expression.
              if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Check type of two operands and do implicit type casting if allowed.
              typecheck(&((yyvsp[-2].expression_attr)),&((yyvsp[0].expression_attr)));
              _type *p = (yyvsp[-2].expression_attr)._type_;
              _type *q = (yyvsp[0].expression_attr)._type_;
              //Check if the types of the two expression are same or not after implicit type casting.
              while(p != NULL && q != NULL){
                if(strcmp(p->variable_data_type,q->variable_data_type)){
                  char str[] = "Incompatible types for operation at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
                }
                p = p->_next_;
                q = q->_next_;
              }
              if(p != NULL || q != NULL){
                char str[] = "Incompatible types for operation at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              }
              //Make truelist as nextinstr where if E1 != E2 is emitted with a dangling goto.
              (yyval.expression_attr).truelist = makelist(nextinstr);
              //Make falselist as nextinstr + 1 where a dangling goto is emitted.
              (yyval.expression_attr).falselist = makelist(nextinstr + 1);
              //Make the type of the expression as boolean expression.
              _type* t = new _type;
              t->variable_data_type = strdup("bool");
              t->_next_ = NULL;
              (yyval.expression_attr)._type_ = t;
              char str[] = "...";
              emit(str,(yyvsp[-2].expression_attr).loc->_name_,_CONDITIONAL_NOT_EQUAL,(yyvsp[0].expression_attr).loc->_name_);
              emit(_GOTO,str);
          }
#line 3801 "y.tab.c" /* yacc.c:1646  */
    break;

  case 60:
#line 1903 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 3809 "y.tab.c" /* yacc.c:1646  */
    break;

  case 61:
#line 1906 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              if((yyvsp[-2].expression_attr)._type_ == NULL || (yyvsp[0].expression_attr)._type_ == NULL){
                char str[] = "Variable has not been declared at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              }
              //Convert boolean expression into an integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Convert character expression into an integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[-2].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[0].expression_attr)));
              }
              //Only integer expressions are allowed for bitwise and operation.
              if(strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"int") || strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                char s[] = "Operands of Bitwise And should be integer at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1);
              }
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              (yyval.expression_attr).width = (yyvsp[-2].expression_attr).width;
              current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-2].expression_attr)._type_,(yyvsp[-2].expression_attr).width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + (yyvsp[-2].expression_attr).width;
              //Generate a temporary and emit the result into the temporary variable.
              emit((yyval.expression_attr).loc->_name_,(yyvsp[-2].expression_attr).loc->_name_,_UNARY_AND,(yyvsp[0].expression_attr).loc->_name_);
              (yyval.expression_attr).int_val = (yyvsp[-2].expression_attr).int_val & (yyvsp[0].expression_attr).int_val;
              (yyval.expression_attr)._type_ = (yyvsp[-2].expression_attr)._type_;
          }
#line 3855 "y.tab.c" /* yacc.c:1646  */
    break;

  case 62:
#line 1949 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 3863 "y.tab.c" /* yacc.c:1646  */
    break;

  case 63:
#line 1952 "ass6_14CS10060.y" /* yacc.c:1646  */
    { 
              if((yyvsp[-2].expression_attr)._type_ == NULL || (yyvsp[0].expression_attr)._type_ == NULL){
                char str[] = "Variable has not been declared at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              }
              //Convert character expression into an integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[-2].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[0].expression_attr)));
              }
              //Convert boolean expression into an integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              //Only integer expressions are allowed for bitwise xor operation.
              if(!(strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"int") || strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int"))){
                  (yyval.expression_attr).loc = current_symb_table->gentemp();
                  (yyval.expression_attr).width = (yyvsp[-2].expression_attr).width;
                  current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-2].expression_attr)._type_,(yyvsp[-2].expression_attr).width,current_symb_table->offset);
                  current_symb_table->offset = current_symb_table->offset + (yyvsp[-2].expression_attr).width;
                  //Generate a temporary and emit the result into the temporary variable.
                  emit((yyval.expression_attr).loc->_name_,(yyvsp[-2].expression_attr).loc->_name_,_XOR,(yyvsp[0].expression_attr).loc->_name_);
                  (yyval.expression_attr).int_val = (yyvsp[-2].expression_attr).int_val ^ (yyvsp[0].expression_attr).int_val;
                  (yyval.expression_attr)._type_ = (yyvsp[-2].expression_attr)._type_;
              }
              else {
                 char s[] = "Operands of Bitwise Xor should be integer at line ";
                 char temporary_string[50];
                 sprintf(temporary_string,"%d",line_num);
                 strcat(s,temporary_string);
                 yyerror(s);
                 exit(1);
              }
          }
#line 3911 "y.tab.c" /* yacc.c:1646  */
    break;

  case 64:
#line 1997 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);   
          }
#line 3919 "y.tab.c" /* yacc.c:1646  */
    break;

  case 65:
#line 2000 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              if((yyvsp[-2].expression_attr)._type_ == NULL || (yyvsp[0].expression_attr)._type_ == NULL){
                char str[] = "Variable has not been declared at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              }
              //Convert boolean expression into an integer expression.
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
              }
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[-2].expression_attr)));
              }
              //Convert character expression into an integer expression.
              if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[-2].expression_attr)));
              }
              if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                convert_char_to_int(&((yyvsp[0].expression_attr)));
              }
              //Only integer expressions are allowed for bitwise or operation.
              if(strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"int") || strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                char s[] = "Operands of Bitwise Or should be integer at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(s,temporary_string);
                yyerror(s);
                exit(1);
              }
              (yyval.expression_attr).loc = current_symb_table->gentemp();
              (yyval.expression_attr).width = (yyvsp[-2].expression_attr).width;
              current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-2].expression_attr)._type_,(yyvsp[-2].expression_attr).width,current_symb_table->offset);
              current_symb_table->offset = current_symb_table->offset + (yyvsp[-2].expression_attr).width;
              //Generate a temporary and emit the result into the temporary variable.
              emit((yyval.expression_attr).loc->_name_,(yyvsp[-2].expression_attr).loc->_name_,_UNARY_OR,(yyvsp[0].expression_attr).loc->_name_);
              (yyval.expression_attr).int_val = (yyvsp[-2].expression_attr).int_val | (yyvsp[0].expression_attr).int_val;
              (yyval.expression_attr)._type_ = (yyvsp[-2].expression_attr)._type_;
          }
#line 3965 "y.tab.c" /* yacc.c:1646  */
    break;

  case 66:
#line 2043 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 3973 "y.tab.c" /* yacc.c:1646  */
    break;

  case 67:
#line 2046 "ass6_14CS10060.y" /* yacc.c:1646  */
    { // Grammar Augmented so as to backpatch the dangling truelist.
            if((yyvsp[-3].expression_attr)._type_ == NULL || (yyvsp[0].expression_attr)._type_ == NULL){
              char str[] = "Variable has not been declared at line ";
              char temporary_string[50];
              sprintf(temporary_string,"%d",line_num);
              strcat(str,temporary_string);
              yyerror(str);
              exit(1);
            }
            //Convert into a boolean expression.
            if(strcmp((yyvsp[-3].expression_attr)._type_->variable_data_type,"bool")){
              convert_exp_to_bool(&((yyvsp[-3].expression_attr)));
            }
            if(strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
              convert_exp_to_bool(&((yyvsp[0].expression_attr)));
            }
            //As if B1 is true in B1 && B2, we need to check B2. 
            backpatch((yyvsp[-3].expression_attr).truelist,(yyvsp[-1].expression_attr).instr);
            //The expression is true if both B1 and B2 are true.
            (yyval.expression_attr).truelist = (yyvsp[0].expression_attr).truelist;
            //The expression is false if only one of them is false.
            (yyval.expression_attr).falselist = merge((yyvsp[-3].expression_attr).falselist,(yyvsp[0].expression_attr).falselist);
            (yyval.expression_attr)._type_ = (yyvsp[-3].expression_attr)._type_;
          }
#line 4002 "y.tab.c" /* yacc.c:1646  */
    break;

  case 68:
#line 2072 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4010 "y.tab.c" /* yacc.c:1646  */
    break;

  case 69:
#line 2075 "ass6_14CS10060.y" /* yacc.c:1646  */
    { // Grammar Augmented so as to backpatch the dangling falselist.
            if((yyvsp[-3].expression_attr)._type_ == NULL || (yyvsp[0].expression_attr)._type_ == NULL){
              char str[] = "Variable has not been declared at line ";
              char temporary_string[50];
              sprintf(temporary_string,"%d",line_num);
              strcat(str,temporary_string);
              yyerror(str);
              exit(1);
            }
            //Convert into a boolean expression.
            if(strcmp((yyvsp[-3].expression_attr)._type_->variable_data_type,"bool")){
              convert_exp_to_bool(&((yyvsp[-3].expression_attr)));
            }
            if(strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
              convert_exp_to_bool(&((yyvsp[0].expression_attr)));
            }
            //As if B1 is false in B1 && B2, we need to check B2.
            backpatch((yyvsp[-3].expression_attr).falselist,(yyvsp[-1].expression_attr).instr);
            //The expression is false if both B1 and B2 are false.
            (yyval.expression_attr).falselist = (yyvsp[0].expression_attr).falselist;
            //The expression is true if only one of them is true.
            (yyval.expression_attr).truelist = merge((yyvsp[-3].expression_attr).truelist,(yyvsp[0].expression_attr).truelist);
            (yyval.expression_attr)._type_ = (yyvsp[-3].expression_attr)._type_;
            _list* temp_list;
          }
#line 4040 "y.tab.c" /* yacc.c:1646  */
    break;

  case 70:
#line 2102 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr).instr = nextinstr;     //M stores the current instruction. 
          }
#line 4048 "y.tab.c" /* yacc.c:1646  */
    break;

  case 71:
#line 2107 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4056 "y.tab.c" /* yacc.c:1646  */
    break;

  case 72:
#line 2110 "ass6_14CS10060.y" /* yacc.c:1646  */
    { // Grammar augmented to backpatch 
             //truelist and falselist of expression1 and N's are added to add a goto to the new boolean expression
             //generated after conversion of expression1, else if expression1 is boolean, to add a redundant goto  
             (yyval.expression_attr) = (yyvsp[-4].expression_attr);
             //Generate temporary for storing the value expression2 or expression3.
             (yyval.expression_attr).loc = current_symb_table->gentemp();
             current_symb_table->update((yyval.expression_attr).loc,(yyvsp[-4].expression_attr)._type_,(yyvsp[-4].expression_attr).width,current_symb_table->offset);
             current_symb_table->offset = current_symb_table->offset + (yyvsp[-4].expression_attr).width;
             //emit temporary variable assigned expression3.
             emit((yyval.expression_attr).loc->_name_,(yyvsp[0].expression_attr).loc->_name_);
             _list* temp_list = makelist(nextinstr);
             char str[] = "...";
             //emit goto for skipping assignment of expression2.
             emit(_GOTO,str);
             backpatch((yyvsp[-3].expression_attr).nextlist,nextinstr);
             //emit temporary variable assigned expression2.
             emit((yyval.expression_attr).loc->_name_,(yyvsp[-4].expression_attr).loc->_name_);
             temp_list = merge(temp_list,makelist(nextinstr));
             emit(_GOTO,str);
             backpatch((yyvsp[-7].expression_attr).nextlist,nextinstr);
             //Conversion of expression1 into boolean expression.
             if(strcmp((yyvsp[-8].expression_attr)._type_->variable_data_type,"bool")){
               convert_exp_to_bool(&((yyvsp[-8].expression_attr)));
             }
             //backpatch truelist and falselist of expression1 to expression2 assignment and expression3 assignment. 
             backpatch((yyvsp[-8].expression_attr).truelist,(yyvsp[-5].expression_attr).instr);
             backpatch((yyvsp[-8].expression_attr).falselist,(yyvsp[-1].expression_attr).instr);
             backpatch(temp_list,nextinstr);  
          }
#line 4090 "y.tab.c" /* yacc.c:1646  */
    break;

  case 73:
#line 2141 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4098 "y.tab.c" /* yacc.c:1646  */
    break;

  case 74:
#line 2144 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             //If the left hand side is not a l-value, print error message.
             if((yyvsp[-2].expression_attr).is_l_val == 1){
                char str[] = "Assignment can only be done to a l-value at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
             }
             if((yyvsp[-2].expression_attr)._type_ == NULL || (yyvsp[0].expression_attr)._type_ == NULL){
                char str[] = "Variable not declared at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
             }
             //Handle array dereferencing by generating a temporary variable and equating to it.
             if((yyvsp[0].expression_attr).is_array_id == 1 && strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"array")){
               symb_table* t = current_symb_table->gentemp();
               current_symb_table->update(t,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width,current_symb_table->offset);
               current_symb_table->offset = current_symb_table->offset + (yyvsp[0].expression_attr).width;
               emit(t->_name_,(yyvsp[0].expression_attr).array->_name_,_ARRAY_DEREFERENCE,(yyvsp[0].expression_attr).loc->_name_);
               (yyvsp[0].expression_attr).loc = t;
               (yyvsp[0].expression_attr).is_array_id = 0;
             }
             //Conversion of boolean expression into character expression.
             if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
             }
             //Conversion from $3._type_ to $1._type_ for fundamental datatypes if it is permissible.
             if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"int")){
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                  convert_char_to_int(&((yyvsp[0].expression_attr)));
                }
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")){
                  convert_double_to_int(&((yyvsp[0].expression_attr)));
                }
             }
             else if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"char")){
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                  convert_int_to_char(&((yyvsp[0].expression_attr)));
                }
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")){
                  convert_double_to_int(&((yyvsp[0].expression_attr)));
                  convert_int_to_char(&((yyvsp[0].expression_attr)));
                }
             }
             else if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"double")){
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                  convert_char_to_int(&((yyvsp[0].expression_attr)));
                  convert_int_to_double(&((yyvsp[0].expression_attr)));
                }
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                  convert_int_to_double(&((yyvsp[0].expression_attr)));
                }
             }
             //Print warning for assignment of character/integer to a pointer and error for assignment of a double to a pointer.
             else if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr")){
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                  convert_char_to_int(&((yyvsp[0].expression_attr)));
                }
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                  char str[] = "Warning : Assignment of integer to a pointer at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                }
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")){
                  char str[] = "Assignment of double to a pointer at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
                }
             }
             //Assignment of pointer to a non-pointer gives an error.
             if(strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr") && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"ptr")){
                char str[] = "Warning : Assignment of a pointer to a non-pointer type at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
             }
             if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"array") || !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"array")){
             
             
                char str[] = "Wrong assignment of array at  line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              
             }
             //If left side is an assignment to the variable pointed to by a pointer, opcode is _POINTER_ASSIGNMENT.
             if((yyvsp[-2].expression_attr).is_pointer_type == 1){
               emit((yyvsp[-2].expression_attr).pointer->_name_,(yyvsp[0].expression_attr).loc->_name_,_POINTER_ASSIGNMENT);
               (yyvsp[-2].expression_attr).is_pointer_type = 0;
             }
             //If left side is an array, then opcode is _ARRAY_ACCESS.
             else if((yyvsp[-2].expression_attr).is_array_id == 1){
                emit((yyvsp[-2].expression_attr).array->_name_,(yyvsp[-2].expression_attr).loc->_name_,_ARRAY_ACCESS,(yyvsp[0].expression_attr).loc->_name_);
             }
             //Normal Assignment after implicit type conversion.
             else {
                emit((yyvsp[-2].expression_attr).loc->_name_,(yyvsp[0].expression_attr).loc->_name_);
             }
          }
#line 4215 "y.tab.c" /* yacc.c:1646  */
    break;

  case 86:
#line 2271 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4223 "y.tab.c" /* yacc.c:1646  */
    break;

  case 93:
#line 2286 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
        	  //Store the type in global_type and size in global_width.
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
            global_type = new _type;
            global_type->variable_data_type = strdup((yyvsp[0].expression_attr)._type_->variable_data_type);
        	  global_type->_next_ = NULL;
            global_width = (yyvsp[0].expression_attr).width;
            if(flag_return_type == 0){
              return_type = new _type;
              return_type->variable_data_type = strdup(global_type->variable_data_type);
              return_type->_next_ = NULL;
              return_width = global_width;
              flag_return_type = 2;
            }
          }
#line 4243 "y.tab.c" /* yacc.c:1646  */
    break;

  case 99:
#line 2309 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
	          (yyval.expression_attr) = (yyvsp[0].expression_attr);

		      }
#line 4252 "y.tab.c" /* yacc.c:1646  */
    break;

  case 100:
#line 2313 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
        	  (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4260 "y.tab.c" /* yacc.c:1646  */
    break;

  case 101:
#line 2318 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            _type* p = (yyvsp[0].expression_attr)._type_;
            
            if(!((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"function"))){
             (yyvsp[0].expression_attr).loc = current_symb_table->lookup_2((yyvsp[0].expression_attr).string_text);
                /*int flag8=0;
                if($1.loc == NULL && current_symb_table!=Global_symb_table)
                {
                  $1.loc = Global_symb_table->lookup_check($1.string_text);
                  if($1.loc!=NULL)
                  flag8=1;

                }
                if(flag8==1)
                $1.loc = Global_symb_table->lookup($1.string_text);
                else
              $1.loc = current_symb_table->lookup_2($1.string_text);*/
              int flag = 1;
              //If the type of the variable is not a pointer, update the type and size in the symboltable.
              if(p == NULL){       
                current_symb_table->update((yyvsp[0].expression_attr).loc,global_type,global_width,current_symb_table->offset);
                current_symb_table->offset = current_symb_table->offset + global_width;
                _type *t,*q;
                q = new _type;
                (yyvsp[0].expression_attr)._type_ = q;
                t = global_type;
                for(;t->_next_ != NULL;){
                  q->variable_data_type = strdup(t->variable_data_type);
                  q->size = t->size;
                  q->_next_ = new _type;
                  t = t->_next_;
                  q = q->_next_;
                }
                q->variable_data_type = strdup(t->variable_data_type);
                q->size = t->size;
                q->_next_ = NULL;
                (yyvsp[0].expression_attr).width = global_width;
              }
              //If it is a function declaration, then current syboltable is global symboltable.
              else {
                if(!strcmp(p->variable_data_type,"ptr")){
                  flag = 0;
                }
                while(p->_next_ != NULL){
                  p = p->_next_;
                  if(!strcmp(p->variable_data_type,"ptr") && flag == 1){
                    flag = 2;
                  }
                }
                _type *t,*q;
                q = new _type;
                t = global_type;
                while(t->_next_ != NULL){
                  q->variable_data_type = strdup(t->variable_data_type);
                  q->size = t->size;
                  q->_next_ = new _type;
                  t = t->_next_;
                  q = q->_next_;
                }
                q->variable_data_type = strdup(t->variable_data_type);
                q->size = t->size;
                q->_next_ = NULL;
                p->_next_ = q;

                //If the type is a pointer.
                if(flag == 0){

                  current_symb_table->update((yyvsp[0].expression_attr).loc,(yyvsp[0].expression_attr)._type_,8,current_symb_table->offset);
                  current_symb_table->offset = current_symb_table->offset + 8;
                  //printf("os=%d\n\n",current_symb_table->offset);
                }
                //If the type is array.
                else if(flag == 1){

                  current_symb_table->update((yyvsp[0].expression_attr).loc,(yyvsp[0].expression_attr)._type_,((yyvsp[0].expression_attr).width * global_width),current_symb_table->offset);
                  current_symb_table->offset = current_symb_table->offset + ((yyvsp[0].expression_attr).width * global_width);
                }
                //If the type is array of pointers.
                else {
                  current_symb_table->update((yyvsp[0].expression_attr).loc,(yyvsp[0].expression_attr)._type_,((yyvsp[0].expression_attr).width * 8),current_symb_table->offset);
                  current_symb_table->offset = current_symb_table->offset + ((yyvsp[0].expression_attr).width * 8);
                }             
              }
            }
            else 
            {
              current_symb_table = Global_symb_table;
              flag_return_type = 0;
              nextinstr--;
            }
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4357 "y.tab.c" /* yacc.c:1646  */
    break;

  case 102:
#line 2410 "ass6_14CS10060.y" /* yacc.c:1646  */
    {       
             _type* p = (yyvsp[-2].expression_attr)._type_;
             //If it is a function declaration, then current syboltable is global symboltable.
             if((yyvsp[-2].expression_attr)._type_ != NULL && !strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"function")){
              current_symb_table = Global_symb_table;
              flag_return_type = 0;
              nextinstr--;
             }
             else {
              (yyvsp[-2].expression_attr).loc = current_symb_table->lookup_2((yyvsp[-2].expression_attr).string_text);
                /*int flag8=0;
                if($1.loc == NULL && current_symb_table!=Global_symb_table)
                {
                  $1.loc = Global_symb_table->lookup_check($1.string_text);
                  if($1.loc!=NULL)
                  flag8=1;

                }
                if(flag8==1)
                $1.loc = Global_symb_table->lookup($1.string_text);
                else
              $1.loc = current_symb_table->lookup_2($1.string_text);
              */

              int flag = 1;
              //If the type of the variable is not a pointer, update the type and size in the symboltable.
              if(p == NULL){       
                current_symb_table->update((yyvsp[-2].expression_attr).loc,global_type,global_width,current_symb_table->offset);
                current_symb_table->offset = current_symb_table->offset + global_width;
                _type *t,*q;
                q = new _type;
                (yyvsp[-2].expression_attr)._type_ = q;
                t = global_type;
                while(t->_next_ != NULL){
                  q->variable_data_type = strdup(t->variable_data_type);
                  q->size = t->size;
                  q->_next_ = new _type;
                  t = t->_next_;
                  q = q->_next_;
                }
                q->variable_data_type = strdup(t->variable_data_type);
                q->size = t->size;
                q->_next_ = NULL;
                (yyvsp[-2].expression_attr).width = global_width;
              }
              else {
                if(!strcmp(p->variable_data_type,"ptr")){
                  flag = 0;
                }
                while(p->_next_ != NULL){
                  p = p->_next_;
                  if(!strcmp(p->variable_data_type,"ptr") && flag == 1){
                    flag = 2;
                  }
                }
                _type *t,*q;
                q = new _type;
                t = global_type;
                while(t->_next_ != NULL){
                  q->variable_data_type = strdup(t->variable_data_type);
                  q->size = t->size;
                  q->_next_ = new _type;
                  t = t->_next_;
                  q = q->_next_;
                }
                q->variable_data_type = strdup(t->variable_data_type);
                q->size = t->size;
                q->_next_ = NULL;
                p->_next_ = q;
                //If the type is a pointer.
                if(flag == 0){
                  current_symb_table->update((yyvsp[-2].expression_attr).loc,(yyvsp[-2].expression_attr)._type_,8,current_symb_table->offset);
                  current_symb_table->offset = current_symb_table->offset + 8;
                  (yyvsp[-2].expression_attr).width = 8;
                }
                //If the type is array.
                else if(flag == 1){
                  current_symb_table->update((yyvsp[-2].expression_attr).loc,(yyvsp[-2].expression_attr)._type_,((yyvsp[-2].expression_attr).width * global_width),current_symb_table->offset);
                  current_symb_table->offset = current_symb_table->offset + ((yyvsp[-2].expression_attr).width * global_width);
                  (yyvsp[-2].expression_attr).width = (yyvsp[-2].expression_attr).width * global_width;
                }
                //If the type is array of pointers.
                else {
                  current_symb_table->update((yyvsp[-2].expression_attr).loc,(yyvsp[-2].expression_attr)._type_,((yyvsp[-2].expression_attr).width * 8),current_symb_table->offset);
                  current_symb_table->offset = current_symb_table->offset + ((yyvsp[-2].expression_attr).width * 8);
                  (yyvsp[-2].expression_attr).width = (yyvsp[-2].expression_attr).width * 8;
                }             
              }
             }
             if((yyvsp[0].expression_attr)._type_ == NULL){
                char str[] = "Variable not declared at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
             }
             //Conversion of boolean expression into an integer expression.
             if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"bool")){
                convert_bool_to_int(&((yyvsp[0].expression_attr)));
             }
             if((yyvsp[0].expression_attr).is_array_id == 1 && strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"array")){
               symb_table* t = current_symb_table->gentemp();
               current_symb_table->update(t,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width,current_symb_table->offset);
               current_symb_table->offset = current_symb_table->offset + (yyvsp[0].expression_attr).width;
               emit(t->_name_,(yyvsp[0].expression_attr).array->_name_,_ARRAY_DEREFERENCE,(yyvsp[0].expression_attr).loc->_name_);
               (yyvsp[0].expression_attr).loc = t;
               (yyvsp[0].expression_attr).is_array_id = 0;
             }
             //Fundamental type conversions from $3._type_ to $1._type_ which is permissible.
             if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"int")){
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                  convert_char_to_int(&((yyvsp[0].expression_attr)));
                }
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")){
                  convert_double_to_int(&((yyvsp[0].expression_attr)));
                }
             }
             else if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"char")){
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                  convert_int_to_char(&((yyvsp[0].expression_attr)));
                }
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")){
                  convert_double_to_int(&((yyvsp[0].expression_attr)));
                  convert_int_to_char(&((yyvsp[0].expression_attr)));
                }
             }
             else if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"double")){
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                  convert_char_to_int(&((yyvsp[0].expression_attr)));
                  convert_int_to_double(&((yyvsp[0].expression_attr)));
                }
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                  convert_int_to_double(&((yyvsp[0].expression_attr)));
                }
             }
             //Warning if character/integer is assigned to a pointer and error if double is assigned to a pointer.
             else if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr")){
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
                  convert_char_to_int(&((yyvsp[0].expression_attr)));
                }
                if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
                  char str[] = "Warning : Assignment of integer to a pointer at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                }
                else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")){
                  char str[] = "Assignment of double to a pointer at line ";
                  char temporary_string[50];
                  sprintf(temporary_string,"%d",line_num);
                  strcat(str,temporary_string);
                  yyerror(str);
                  exit(1);
                }
             }
             //Warning if a non-pointer is assigned to a pointer.
             if(strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"ptr") && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"ptr")){
                char str[] = "Warning : Assignment of a pointer to a non-pointer type at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
             }
             if(!strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"array") || !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"array")){
                char str[] = "Wrong assignment of array at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
             }
             //Update the symboltable with initial values.
             if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"int")){
               current_symb_table->update((yyvsp[-2].expression_attr).loc,(yyvsp[0].expression_attr).int_val);
             }
             else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"double")){
               current_symb_table->update((yyvsp[-2].expression_attr).loc,(yyvsp[0].expression_attr).double_val);
             }
             else if(!strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"char")){
               if((yyvsp[0].expression_attr).char_val != NULL){
                 current_symb_table->update((yyvsp[-2].expression_attr).loc,(yyvsp[0].expression_attr).char_val);
               } 
             }
             (yyval.expression_attr) = (yyvsp[-2].expression_attr);
             emit((yyvsp[-2].expression_attr).loc->_name_,(yyvsp[0].expression_attr).loc->_name_);
          }
#line 4550 "y.tab.c" /* yacc.c:1646  */
    break;

  case 107:
#line 2606 "ass6_14CS10060.y" /* yacc.c:1646  */
    {

            (yyval.expression_attr)._type_ = new _type;
            (yyval.expression_attr)._type_->variable_data_type = strdup("void");
            (yyval.expression_attr)._type_->_next_ = NULL;
		      }
#line 4561 "y.tab.c" /* yacc.c:1646  */
    break;

  case 108:
#line 2612 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr).width = 1;
            (yyval.expression_attr)._type_ = new _type;
            (yyval.expression_attr)._type_->variable_data_type = strdup("char");
            (yyval.expression_attr)._type_->_next_ = NULL;
          }
#line 4572 "y.tab.c" /* yacc.c:1646  */
    break;

  case 110:
#line 2619 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
       
            (yyval.expression_attr).width = 4;
            (yyval.expression_attr)._type_ = new _type;
            (yyval.expression_attr)._type_->variable_data_type = strdup("int");
            (yyval.expression_attr)._type_->_next_ = NULL;
          }
#line 4584 "y.tab.c" /* yacc.c:1646  */
    break;

  case 113:
#line 2628 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr).width = 8;
            (yyval.expression_attr)._type_ = new _type;
            (yyval.expression_attr)._type_->variable_data_type = strdup("double");
            (yyval.expression_attr)._type_->_next_ = NULL;
          }
#line 4595 "y.tab.c" /* yacc.c:1646  */
    break;

  case 120:
#line 2642 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4603 "y.tab.c" /* yacc.c:1646  */
    break;

  case 133:
#line 2665 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
  
          }
#line 4611 "y.tab.c" /* yacc.c:1646  */
    break;

  case 138:
#line 2678 "ass6_14CS10060.y" /* yacc.c:1646  */
    {

            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4620 "y.tab.c" /* yacc.c:1646  */
    break;

  case 139:
#line 2682 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
            //If the type of direct_declarator is array then the new type is array of pointer.
            if((yyvsp[0].expression_attr)._type_ != NULL && !strcmp((yyvsp[0].expression_attr)._type_->variable_data_type,"array")){
              _type* q = (yyvsp[0].expression_attr)._type_;
              while(q->_next_ != NULL){
                q = q->_next_;
              }
              q->_next_ = (yyvsp[-1].expression_attr)._type_;
              (yyval.expression_attr)._type_ = (yyvsp[0].expression_attr)._type_;
            }
            else {
              _type* q = (yyvsp[-1].expression_attr)._type_;
              for(;q->_next_ != NULL;){
                q = q->_next_;
              }
              q->_next_ = (yyvsp[0].expression_attr)._type_;
              (yyval.expression_attr)._type_ = (yyvsp[-1].expression_attr)._type_;
            }
          }
#line 4645 "y.tab.c" /* yacc.c:1646  */
    break;

  case 140:
#line 2704 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr).string_text = strdup((yyvsp[0].string_text));
            (yyval.expression_attr)._type_ = NULL;
				    (yyval.expression_attr).width = 1;
            //To store the return type of the current function, flag_return_type is used.
            if(flag_return_type == 2 || flag_return_type == 3){
              flag_return_type = 1;
            }
			    }
#line 4659 "y.tab.c" /* yacc.c:1646  */
    break;

  case 141:
#line 2713 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
	    		  (yyval.expression_attr) = (yyvsp[-1].expression_attr);
	    	  }
#line 4667 "y.tab.c" /* yacc.c:1646  */
    break;

  case 142:
#line 2716 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             (yyval.expression_attr) = (yyvsp[-2].expression_attr);
             (yyval.expression_attr)._type_ = new _type;
             (yyval.expression_attr)._type_->variable_data_type = strdup("array");
             (yyval.expression_attr)._type_->size = 0;
             (yyval.expression_attr)._type_->_next_ = NULL;
          }
#line 4679 "y.tab.c" /* yacc.c:1646  */
    break;

  case 144:
#line 2724 "ass6_14CS10060.y" /* yacc.c:1646  */
    {

            (yyval.expression_attr).string_text = strdup((yyvsp[-3].expression_attr).string_text);
            _type* p = new _type;
            _type* q;
            //If index is character expression, convert into an integer expression.
            if(!strcmp((yyvsp[-1].expression_attr)._type_->variable_data_type,"char")){
               convert_char_to_int(&((yyvsp[-1].expression_attr)));
            }
            //The expression of the index of array has to be an integer.
            if(strcmp((yyvsp[-1].expression_attr)._type_->variable_data_type,"int")){
              char s[] = "Array indices have non-integer type at line ";
              char temporary_string[50];
              sprintf(temporary_string,"%d",line_num);
              strcat(s,temporary_string);
              yyerror(s);
              exit(1);
            }
            //Negative indices for array declaration is not allowed.
            if((yyvsp[-1].expression_attr).int_val <= 0){
              char s[] = "Array size cannot be negative at line ";
              char temporary_string[50];
              sprintf(temporary_string,"%d",line_num);
              strcat(s,temporary_string);
              yyerror(s);
              exit(1);   
            }

        	  p->variable_data_type = strdup("array");
            p->size = (yyvsp[-1].expression_attr).int_val;
        	  p->_next_ = NULL;
        	  q = (yyvsp[-3].expression_attr)._type_;
        	  //Build the width of the array.
           if(q == NULL){

              (yyval.expression_attr)._type_ = p;
              (yyval.expression_attr).width = (yyvsp[-1].expression_attr).int_val;
              //printf("hello  %d\n",$$.width);
            }
            else {
              while(q->_next_ != NULL){
                  q = q->_next_;
              }
              q->_next_ = p;
              (yyval.expression_attr)._type_ = (yyvsp[-3].expression_attr)._type_;
              (yyval.expression_attr).width = (yyvsp[-1].expression_attr).int_val * (yyvsp[-3].expression_attr).width;
              
            }
        	  	
           }
#line 4734 "y.tab.c" /* yacc.c:1646  */
    break;

  case 151:
#line 2780 "ass6_14CS10060.y" /* yacc.c:1646  */
    {

            _type* t = new _type;
            t->variable_data_type = strdup("function");
            t->_next_ = NULL;
            Global_symb_table->insert((yyvsp[-3].expression_attr).string_text,t,(yyvsp[-1].expression_attr).num_params,(yyvsp[-1].expression_attr).symbol_table_);
            current_symb_table = (yyvsp[-1].expression_attr).symbol_table_;
            (yyval.expression_attr) = (yyvsp[-3].expression_attr);
            (yyval.expression_attr)._type_ = t;
            (yyval.expression_attr).string_text = (yyvsp[-3].expression_attr).string_text;
            (yyval.expression_attr).symbol_table_ = (yyvsp[-1].expression_attr).symbol_table_;
            emit(_FUNCTION_BEGIN,(yyvsp[-3].expression_attr).string_text);
          }
#line 4752 "y.tab.c" /* yacc.c:1646  */
    break;

  case 152:
#line 2793 "ass6_14CS10060.y" /* yacc.c:1646  */
    {

            _type* t = new _type;
            t->variable_data_type = strdup("function");
            t->_next_ = NULL;
            (yyval.expression_attr) = (yyvsp[-2].expression_attr);
            (yyval.expression_attr).symbol_table_ = new symboltable;
            (yyval.expression_attr)._type_ = t;
            (yyval.expression_attr).string_text = (yyvsp[-2].expression_attr).string_text;
            Global_symb_table->insert((yyvsp[-2].expression_attr).string_text,t,0,(yyval.expression_attr).symbol_table_);
            current_symb_table = (yyval.expression_attr).symbol_table_;
            emit(_FUNCTION_BEGIN,(yyvsp[-2].expression_attr).string_text);
          }
#line 4770 "y.tab.c" /* yacc.c:1646  */
    break;

  case 154:
#line 2809 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             (yyval.expression_attr)._type_ = new _type;
             (yyval.expression_attr)._type_->variable_data_type = strdup("ptr");
             (yyval.expression_attr)._type_->_next_ = NULL;
             //If the return type of the function has a pointer, make the return type a pointer to the previous return type. 
             if(flag_return_type == 2){
              _type *p,*q;
              p = new _type;
              q = (yyval.expression_attr)._type_;
              p->variable_data_type = strdup(q->variable_data_type);
              p->_next_ = return_type;
              return_type = p;
              flag_return_type = 3;
              return_width = 8; 
            }
          }
#line 4791 "y.tab.c" /* yacc.c:1646  */
    break;

  case 156:
#line 2826 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             (yyval.expression_attr) = (yyvsp[0].expression_attr);
             _type* p = new _type;
             p->variable_data_type = strdup("ptr");
             p->_next_ = (yyvsp[0].expression_attr)._type_;
             (yyval.expression_attr)._type_ = p;
             //Make the return type pointer of the previous type and change the flag accordingly.
             if(flag_return_type == 3){
                _type *p;
                p = new _type;
                p->variable_data_type = strdup("ptr");
                p->_next_ = return_type;
                return_type = p;
                return_width = 8;
             }
          }
#line 4812 "y.tab.c" /* yacc.c:1646  */
    break;

  case 160:
#line 2849 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4820 "y.tab.c" /* yacc.c:1646  */
    break;

  case 161:
#line 2852 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[-2].expression_attr);
          }
#line 4828 "y.tab.c" /* yacc.c:1646  */
    break;

  case 162:
#line 2857 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            //Make the new function's symboltable and insert the parameter into the symboltable.
            (yyval.expression_attr).symbol_table_ = new symboltable;
            (yyval.expression_attr).symbol_table_->insert((yyvsp[0].expression_attr).string_text,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width);
            (yyval.expression_attr).num_params = 1;
          }
#line 4839 "y.tab.c" /* yacc.c:1646  */
    break;

  case 163:
#line 2863 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            //Make the new function's symboltable and insert the parameter into the symboltable.
            (yyval.expression_attr) = (yyvsp[-2].expression_attr);
            (yyval.expression_attr).symbol_table_->insert((yyvsp[0].expression_attr).string_text,(yyvsp[0].expression_attr)._type_,(yyvsp[0].expression_attr).width);
            (yyval.expression_attr).num_params = (yyvsp[-2].expression_attr).num_params + 1;
          }
#line 4850 "y.tab.c" /* yacc.c:1646  */
    break;

  case 164:
#line 2871 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             //Create the type of the parameter.
             if((yyvsp[0].expression_attr)._type_ == NULL){
               (yyval.expression_attr)._type_ = (yyvsp[-1].expression_attr)._type_;
               (yyval.expression_attr).width = (yyvsp[-1].expression_attr).width;
               (yyval.expression_attr).string_text = strdup((yyvsp[0].expression_attr).string_text);
             } 
             else {
               _type* p = (yyvsp[0].expression_attr)._type_;
               int flag = 1;
               if(!strcmp(p->variable_data_type,"ptr")){
                  flag = 0;
               }
               while(p->_next_ != NULL){
                  p = p->_next_;
                  if(!strcmp(p->variable_data_type,"ptr")){
                    flag = 0;
                  }
              }
              p->_next_ = (yyvsp[-1].expression_attr)._type_;
              if(flag == 0){
                (yyval.expression_attr)._type_ = (yyvsp[0].expression_attr)._type_;
                (yyval.expression_attr).width = 4; 
                (yyval.expression_attr).string_text = strdup((yyvsp[0].expression_attr).string_text);
              }
              else {
                (yyval.expression_attr)._type_ = (yyvsp[0].expression_attr)._type_;
                (yyval.expression_attr).width = (yyvsp[0].expression_attr).width * (yyvsp[-1].expression_attr).width;
                (yyval.expression_attr).string_text = strdup((yyvsp[0].expression_attr).string_text);
              }
             }
          }
#line 4887 "y.tab.c" /* yacc.c:1646  */
    break;

  case 165:
#line 2903 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
         }
#line 4895 "y.tab.c" /* yacc.c:1646  */
    break;

  case 166:
#line 2908 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
          
          }
#line 4903 "y.tab.c" /* yacc.c:1646  */
    break;

  case 167:
#line 2911 "ass6_14CS10060.y" /* yacc.c:1646  */
    {

          }
#line 4911 "y.tab.c" /* yacc.c:1646  */
    break;

  case 168:
#line 2916 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4919 "y.tab.c" /* yacc.c:1646  */
    break;

  case 169:
#line 2921 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
			         (yyval.expression_attr) = (yyvsp[0].expression_attr);
		      }
#line 4927 "y.tab.c" /* yacc.c:1646  */
    break;

  case 172:
#line 2928 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4935 "y.tab.c" /* yacc.c:1646  */
    break;

  case 182:
#line 2948 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4943 "y.tab.c" /* yacc.c:1646  */
    break;

  case 183:
#line 2951 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4951 "y.tab.c" /* yacc.c:1646  */
    break;

  case 184:
#line 2954 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr); 
          }
#line 4959 "y.tab.c" /* yacc.c:1646  */
    break;

  case 185:
#line 2957 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4967 "y.tab.c" /* yacc.c:1646  */
    break;

  case 186:
#line 2960 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 4975 "y.tab.c" /* yacc.c:1646  */
    break;

  case 187:
#line 2965 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            
          }
#line 4983 "y.tab.c" /* yacc.c:1646  */
    break;

  case 191:
#line 2973 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[-1].expression_attr);
          }
#line 4991 "y.tab.c" /* yacc.c:1646  */
    break;

  case 192:
#line 2978 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);  
          }
#line 4999 "y.tab.c" /* yacc.c:1646  */
    break;

  case 193:
#line 2981 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            if((yyvsp[-2].expression_attr).nextlist != NULL){
              backpatch((yyvsp[-2].expression_attr).nextlist,(yyvsp[-1].expression_attr).instr);
            }
            (yyval.expression_attr).nextlist = (yyvsp[0].expression_attr).nextlist;
          }
#line 5010 "y.tab.c" /* yacc.c:1646  */
    break;

  case 194:
#line 2989 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             (yyval.expression_attr) = (yyvsp[0].expression_attr);
             (yyval.expression_attr).nextlist = NULL;
          }
#line 5019 "y.tab.c" /* yacc.c:1646  */
    break;

  case 195:
#line 2993 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 5027 "y.tab.c" /* yacc.c:1646  */
    break;

  case 197:
#line 2999 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            //If the expression is boolean, insert its truelist and falselist into the statement's nextlist.
            if((yyvsp[-1].expression_attr).truelist != NULL && (yyvsp[-1].expression_attr).falselist != NULL){
              (yyval.expression_attr).nextlist = merge((yyvsp[-1].expression_attr).truelist,(yyvsp[-1].expression_attr).falselist);
            }
            else if((yyvsp[-1].expression_attr).truelist != NULL){
              (yyval.expression_attr).nextlist = (yyvsp[-1].expression_attr).truelist;
            }
            else if((yyvsp[-1].expression_attr).falselist != NULL){
              (yyval.expression_attr).nextlist = (yyvsp[-1].expression_attr).falselist;
            }
            else {
              (yyval.expression_attr).nextlist = NULL;
            }
            
          }
#line 5048 "y.tab.c" /* yacc.c:1646  */
    break;

  case 198:
#line 3017 "ass6_14CS10060.y" /* yacc.c:1646  */
    {   //Grammar Augmented to emit a goto and store the line number in its nextlist.
              
              (yyval.expression_attr).nextlist = makelist(nextinstr);
              char str[] = "...";
              emit(_GOTO,str);
          }
#line 5059 "y.tab.c" /* yacc.c:1646  */
    break;

  case 199:
#line 3025 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
               _list* temp_list;
               //If the expression is not boolean, then convert the expression into boolean after emitting a goto to avoid
               //checking been done more than once. Backpatch the truelist to the instruction of M
               //and create the nextlist of this statement as merge of the false list of the expression and nextlist 
               //of the statement.
               if(!(strcmp((yyvsp[-5].expression_attr)._type_->variable_data_type,"bool"))){//boolean
                  backpatch((yyvsp[-4].expression_attr).nextlist,(yyvsp[-2].expression_attr).instr);
                  backpatch((yyvsp[-5].expression_attr).truelist,(yyvsp[-2].expression_attr).instr);
                  temp_list = merge((yyvsp[-5].expression_attr).falselist,(yyvsp[0].expression_attr).nextlist);
                  (yyval.expression_attr).nextlist = merge((yyvsp[-1].expression_attr).nextlist,temp_list);
               }
               else {   //not boolean
                  backpatch((yyvsp[-4].expression_attr).nextlist,nextinstr);
                  convert_exp_to_bool(&((yyvsp[-5].expression_attr)));
                  temp_list = merge((yyvsp[-1].expression_attr).nextlist,(yyvsp[0].expression_attr).nextlist);
                  backpatch((yyvsp[-5].expression_attr).truelist,(yyvsp[-2].expression_attr).instr);
                  (yyval.expression_attr).nextlist = merge(temp_list,(yyvsp[-5].expression_attr).falselist);
               }
          }
#line 5084 "y.tab.c" /* yacc.c:1646  */
    break;

  case 200:
#line 3045 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
                  _list* temp_list;
                  //If the expression is not boolean, then convert the expression into boolean after emitting a goto to avoid
                  //checking been done more than once. Backpatch the truelist to the instruction of M1 and falselist to the 
                  //instruction of M2 and create the nextlist of this statement as nextlist of N2 and nextlist of statement.
                  if(!(strcmp((yyvsp[-8].expression_attr)._type_->variable_data_type,"bool"))){//boolean
                    temp_list = merge((yyvsp[-4].expression_attr).nextlist,(yyvsp[-3].expression_attr).nextlist);
                    (yyval.expression_attr).nextlist = merge(temp_list,(yyvsp[0].expression_attr).nextlist);
                    backpatch((yyvsp[-7].expression_attr).nextlist,(yyvsp[-5].expression_attr).instr);
                    backpatch((yyvsp[-8].expression_attr).truelist,(yyvsp[-5].expression_attr).instr);
                    backpatch((yyvsp[-8].expression_attr).falselist,(yyvsp[-1].expression_attr).instr);
                  }
                  else //not boolean
                  {
                    temp_list = makelist(nextinstr);
                    char str[] = "...";
                    emit(_GOTO,str);
                    backpatch((yyvsp[-7].expression_attr).nextlist,nextinstr);
                    convert_exp_to_bool(&((yyvsp[-8].expression_attr)));
                    temp_list = merge((yyvsp[-4].expression_attr).nextlist,temp_list);
                    temp_list = merge((yyvsp[-3].expression_attr).nextlist,temp_list);
                    (yyval.expression_attr).nextlist = merge(temp_list,(yyvsp[0].expression_attr).nextlist);
                    backpatch((yyvsp[-8].expression_attr).truelist,(yyvsp[-5].expression_attr).instr);
                    backpatch((yyvsp[-8].expression_attr).falselist,(yyvsp[-1].expression_attr).instr);
                  }
          }
#line 5115 "y.tab.c" /* yacc.c:1646  */
    break;

  case 202:
#line 3074 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
                _list* temp_list;            
                //Convert the expression into boolean and the nextlist of N has been backpatched to instruction of M2
                //and emit goto to instruction of M1.    
                if(strcmp((yyvsp[-4].expression_attr)._type_->variable_data_type,"bool")){
                    backpatch((yyvsp[-3].expression_attr).nextlist,nextinstr);
                    char s4[33];
                    sprintf(s4,"%d",(yyvsp[-5].expression_attr).instr);
                    emit(_GOTO,s4);
                    convert_exp_to_bool(&((yyvsp[-4].expression_attr)));
                    backpatch((yyvsp[0].expression_attr).nextlist,(yyvsp[-5].expression_attr).instr);
                    backpatch((yyvsp[-4].expression_attr).truelist,(yyvsp[-1].expression_attr).instr);
                    (yyval.expression_attr).nextlist = (yyvsp[-4].expression_attr).falselist;
                }
                else {
                    backpatch((yyvsp[0].expression_attr).nextlist,(yyvsp[-5].expression_attr).instr);
                    backpatch((yyvsp[-4].expression_attr).truelist,(yyvsp[-1].expression_attr).instr);
                    backpatch((yyvsp[-3].expression_attr).nextlist,(yyvsp[-1].expression_attr).instr);
                    (yyval.expression_attr).nextlist = (yyvsp[-4].expression_attr).falselist;
                    char s4[33];
                    sprintf(s4,"%d",(yyvsp[-5].expression_attr).instr);
                    emit(_GOTO,s4);
                }     
          }
#line 5144 "y.tab.c" /* yacc.c:1646  */
    break;

  case 203:
#line 3098 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
                //Convert the expression into boolean and the truelist of N has been backpatched to instruction of M1
                //and the nextlist of statement has been backpatched to instruction of M1.   
                if(strcmp((yyvsp[-2].expression_attr)._type_->variable_data_type,"bool")){ 
                    convert_exp_to_bool(&((yyvsp[-2].expression_attr)));
                }
                backpatch((yyvsp[-2].expression_attr).truelist,(yyvsp[-7].expression_attr).instr);
                backpatch((yyvsp[-6].expression_attr).nextlist,(yyvsp[-4].expression_attr).instr);
                (yyval.expression_attr).nextlist = (yyvsp[-2].expression_attr).falselist;     
          }
#line 5159 "y.tab.c" /* yacc.c:1646  */
    break;

  case 204:
#line 3108 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
             //If expression2 is not a boolean, convert it into a boolean and backpatch nextlist of statement to M2,
             //backpatch nextlist of N2 to M1 and backpatch truelist of expression2 into instruction of M3,
             //N1's goto is redundant if expression2 is boolean, else it is backpatched to nextinstr before converting 
             //expression2 into boolean.
             backpatch((yyvsp[-3].expression_attr).nextlist,(yyvsp[-9].expression_attr).instr);
             backpatch((yyvsp[0].expression_attr).nextlist,(yyvsp[-5].expression_attr).instr);
             char str[33];
             sprintf(str,"%d",(yyvsp[-5].expression_attr).instr);
             emit(_GOTO,str);
             if((yyvsp[-8].expression_attr)._type_ != NULL && strcmp((yyvsp[-8].expression_attr)._type_->variable_data_type,"bool")){
               backpatch((yyvsp[-7].expression_attr).nextlist,nextinstr);
               convert_exp_to_bool(&((yyvsp[-8].expression_attr)));
             }
             else {
               backpatch((yyvsp[-7].expression_attr).nextlist,(yyvsp[-1].expression_attr).instr);
             }
             backpatch((yyvsp[-8].expression_attr).truelist,(yyvsp[-1].expression_attr).instr);
             (yyval.expression_attr).nextlist = (yyvsp[-8].expression_attr).falselist;
          }
#line 5184 "y.tab.c" /* yacc.c:1646  */
    break;

  case 209:
#line 3134 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr)._type_ = NULL;
          }
#line 5192 "y.tab.c" /* yacc.c:1646  */
    break;

  case 210:
#line 3137 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
              (yyval.expression_attr) = (yyvsp[0].expression_attr);
          }
#line 5200 "y.tab.c" /* yacc.c:1646  */
    break;

  case 214:
#line 3145 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            //Check if the return type of the function is void or not else print error.
            if(!strcmp(return_type->variable_data_type,"void")){
              char str[] = "";
              emit(_RETURN_VOID,str);
            }
            else {
              char str[] = "Function expects non-void return type at line ";
              char temporary_string[50];
              sprintf(temporary_string,"%d",line_num);
              strcat(str,temporary_string);
              yyerror(str);
              exit(1);
            }
          }
#line 5220 "y.tab.c" /* yacc.c:1646  */
    break;

  case 215:
#line 3160 "ass6_14CS10060.y" /* yacc.c:1646  */
    {
            //Check if the return type matches with the return type of the function,then emit _RETURN else print an error message.
            if((yyvsp[-1].expression_attr)._type_ == NULL){
              char str[] = "Variable not declared at line ";
              char temporary_string[50];
              sprintf(temporary_string,"%d",line_num);
              strcat(str,temporary_string);
              yyerror(str);
              exit(1);
            }
            _type *p,*q;
            p = return_type;
            q = (yyvsp[-1].expression_attr)._type_;
            while(true){
            if(p == NULL || q == NULL)
            break;
              if((!strcmp(p->variable_data_type,"ptr") && !strcmp(q->variable_data_type,"array")) || (!strcmp(p->variable_data_type,"array") && !strcmp(q->variable_data_type,"ptr"))){

              }
              else if(strcmp(p->variable_data_type,q->variable_data_type) || p->size != q->size){
                char str[] = "Function return type mismatch at line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
              }
              p = p->_next_;
              q = q->_next_;
            }
            if(p != NULL || q != NULL){
                char str[] = "Function return type mismatch at 2 line ";
                char temporary_string[50];
                sprintf(temporary_string,"%d",line_num);
                strcat(str,temporary_string);
                yyerror(str);
                exit(1);
            }
            emit(_RETURN,(yyvsp[-1].expression_attr).loc->_name_);
          }
#line 5265 "y.tab.c" /* yacc.c:1646  */
    break;


#line 5269 "y.tab.c" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 3202 "ass6_14CS10060.y" /* yacc.c:1906  */


void yyerror(char s[])
{
   printf("%s\n",s);       
}
