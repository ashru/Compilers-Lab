
//testing pointers and input 
int *f(int a)
{
    int b;
   
    b = a;
    

    b = b + 2;
    int *k;
    k=&b;
    return k;
}
int main()
{
    int a,b;
    int *e;
    
    prints("***********************Some test outputs!!*************************\n");
    
    b = 3;
    e = &b;

    prints("Returning  pointers from function f!\n");
    prints("Value passed to function: ");
    printi(b);
    prints("\n");
    e = f(b);
    a=*e;
    prints("Value returned from function s is: ");
    printi(a);
    prints("\n");
    
    prints("Read an integer!!");
    prints("\n");
    int p;
    b = readi(&p);
    prints("The integer that was read is:");
    printi(b);
    prints("\n");
    
   
    
    return 0;
}
