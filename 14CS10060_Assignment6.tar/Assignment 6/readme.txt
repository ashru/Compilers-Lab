Assignment 6

Name:Ashrujit Ghoshal
Roll No-14CS10060

ass6_14CS10060.l ,ass6_14CS10060.y are the relevant .l ,.y files
ass6_14CS10060_translator.h,ass6_14CS10060_translator.cxx are relevant translator files.
ass6_14CS10060_target_translator.cxx  is the relevant file that generates  target assembly code

libmyl.a,myl.h,myl.c,myl.o are files from assignment 2 submissin for input output libraries



ass6_14CS10060_test1.c,
ass6_14CS10060_test2.c,
ass6_14CS10060_test3.c,
ass6_14CS10060_test4.c,
ass6_14CS10060_test5.c
are the 5 test files and the symbol tables and quads generated are stored in:

ass6_14CS10060_quads1.out,
ass6_14CS10060_quads2.out,
ass6_14CS10060_quads3.out,
ass6_14CS10060_quads4.out,
ass6_14CS10060_quads5.out

The target assembly code are stored in:
ass6_14CS10060_1.asm,
ass6_14CS10060_2.asm,
ass6_14CS10060_3.asm,
ass6_14CS10060_4.asm,
ass6_14CS10060_5.asm
The above files are same as:
ass6_14CS10060_1.s,
ass6_14CS10060_2.s,
ass6_14CS10060_3.s,
ass6_14CS10060_4.s,
ass6_14CS10060_5.s
(.asm was generated only to follow naming convention in the problem statement. .s was used to generate .o file)


Type :
make to compile.
make clean to remove.
make test<test_number>  to test all corresponding test file



Note:
Shortcomings:
datatypes were restricted to int, char, char*,int*,void, void*
