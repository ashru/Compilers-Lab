//testing recursive functions with more than one parameter

int gcd(int m, int n)
{
    if (n!=0)
    {
		int a, b;
		a = m % n;
		b = gcd(n, a);
	        return b;
    }
    else 
       return m;
}

int main()
{
	int a, b, c, p;
	prints("****************Recursive GCD****************\n");
	prints("Enter a positive number(a) :");
	a = readi(&p);
	prints("Enter a positive number(b) :");
	b = readi(&p);	
	prints("The gcd of ");
	printi(a);
	prints(" & ");
	printi(b);
	prints(" is : ");
	c = gcd(a, b);
	printi(c);
	prints("\n");	
	return 0;
}
