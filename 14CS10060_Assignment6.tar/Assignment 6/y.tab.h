/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    KEYWORD_AUTO = 258,
    KEYWORD_BREAK = 259,
    KEYWORD_CASE = 260,
    KEYWORD_CHAR = 261,
    KEYWORD_CONST = 262,
    KEYWORD_CONTINUE = 263,
    KEYWORD_DEFAULT = 264,
    KEYWORD_DO = 265,
    KEYWORD_DOUBLE = 266,
    KEYWORD_ELSE = 267,
    KEYWORD_ENUM = 268,
    KEYWORD_EXTERN = 269,
    KEYWORD_FLOAT = 270,
    KEYWORD_FOR = 271,
    KEYWORD_GOTO = 272,
    KEYWORD_IF = 273,
    KEYWORD_INLINE = 274,
    KEYWORD_INT = 275,
    KEYWORD_LONG = 276,
    KEYWORD_REGISTER = 277,
    KEYWORD_RESTRICT = 278,
    KEYWORD_RETURN = 279,
    KEYWORD_SHORT = 280,
    KEYWORD_SIGNED = 281,
    KEYWORD_SIZEOF = 282,
    KEYWORD_STATIC = 283,
    KEYWORD_STRUCT = 284,
    KEYWORD_SWITCH = 285,
    KEYWORD_TYPEDEF = 286,
    KEYWORD_UNION = 287,
    KEYWORD_UNSIGNED = 288,
    KEYWORD_VOID = 289,
    KEYWORD_VOLATILE = 290,
    KEYWORD_WHILE = 291,
    KEYWORD_BOOL = 292,
    KEYWORD_COMPLEX = 293,
    KEYWORD_IMAGINARY = 294,
    ARROW = 295,
    PLUS_PLUS = 296,
    MINUS_MINUS = 297,
    SHIFT_LEFT = 298,
    SHIFT_RIGHT = 299,
    LESS_EQUAL = 300,
    GREATER_EQUAL = 301,
    IS_EQUAL = 302,
    NOT_EQUAL = 303,
    LOGICAL_AND = 304,
    LOGICAL_OR = 305,
    ELLIPSIS = 306,
    STAR_EQUAL = 307,
    DIVIDE_EQUAL = 308,
    MODULO_EQUAL = 309,
    PLUS_EQUAL = 310,
    MINUS_EQUAL = 311,
    SHIFT_LEFT_EQUAL = 312,
    SHIFT_RIGHT_EQUAL = 313,
    AND_EQUAL = 314,
    XOR_EQUAL = 315,
    OR_EQUAL = 316,
    identifier = 317,
    integer_constant = 318,
    floating_constant = 319,
    character_constant = 320,
    string_literal = 321,
    IFEND = 322,
    ELSE = 323
  };
#endif
/* Tokens.  */
#define KEYWORD_AUTO 258
#define KEYWORD_BREAK 259
#define KEYWORD_CASE 260
#define KEYWORD_CHAR 261
#define KEYWORD_CONST 262
#define KEYWORD_CONTINUE 263
#define KEYWORD_DEFAULT 264
#define KEYWORD_DO 265
#define KEYWORD_DOUBLE 266
#define KEYWORD_ELSE 267
#define KEYWORD_ENUM 268
#define KEYWORD_EXTERN 269
#define KEYWORD_FLOAT 270
#define KEYWORD_FOR 271
#define KEYWORD_GOTO 272
#define KEYWORD_IF 273
#define KEYWORD_INLINE 274
#define KEYWORD_INT 275
#define KEYWORD_LONG 276
#define KEYWORD_REGISTER 277
#define KEYWORD_RESTRICT 278
#define KEYWORD_RETURN 279
#define KEYWORD_SHORT 280
#define KEYWORD_SIGNED 281
#define KEYWORD_SIZEOF 282
#define KEYWORD_STATIC 283
#define KEYWORD_STRUCT 284
#define KEYWORD_SWITCH 285
#define KEYWORD_TYPEDEF 286
#define KEYWORD_UNION 287
#define KEYWORD_UNSIGNED 288
#define KEYWORD_VOID 289
#define KEYWORD_VOLATILE 290
#define KEYWORD_WHILE 291
#define KEYWORD_BOOL 292
#define KEYWORD_COMPLEX 293
#define KEYWORD_IMAGINARY 294
#define ARROW 295
#define PLUS_PLUS 296
#define MINUS_MINUS 297
#define SHIFT_LEFT 298
#define SHIFT_RIGHT 299
#define LESS_EQUAL 300
#define GREATER_EQUAL 301
#define IS_EQUAL 302
#define NOT_EQUAL 303
#define LOGICAL_AND 304
#define LOGICAL_OR 305
#define ELLIPSIS 306
#define STAR_EQUAL 307
#define DIVIDE_EQUAL 308
#define MODULO_EQUAL 309
#define PLUS_EQUAL 310
#define MINUS_EQUAL 311
#define SHIFT_LEFT_EQUAL 312
#define SHIFT_RIGHT_EQUAL 313
#define AND_EQUAL 314
#define XOR_EQUAL 315
#define OR_EQUAL 316
#define identifier 317
#define integer_constant 318
#define floating_constant 319
#define character_constant 320
#define string_literal 321
#define IFEND 322
#define ELSE 323

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 27 "ass6_14CS10060.y" /* yacc.c:1909  */

	struct expression_attributes expression_attr;
  int int_val;
  double double_val;
  char* string_text;

#line 197 "y.tab.h" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
