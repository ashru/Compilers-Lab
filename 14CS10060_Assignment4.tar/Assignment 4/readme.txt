Assignment 4

Name:Ashrujit Ghoshal
Roll No-14CS10060

ass4_14CS10060.l ,ass4_14CS10060.y are the relevant .l ,.y files
ass4_14CS10060.c is the file containing the main method
ass4_14CS10060_test.c is the test file

type make in terminal to compile
type make test in terminal to test the lexer on the test file.The output is ritten on th file test_out.txt(alternatively ./a.out<ass3_14CS10060_test.c can be used to get the output on the terminal)

I have printed the rules while parsing in the .y file.There is 1 shift reduce conflict(the dangling else oe). Bison gives precedence to shift which serves our purpose.