int barfun(int *p,...);

int main(){
	int x,z;
	char c;
	

	x=5;

	int s,v,f,lo,v4,f1,f2,p,q,v1,v2;


	if(x==4) goto mylabel;
	static int y=2;
	x=y+z;
    y++;
    long long int a=0;
    char dum[]={'a','s','h','r','u','j','i','t'};
    mylabel:y=y<<1;
   
    char output[10000];

	extern char* strout;
	int d; //asdfasdfasfdasdf
	int a9;
	float b;
	a9=4;
	b=(float)a9;
	d=++a;
	a9=d--;
	x=((a9>d)||(a9==d));
	b=1.732E-19;
	b=-0.23E-13;
	x-=y;
    x<<=y;
    x>>=y;
    x&=y;
    x^=y;
	lo+=a9;
	double doub=22.32;
	doub-=a9;
	b/=a9;
	d^=a9;
	d=!a9;
	int i=1;
	while(i<2){
		a++;
		a9%=a9;
		a9*=a9;
	}
	int *ptr;
	ptr=&a9;
	d=*(ptr);
	a=d==a9?1:0;
	a=a && d;
	a= a|| d;
	a|=d;
	a&=d;
	a=~a;
	d=!d;
	int p1=sizeof(a);
	
	if(v4 == f1){
		int r = 90;
		if(p>q || v1<=f1 && v2!=f2){
			p = q +p;
			p=q*q;
			p=q-q/q;
			q%=p;
			++q;

		}
	}
	else{
		if(s % 2 == 1) return -1;
	}
	int g,h;
	switch(i){
		case 1:
			g=0;
			do
			{
				++g;
			}
			while(g<5);
			break;
		case 2:
			h=0;
			while(h<5)
				++h;
			break;
		default:break;
	}
	for(i=1;i<10;i++){
		int a=1;
		a+=s;
	}
	int retf=barfun(&i);
	
}

int barfun(int* p,...){
	int MOD=100007,n=15,sum=0;
	if(n==13)return 1;
	if(n<13)return 2;
	int a[7];
	int i=15;
	while(i<n){
		a[1]=sum;
		sum=5;
		sum%=MOD;
		i+=2;
	}
	return sum%MOD;
}
