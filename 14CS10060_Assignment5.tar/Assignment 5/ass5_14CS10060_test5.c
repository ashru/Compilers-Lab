//test global variable,all operators(arithmetic, logical,bitwise)
int k;//global variable
void test5(int c);
void main()
{
	k=10;
	test5(k);
}
void test5(int c)
{
	c++;
	c*=5;
	int d=c--;
	c=c|d;
	d=~c;
	c=c+d;
	d=d*c;
	d=d%5;
	c=c^d;
	int a,b;
	a=c && d;
	a=c || d;
	b=!d;
	a=a & b;
	b=b & d;
	a=b | c;
	a=a>>2;
	b=b<<2;
	a+=1;
	a++;
	++a;
	--a;
	a--;
	if(a==b)
		a=b>c?b:c;
	if(a!=b)
		++c;
	if(a<b)
		++b;
	if(a>b)
		++d;
	if(a>=b)
		++a;
	if(a<=b)
		a=0;

}