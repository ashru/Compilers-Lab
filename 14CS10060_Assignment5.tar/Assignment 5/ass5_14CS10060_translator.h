#ifndef __ASS5_14CS10060_TRANSLATOR_H
#define __ASS5_14CS10060_TRANSLATOR_H

#define MAX_SIZE 100000




//A linked_list structure for storing type. member variable_data_type stores base type like int,char,double,ptr or array.
//member size is used for arrays to store the size/index of the array and member next points to a _type object.
typedef struct _type{
	char* variable_data_type;
	int size;
	struct _type* _next_;
}_type;

typedef union init{
	int int_value;
	double double_value;
	char* string_lit;
}init_value;

//forward declaration of symboltable.
class symboltable;
//struct for a symboltable entry. name stores the name of the variable it stores.
// _type_ stores the type of the variable it stores. _size_ stores the size of the variable type.
// _offset_ stores the offset of the variable in the symboltable. _nested_table_ stores the symboltable
// of the function if this variable is a function, else it is NULL. num_params stores number of parameters
// if this variable is a function. init_val stores the initialization value of the variable.
typedef struct symb_table{
	char* _name_;
	_type* _type_;
	int num_params;
	init_value _init_val_;
	int _size_;
	int _offset_;
	symboltable* _nested_table_;
	
}symb_table;

//Structure for constant table.
typedef struct Constant_Table{
	char* label;
	char* constant;
	struct Constant_Table* next;
}constant_table;

//symboltable class which contains an array of symboltable entries and num_entries_ is the number of entries in it.
//offset stores the current offset of the symboltable.
class symboltable{
public : 
	symb_table _symboltable_[MAX_SIZE];
	int number_of_entries;
	int offset;
	constant_table* _constant_table_;

	symboltable();
	symb_table* lookup(char* s);      // function lookup is used for getting the symboltable entry with variable name s.
	symb_table* lookup_2(char* s);  // function lookup_2 is used for inserting a new variable into the symboltable
								  // after checking if it is declared for the first time.
	symb_table* lookup_check(char *s);// checks whether it is present in table(no insertion)
	symb_table* gentemp();            // function for generating and inserting a temporary variable in the symboltable.
	void print();                 // function for printing the symboltable.
	void update(symb_table* symb_table_entry,_type* t,int width,int offset); // function for updating different parameters 
								  // of a symboltable entry.
	void update(symb_table* symb_table_entry,int int_val);//To initiliaze init_value with an integer value.
	void update(symb_table* symb_table_entry,double double_val);//To initiliaze init_value with a double value.
	void update(symb_table* symb_table_entry,char* char_val);//To initiliaze init_value with a character value.
	
	void insert(char* s,_type* t,int width); // function for inserting a new variable with name s and type *t and 
								  // size width.
	void insert(char* s,_type* t,int num_params,symboltable* symbol_table); // function for inserting a function into
								  // a symboltable with num_params and symboltable of the function.
	char* generate_constant_label(char* s); // Generate a label for each new string literal.
};



//enum for Op_codes for Quad array.
typedef enum{
	//binary operators.
	_ADD = 1,
	_SUBTRACT,
	_PRODUCT,
	_DIVIDE,
	_UNARY_AND,
	_MODULO,
	_SHIFT_LEFT,
	_SHIFT_RIGHT,
	_XOR,
	_UNARY_OR,
	_LOGICAL_AND,
	_LOGICAL_OR,
	_LESS,
	_GREATER,
	_IS_EQUAL,
	_NOT_EQUAL,
	_LESS_EQUAL,
	_GREATER_EQUAL,

	//unary operators.
	_UNARY_SUBTRACT,
	_UNARY_ADD,
	_COMPLEMENT,
	_NOT,

	//Conditional jump operators.
	_CONDITIONAL_LESS,
	_CONDITIONAL_GREATER,
	_CONDITIONAL_LESS_EQUAL,
	_CONDITIONAL_GREATER_EQUAL,
	_CONDITIONAL_IS_EQUAL,
	_CONDITIONAL_NOT_EQUAL,
	_CONDITIONAL_EXPRESSION,
	_CONDITIONAL_NOT_EXPRESSION,
	//Unconditional jump.
	_GOTO,

	//assignment operator.
	_COPY,

	//Array Access and Dereferencing.
	_ARRAY_ACCESS,
	_ARRAY_DEREFERENCE,

	//Procedure Call.
	_PARAM,
	_CALL,

	//Return Value
	_RETURN_VOID,
	_RETURN,

	//Address and Pointer Assignment Instructions.
	_REFERENCE,
	_DEREFERENCE,
	_POINTER_ASSIGNMENT,

	//Type Conversions.
	_INT_TO_DOUBLE,
	_CHAR_TO_INT,
	_DOUBLE_TO_INT,
	_INT_TO_CHAR,

	//Function operation_codes.
	_FUNCTION_BEGIN,
	_FUNCTION_END,

	//Inc and Dec operators.
	_INCREMENT,
	_DECREMENT
	
}operation_code;



//class Quad with private members operation_code, argument1 , argument2 and result.
class Quad{

public :

	operation_code op_code;
	char *result,*arg1,*arg2;


	Quad(operation_code op,char* result1,char* argument1,char* argument2 = 0); //Quad Constructor for binary or unary operations.
	Quad(operation_code op,char* result1,int int_num); //Quad for assignment of integer into result variable.
	Quad(operation_code op,char* result1,double double_num); //Quad for assignment of double into result variable.
	Quad(operation_code op,char* result1); //Quad for operation_codes like GOTO and Return.

	void update(char* result1); //Update function for backpatching result in operation_code _GOTO.
	void print(); //Print function which prints a quad.
};

extern symboltable* Global_symb_table; // Global Symboltable.
extern symboltable* current_symb_table;   // Current symboltable.
extern Quad* Quad_array[MAX_SIZE]; // Quad Array of size MAX_SIZE.
extern int nextinstr;              // Global variable nextinstr storing the count of Quads in Quad Array.
extern int line_num;			   // Global variable line_num storing the line number of the input program.
extern void yyerror(char* s);      // Function yyerror for printing an error.
extern _type* global_type;		   // Global variable global_type used for storing type while declaration.
extern int global_width;		   // Global variable global_width used for storing width while declaration.	

// structure list used for truelist, falselist and nextlist where _index_ stores the index of Quad Array and _next_
// points to the next object in the list.
typedef struct _list_{
	int _index_;
	struct _list_* _next_;
}_list;

// structure function_list used for parameter_list where loc stores the symboltable entry of the parameter,
// _type_ stores the type of the parameter, width stores the width of the parameter and _next_
// points to the next object in the parameter list.
typedef struct function_list{
	symb_table* loc;
	_type* _type_;
	int width;
	struct function_list* _next_;
}function_list;

//loc stores a pointer to the symboltable entry of the variable it is referring to.
//_type_ is a pointer to a _type object storing the type of the variable it is referring to.
//width is the size of the variable it is referring to.
//is_l_val = 0 => it is a l-value , is_l_val = 1 => it is a r-value.
//is_array_id = 1 => it is an array . is_array_id = 0 => the postfix_expression is not an array.
//array stores a pointer to the symboltable entry of the array identifier.
//num_params stores the number of parameters if it is a function/parameter_list attribute.
//instr stores the nextinstruction for M type.
//parameter_list stores the list of parameters if it is a function call.
//symbol_table_ stores the symboltable while declaration/definition of the function.
//truelist stores the dangling indices of the symboltable entries which have same exits as the true exit of this expression.
//falselist stores the dangling indices of the symboltable entries which have same exits as the false exit of this expression.
//nextlist stores the dangling indices of the symboltable entries which have same exits as the exit of this statement.
//int_val stores integer value,double_val stores double value,string_text is used for storing the name of the identifier (looked up later).
//is_pointer_type is a flag used for checking if the assignment is a pointer dereferencing assignment.
//pointer stores the symboltable entry of the pointer which has to be dereferenced.
typedef struct expression_attributes{
	symb_table* loc;
	_type* _type_;
	_list *truelist;
	_list *falselist;
	_list *nextlist;
	int width;
	symb_table* array;
	int is_array_id;
	int is_l_val;
	int num_params;
	int instr;
	function_list* parameter_list;
	symboltable* symbol_table_; 
	int is_pointer_type;
	symb_table* pointer;
	int int_val;
	double double_val;
	char* string_text;
	char* char_val;
}e_attr;

//Function emit() for binary 3-address codes.
void emit(char *result,char* arg1,operation_code op,char* arg2);

//Function emit() for unary 3-address codes.
void emit(char *result,char* arg1,operation_code op);

//Function emit() for copy 3-address code.
void emit(char* result,char* arg1);
void emit(char* result,int int_num);
void emit(char* result,double double_num);

//Function emit() for instructions which only have result like goto, param and return.
void emit(operation_code op,char* result);

_list* makelist(int i); // Makes a list having index as i.
_list* merge(_list* p1,_list* p2); // Returns a merged list of two lists p1 and p2.
void backpatch(_list *p,int i); //backpatches indices in the list with value i.
void typecheck(e_attr* E1,e_attr* E2); //Checks type between E1 and E2 expressions (only up conversions done).
void convert_int_to_double(e_attr* E); //Converts expression E from int to double.
void convert_char_to_int(e_attr* E); //Converts expression E from char to int.
void convert_bool_to_int(e_attr* E); //Converts expression E from bool to int.
void convert_double_to_int(e_attr* E); //Converts expression E from double to int.
void convert_int_to_char(e_attr* E); //Converts expression E from int to char.
void convert_exp_to_bool(e_attr* E); //Converts expression E to bool.
_type* obtain_data_type(symb_table* sym_entry); //Returns the type of variable stored in sym_entry of the current symboltable.
int getwidth(symb_table* sym_entry); //Returns the width of variable stored in sym_entry of the current symboltable.
function_list* make_function_list(symb_table* sym_entry,_type* t,int width); //Makes a function_list/parameter_list with a parameter having type t
											// and size width and symboltable entry sym_entry.
function_list* merge_function_list(function_list* p1,function_list* p2); //Merges two function_lists p1 and p2 and returns the merged function_list.





#endif
