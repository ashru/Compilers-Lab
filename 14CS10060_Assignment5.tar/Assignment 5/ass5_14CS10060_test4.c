//Test array declarations 
int add_modulus(int a[10][5], int b[10],int n);
void main();
int add_modulus(int a[10][5],int b[10] ,int n) {
       int ans = 0, i, j ;
       for(i=0;i<10;++i)
       {
        for(j=0;j<5;++j)
          ans=(ans+a[i][j]+n)%b[i];
       }
       return ans;
}

void main() {
       int a[10][5], b[10];
       add_modulus(a,b,5);
       int test [50][60][100][6];
       test[0][0][0][0]=0;
       return;
}
