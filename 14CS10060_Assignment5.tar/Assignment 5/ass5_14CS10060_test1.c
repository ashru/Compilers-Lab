/*Testing control constructs ,return statements,conditional operator*/
void test_for(int n);
void test_while(int n);
void test_do_while(int n);
void test_if(int n);
void test_if_else(int n);
int main()
{
	int d=5;
test_for(d);
test_while(d);
test_do_while(d);
test_if(d);
test_if_else(d);
d=d>5?50:100;
return 0;

}
void test_for(int n)
{
	int i,j,k=0;
	for(i=0;n-i;++i)
	{
		for(j=0;j<i;++j)
		{
			k++;
		}
	}
	return;
}
void test_while(int n)
{
	int i;
	while(n--)
	{
		i++;

	}
	return;
}

void test_do_while(int n)
{
	do{
		n=n*10;
	}
	while(n<150);
	return;
	
}
void test_if(int n)
{
	if (n)
		return;
	return;
}
void test_if_else(int n)
{
	int i;
	if(n>50)
		return;
	i=10;
	return;

}