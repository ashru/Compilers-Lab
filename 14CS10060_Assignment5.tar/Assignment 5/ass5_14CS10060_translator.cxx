#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <bits/stdc++.h>
#include "ass5_14CS10060_translator.h"
#include "y.tab.h"

using namespace std;

#ifdef YYDEBUG
extern int yydebug;
#endif
int goto_label_id = 0;
vector<pair<int,char *> > goto_labels; 
int num_functions = 0;
int parameters_size = 0;
vector<int> parameter_stack;



char* symboltable::generate_constant_label(char* s)
{
	static int constant_count = 0;
	char* str;
	char t[10];
	sprintf(t,".LC%05d",constant_count);
	constant_count++;
	str = strdup(t);
	constant_table *constants,*temp_constant_entry;
	temp_constant_entry = new constant_table;
	temp_constant_entry->label = strdup(t);
	temp_constant_entry->constant = strdup(s);
	temp_constant_entry->next = NULL;
	constants = this->_constant_table_;
	if(constants == NULL){
		this->_constant_table_ = temp_constant_entry;
	}
	else {
		while(constants->next != NULL){
			constants = constants->next;
		}
		constants->next = temp_constant_entry;
	}
	return str;	
}

//This prints the symboltable in a suitable format.
void symboltable::print()
{
	symb_table* sp;
	
	cout << setfill (' ') << left << setw(16) << "Name";
	cout << left << setw(16) << "Type";
	cout << left << setw(12) << "Init Val";
	cout << left << setw(8) << "Size";
	cout << left << setw(8) << "Offset";
	cout << left << "Nested Table" << endl;
	cout << setw(80) << setfill ('-') << "-"<< setfill (' ') << endl;
	
	for(sp = this->_symboltable_;sp < &(this->_symboltable_[MAX_SIZE]);sp++){
		if(sp->_name_){
			
			cout<<left<<setw(16)<<sp->_name_;
			_type* t = sp->_type_;
			if(t == NULL){
				
				cout<<left<<setw(16)<<"NULL";
			}
			else if(t->_next_ == NULL){
				
				cout<<left<<setw(16)<<t->variable_data_type;
				if(!strcmp(t->variable_data_type,"int")){
					
					cout<<left<<setw(12)<<sp->_init_val_.int_value;
				}
				else if(!strcmp(t->variable_data_type,"double")){
					
					cout<<left<<setw(12)<<sp->_init_val_.double_value;
				}
				else if(!strcmp(t->variable_data_type,"char")){
					
					cout<<left<<setw(12)<<sp->_init_val_.string_lit;
				}
				else {
					cout<<left<<setw(12)<<"NULL";
					
				}
			}
			else {
				while(t->_next_ != NULL) {
					printf("%s(%d , ",t->variable_data_type,t->size);
					t = t->_next_;
				}
				printf("%s) \t ",t->variable_data_type);
				
				cout<<left<<setw(12)<<"NULL";
			}
			
			cout<<left<<setw(8)<<sp->_size_;
			cout<<left<<setw(8)<<sp->_offset_;
			if(sp->_nested_table_ == NULL){
				printf("NULL\n");
			}
			else {
				printf("%s\n",sp->_name_);
			}
		}
	}
}

//This function updates a symboltable entry with type &t, size width and offset as offset.
void symboltable::update(symb_table* symb_table_entry,_type* t,int width,int offset)
{
	_type *p,*q;
	symb_table_entry->_type_ = new _type;
	p = symb_table_entry->_type_;
	if(t == NULL){
		symb_table_entry->_type_ = NULL;
	}
	else {
		q = t;
		for(;q->_next_ != NULL;){
			p->variable_data_type = strdup(q->variable_data_type);
			p->size = q->size;
			p->_next_ = new _type;
			p = p->_next_;
			q = q->_next_;
			
		}
		p->variable_data_type = strdup(q->variable_data_type);
		p->size = q->size;
		p->_next_ = NULL;
	}	
	symb_table_entry->_size_ = width;
	symb_table_entry->_offset_ = offset;
}

//To initiliaze init_value with an integer value.
void symboltable::update(symb_table* symb_table_entry,int int_val)
{
	symb_table_entry->_init_val_.int_value = int_val;
}

//To initiliaze init_value with a double value.
void symboltable::update(symb_table* symb_table_entry,double double_val)
{
	symb_table_entry->_init_val_.double_value = double_val;
}

//To initiliaze init_value with a character value.
void symboltable::update(symb_table* symb_table_entry,char* char_val)
{
	symb_table_entry->_init_val_.string_lit = strdup(char_val);
}


//This function checks if the variable is present in symboltable or not, if it is present it gives a redeclaration error
//else it creates a new entry with this variable name, type &t and size width.
void symboltable::insert(char *s,_type* t,int width)
{
	symb_table* sp;
	for(sp = this->_symboltable_;sp < &(this->_symboltable_[MAX_SIZE]);sp++){
		if(sp->_name_ && !strcmp(sp->_name_,s)){
			char str[] = "Redeclaration of variable at line ";
			char temporary_string[50];
            sprintf(temporary_string,"%d",line_num);
            strcat(str,temporary_string);
            yyerror(str);
			exit(1);
		}
		if(!sp->_name_){
			sp->_name_ = strdup(s);
			sp->_size_ = width;
			_type *p,*q;
			sp->_type_ = new _type;
			p = sp->_type_;
			q = t;
			for(;q->_next_ != NULL;){
				p->variable_data_type = strdup(q->variable_data_type);
				p->size = q->size;
				p->_next_ = new _type;
				q = q->_next_;
				p = p->_next_;
			}
			p->variable_data_type = strdup(q->variable_data_type);
			p->size = q->size;
			p->_next_ = NULL;
			sp->_offset_ = this->offset;
			this->offset = this->offset + width;
			
			this->number_of_entries++;
			return ;
		}
	}
	char str[] = "Overflow ofsymbols!!\n";
	yyerror(str);
	exit(1);
}

//This function inserts a function into the symboltable.It checks if the variable is present in symboltable or not,
// if it is present then it matches the parameters with the previous declaration,if it is different then it gives a redeclaration error
//else it creates a new entry with this function name, type &t and number of parameters num_params and a pointer to its symboltable.
void symboltable::insert(char* s,_type* t,int num_params,symboltable* symbol_table)
{
	symb_table* sp;
	for(sp = this->_symboltable_;sp < &(this->_symboltable_[MAX_SIZE]);sp++){
		if(sp->_name_ && !strcmp(sp->_name_,s)){
			int flag_var = 0,i = 0;
			if(sp->_nested_table_ == NULL){
				flag_var = 1;
			}
			else {
				if(sp->num_params != num_params){
					flag_var = 1;
				}
				else {
					symb_table* p = &(sp->_nested_table_->_symboltable_[i]);
					symb_table* q = &(symbol_table->_symboltable_[i++]);
					while(p->_name_){
						_type *t1 = p->_type_;
						_type *t2 = q->_type_;
						while(t1 != NULL && t2 != NULL){
							if(strcmp(t1->variable_data_type,t2->variable_data_type) || t1->size != t2->size){
								flag_var = 1;
								break;
							}
							t1 = t1->_next_;
							t2 = t2->_next_;
						}
						if(t1 != NULL || t2 != NULL){
							flag_var = 1;
						}
						if(flag_var == 1){
							break;
						}
						p = &(sp->_nested_table_->_symboltable_[i]);
					    q = &(symbol_table->_symboltable_[i++]);
					}	
				}	
			}
			if(flag_var == 1)
			 {

			 	char str[] = "Redeclaration of function at line ";
				char temporary_string[50];
            	sprintf(temporary_string,"%d",line_num);
            	strcat(str,temporary_string);
            	yyerror(str);
				exit(1);
				
				
			}	
			else {
				sp->_nested_table_ = symbol_table;
				
			}
			return;
		}
		else if(!sp->_name_){
			sp->_name_ = strdup(s);
			sp->_nested_table_ = symbol_table;
			_type *p,*q;
			sp->_type_ = new _type;
			p = sp->_type_;
			q = t;
			for(;q->_next_ != NULL;){
				p->variable_data_type = strdup(q->variable_data_type);
				p->size = q->size;
				p->_next_ = new _type;
				q = q->_next_;
				p = p->_next_;
			}
			p->variable_data_type = strdup(q->variable_data_type);
			p->size = q->size;
			p->_next_ = NULL;
			sp->_offset_ = this->offset;
			sp->num_params = num_params;
			this->number_of_entries++;
			return ;
		}
	}
	char str[] = "Overflow ofsymbols!!\n";
	yyerror(str);
	exit(1);
}

//This function returns the type of a symboltable entry.
_type* obtain_data_type(symb_table* sym_entry)
{
	_type *p,*q,*temp;
	p = sym_entry->_type_;
	if(p == NULL){
		return NULL;
	}
	q = new _type;
	temp = q;
	for(;p->_next_ != NULL;){
		q->variable_data_type = strdup(p->variable_data_type);
		q->size = p->size;
		q->_next_ = new _type;
		q = q->_next_;
		p = p->_next_;
	}
	q->variable_data_type = strdup(p->variable_data_type);
	q->size = p->size;
	q->_next_ = NULL;
	return temp;
}

//This function returns the size of a symboltable entry.
int getwidth(symb_table* sym_entry)
{
	return sym_entry->_size_;
}

//This function makes a list with index as i and returns a pointer to the list.
_list* makelist(int i)
{
	_list* new_list = new _list;
	new_list->_index_ = i;
	new_list->_next_ = NULL;
	return new_list;
}

//This function merges two lists p1 and p2 by concatenating p2 into p1.
_list* merge(_list* p1,_list* p2)
{
	if(p1 == NULL){
		return p2;
	}
	if(p2 == NULL){
		return p1;
	}
	_list* p = p1;
	while(p->_next_ != NULL){
		p = p->_next_;
	}
	p->_next_ = p2;
	return p1;
}	

//A function that creates a new goto label for a quad instruction.
char* gengotolabel()
{
   char* s;
   char t[50];
   s = strdup(".L");
   sprintf(t,"%d",goto_label_id);
   goto_label_id++;
   strcat(s,t);
   return s; 
}

//This function searches if there is any goto label associated with Quad's index line_num.
int find_goto_label(int line_num)
{
	int i=0;
	while(i<goto_labels.size()){
	
		if(goto_labels[i].first == line_num){
			return i;
		}
		++i;
	}
	return -1;
}

//Quad constructor for binary/unary operators.
Quad::Quad(operation_code op,char* result_,char* argument1,char* argument2) : op_code(op)
{
	result = strdup(result_);
	arg1 = strdup(argument1);
	if(argument2 ){
		arg2 = strdup(argument2);
	}
}

//Quad constructor for assignment to integer operation.
Quad::Quad(operation_code op,char* result_,int int_num) : op_code(op)
{
	result = strdup(result_);
	arg1 = new char[50];
	sprintf(arg1,"%d",int_num);
} 

//Quad constructor for assignment to floating number operation.
Quad::Quad(operation_code op,char* result_,double double_num) : op_code(op)
{
	result = strdup(result_);
	arg1 = new char[100];
	sprintf(arg1,"%lf",double_num);
} 

//Quad constructor for goto and return operation.
Quad::Quad(operation_code op,char* result_) : op_code(op)
{
	result = strdup(result_);
}

//This function updates the result member of the quad.
void Quad::update(char* result_)
{
	result = strdup(result_);
}

//Creates a new quad for binary/unary operators.
void emit(char *result,char* arg1,operation_code op,char* arg2)
{
	Quad_array[nextinstr] = new Quad(op,result,arg1,arg2);
	nextinstr++;
}

//Creates a new quad for unary operators.
void emit(char *result,char* arg1,operation_code op)
{
	Quad_array[nextinstr] = new Quad(op,result,arg1);
	nextinstr++;
}

//Creates a new quad for assignment operation.
void emit(char* result,char* arg1)
{
	Quad_array[nextinstr] = new Quad(_COPY,result,arg1);
	nextinstr++;
}

//Creates a new quad for assignment to integer operation.
void emit(char* result,int int_num)
{
	Quad_array[nextinstr] = new Quad(_COPY,result,int_num);
	nextinstr++;
}

void emit(char* result,double double_num)
{
	Quad_array[nextinstr] = new Quad(_COPY,result,double_num);
	nextinstr++;
}

//Creates a new quad for assignment to floating number operation.
void emit(operation_code op,char* result)
{
	Quad_array[nextinstr] = new Quad(op,result);
	nextinstr++;
}

//prints a quad in suitable format.
void Quad::print()
{
	//Binary Operators.
	if(op_code <= _GREATER_EQUAL && op_code >= _ADD){
		printf("%s = %s ",result,arg1);
		
			if(op_code==_ADD)
		{
			cout<<'+';
		}
		else if(op_code==_SUBTRACT)
		{
			cout<<"-";
		}
		else if(op_code==_PRODUCT)
		{
			cout<<"*";
		}else if(op_code==_DIVIDE)
		{
			cout<<"/";
		}else if(op_code==_UNARY_AND)
		{
			cout<<"&";
		}else if(op_code==_MODULO)
		{
			cout<<"%%";
		}else if(op_code==_SHIFT_LEFT)
		{
			cout<<"<<";
		}else if(op_code==_SHIFT_RIGHT)
		{
			cout<<">>";
		}else if(op_code==_XOR)
		{
			cout<<"^";
		}else if(op_code==_UNARY_OR)
		{
			cout<<"|";
		}else if(op_code==_LOGICAL_AND)
		{
			cout<<"&&";
		}else if(op_code==_LOGICAL_OR)
		{
			cout<<"||";
		}else if(op_code==_LESS )
		{
			cout<<"<";
		}else if(op_code==_GREATER)
		{
			cout<<">";
		}else if(op_code==_IS_EQUAL)
		{
			cout<<"==";
		}else if(op_code==_NOT_EQUAL)
		{
			cout<<"!=";
		}else if(op_code==_LESS_EQUAL)
		{
			cout<<"<=";
		}
		else if(op_code==_GREATER_EQUAL)
		{
			cout<<">=";
		}
		printf(" %s\n",arg2);
	} 
	//Unary Operator.
	else if(op_code <= _NOT && op_code >= _UNARY_SUBTRACT){
		printf("%s = ",result);
		if(op_code==_UNARY_SUBTRACT)
		{
			cout<<'-';
		}
		else if(op_code==_UNARY_ADD)
		{
			cout<<"+";
		}
		else if(op_code==_COMPLEMENT)
		{
			cout<<"~";
		}else if(op_code==_NOT)
		{
			cout<<"!";
		}
		printf("%s\n",arg1);
	}
	//Conditional jump operators.
	else if(op_code >= _CONDITIONAL_LESS && op_code <= _CONDITIONAL_NOT_EQUAL){
		printf("if %s ",arg1);
		if(op_code==_CONDITIONAL_LESS )
		{
			cout<<'<';
		}
		else if(op_code==_CONDITIONAL_GREATER)
		{
			cout<<">";
		}
		else if(op_code==_CONDITIONAL_LESS_EQUAL)
		{
			cout<<"<=";
		}else if(op_code==_CONDITIONAL_GREATER_EQUAL)
		{
			cout<<">=";
		}else if(op_code==_CONDITIONAL_IS_EQUAL)
		{
			cout<<"==";
		}else if(op_code==_CONDITIONAL_NOT_EQUAL)
		{
			cout<<"!=";
		}
		printf(" %s goto %s\n",arg2,result);
	}
	else if(op_code == _CONDITIONAL_EXPRESSION){
		printf("if %s goto %s\n",arg1,result);
	}
	else if(op_code == _CONDITIONAL_NOT_EXPRESSION){
		printf("ifFalse %s goto %s\n",arg1,result);
	}
	//Unconditional jump.
	else if (op_code == _GOTO){
		printf("goto %s\n",result);
	}
	//Array Access.
	else if(op_code == _ARRAY_ACCESS){
		printf("%s[%s] = %s\n",result,arg1,arg2);
	}
	//Array dereferencing.
	else if(op_code == _ARRAY_DEREFERENCE){
		printf("%s = %s[%s]\n",result,arg1,arg2);
	}
	//assignment operator.
	else if(op_code == _COPY){
		printf("%s = %s\n",result,arg1);
	}
	//Procedure Call.
	else if(op_code == _PARAM){
		printf("param %s\n",result);
	}
	else if(op_code == _CALL){
		printf("%s = call %s, %s\n",result,arg1,arg2);
	}
	//Return Value
	else if(op_code == _RETURN_VOID){
		printf("return \n");
	}
	else if(op_code == _RETURN){
		printf("return %s\n",result);
	}
	//Address and Pointer Assignment Instructions.
	else if(op_code == _REFERENCE){
		printf("%s = &%s\n",result,arg1);
	}
	else if(op_code == _DEREFERENCE){
		printf("%s = *%s\n",result,arg1);
	}
	else if(op_code == _POINTER_ASSIGNMENT){
		printf("*%s = %s\n",result,arg1);
	}
	//Type Conversions.
	else if(op_code == _INT_TO_DOUBLE){
		printf("%s = int_to_double(%s)\n",result,arg1);
	}
	else if(op_code == _CHAR_TO_INT){
		printf("%s = char_to_int(%s)\n",result,arg1);
	}
	else if(op_code == _DOUBLE_TO_INT){
		printf("%s = double_to_int(%s)\n",result,arg1);
	}
	else if(op_code == _INT_TO_CHAR){
		printf("%s = int_to_char(%s)\n",result,arg1);
	}
	else if(op_code == _FUNCTION_BEGIN){
		printf("%s : \n",result);
	}
	else if(op_code == _FUNCTION_END){
		printf("end %s\n",result);
	}
	else if(op_code == _INCREMENT){
		printf(" %s=%s+1\n",result,result);	
	}
	else if(op_code == _DECREMENT){
		printf(" %s=%s-1\n",result,result);	
	}
}

//Constructor for class symboltable.
symboltable::symboltable() : offset(0)
{
	_constant_table_ = NULL;
}

//This function checks if the variable is present in symboltable or not, if it is present it returns the symboltable entry
//of its previous occurance else it creates a new entry with this variable name.
symb_table* symboltable::lookup(char *s)
{
	symb_table* sp;
	sp=this->_symboltable_;
	while(sp < &(this->_symboltable_[MAX_SIZE])){
		if(sp->_name_ && !strcmp(sp->_name_,s)){
			return sp;
		}
		if(!sp->_name_){
			sp->_name_ = strdup(s);
			sp->_size_ = 0;
			sp->_type_ = NULL;
			sp->_nested_table_ = NULL;
			sp->_offset_ = 0;
			this->number_of_entries++;
			return sp;
		}
		sp++;
	}
	char str[] = "Overflow ofsymbols!!\n";
	yyerror(str);
	exit(1);
}
symb_table* symboltable::lookup_check(char *s)
{
	symb_table* sp;
	for(sp = this->_symboltable_;sp < &(this->_symboltable_[MAX_SIZE]);sp++){
		if(sp->_name_ && !strcmp(sp->_name_,s)){
			return sp;
		}
		return NULL;
		
	}
	
}

//This function checks if the variable is present in symboltable or not, if it is present it gives a redeclaration error
//else it creates a new entry with this variable name.
symb_table* symboltable::lookup_2(char* s)
{
	symb_table* sp;
	for(sp = this->_symboltable_;sp < &(this->_symboltable_[MAX_SIZE]);sp++){
		if(sp->_name_ && !strcmp(sp->_name_,s)){
			char s[] = "Redeclaration of variable at line ";
			char temporary_string[50];
            sprintf(temporary_string,"%d",line_num);
            strcat(s,temporary_string);
            yyerror(s);
			exit(1);
		}
		if(!sp->_name_){
			sp->_name_ = strdup(s);
			sp->_offset_ = 0;
			sp->_size_ = 0;
			sp->_type_ = NULL;
			sp->_nested_table_ = NULL;
			
			sp->_offset_ = 0;
			this->number_of_entries++;
			return sp;
		}
	}
	char str[] = "Overflow ofsymbols!!\n";
	yyerror(str);
	exit(1);	
}

//It creates a temporary variable and calls function lookup on that temporary variable name.
symb_table* symboltable::gentemp()
{
	static int count = 0;
	char str[10];
	sprintf(str,"t%05d",count++);
	return lookup(str);
}

//Generates a constant label for each new string literal.

//This function backpatches/updates the dangling gotos in the indices of the quad present in the list p with value i.
void backpatch(_list *p,int i)
{
	_list* temp = p;
	char s[50];
	for(;temp != NULL;){
		sprintf(s,"%d",i);
		Quad_array[temp->_index_]->update(s);
		temp = temp->_next_;
	}
}

//This function checks type between primitive datatypes and performs implicit up-conversions or promotions.
//Valid promotions are char to int,int to double,char to double.
void typecheck(e_attr* E1,e_attr* E2)
{
	if(E1->_type_ == NULL || E2->_type_ == NULL){
		char str[] = "Variable has not been declared at line ";
		char temporary_string[50];
        sprintf(temporary_string,"%d",line_num);
        strcat(str,temporary_string);
        yyerror(str);
		exit(1);
	}
	_type *p,*q;
	p = E1->_type_;
	q = E2->_type_;
	if(!strcmp(p->variable_data_type,"array") || !strcmp(q->variable_data_type,"array")){
		char str[] = "Invalid operation at line ";
		char temporary_string[50];
        sprintf(temporary_string,"%d",line_num);
        strcat(str,temporary_string);
        yyerror(str);
		exit(1);
	}
	if(p->_next_ == NULL && q->_next_ == NULL){
		if(!strcmp(p->variable_data_type,q->variable_data_type)){
			return;
		}
		else if(!strcmp(p->variable_data_type,"int")){
			if(!strcmp(q->variable_data_type,"double")){
				convert_int_to_double(E1);
				return;
			}
			else if(!strcmp(q->variable_data_type,"char")){
				convert_char_to_int(E2);
				return;
			}
		}
		else if(!strcmp(p->variable_data_type,"char")){
			if(!strcmp(q->variable_data_type,"int")){
				convert_char_to_int(E1);
				return;
			}
			else if(!strcmp(q->variable_data_type,"double")){		
				convert_char_to_int(E1);
				convert_int_to_double(E1);
				return;
			}
		}
		else if(!strcmp(p->variable_data_type,"double")){
			if(!strcmp(q->variable_data_type,"int")){	
				convert_int_to_double(E2);
				return;
			}
			else if(!strcmp(q->variable_data_type,"char")){
				convert_char_to_int(E2);
				convert_int_to_double(E2);
				return;
			}
		}
	}
}

//This function converts an integer expression into a double expression and updates the type and size/width of the expression.
//If the expression is an array, the case is handled seperately as for array, we have to dereference.
void convert_int_to_double(e_attr* E)
{
	if(E->is_array_id == 1){
		symb_table* temp = current_symb_table->gentemp();
        emit(temp->_name_,E->array->_name_,_ARRAY_DEREFERENCE,E->loc->_name_);
        E->loc = temp;
        E->is_array_id = 0;
	}
	symb_table* t = current_symb_table->gentemp();
	emit(t->_name_,E->loc->_name_,_INT_TO_DOUBLE);
	E->loc = t;
	E->_type_->variable_data_type = strdup("double");
	E->width = 8;
	current_symb_table->update(E->loc,E->_type_,8,current_symb_table->offset);
	current_symb_table->offset = current_symb_table->offset + 8;
}

//This function converts a character expression into an integer expression and updates the type and size/width of the expression.
//If the expression is an array, the case is handled seperately as for array, we have to dereference.
void convert_char_to_int(e_attr* E)
{
	if(E->is_array_id == 1){
		symb_table* temp = current_symb_table->gentemp();
        emit(temp->_name_,E->array->_name_,_ARRAY_DEREFERENCE,E->loc->_name_);
        E->loc = temp;
        E->is_array_id = 0;
	}
	symb_table* t = current_symb_table->gentemp();
	emit(t->_name_,E->loc->_name_,_CHAR_TO_INT);
	E->loc = t;
	E->width = 4;
	E->_type_->variable_data_type = strdup("int");
	current_symb_table->update(E->loc,E->_type_,4,current_symb_table->offset);
	current_symb_table->offset = current_symb_table->offset + 4;		
}

//This function converts a double expression into an integer expression and updates the type and size/width of the expression.
//If the expression is an array, the case is handled seperately as for array, we have to dereference.
void convert_double_to_int(e_attr* E)
{
	if(E->is_array_id == 1){
		symb_table* temp = current_symb_table->gentemp();
        emit(temp->_name_,E->array->_name_,_ARRAY_DEREFERENCE,E->loc->_name_);
        E->loc = temp;
        E->is_array_id = 0;
	}
	symb_table* t = current_symb_table->gentemp();
	emit(t->_name_,E->loc->_name_,_DOUBLE_TO_INT);
	E->loc = t;
	E->_type_->variable_data_type = strdup("int");
	E->width = 4;
	current_symb_table->update(E->loc,E->_type_,4,current_symb_table->offset);
	current_symb_table->offset = current_symb_table->offset + 4;
}

//This function converts an integer expression into a double expression and updates the type and size/width of the expression.
//If the expression is an array, the case is handled seperately as for array, we have to dereference.
void convert_int_to_char(e_attr* E)
{	
	if(E->is_array_id == 1){
		symb_table* temp = current_symb_table->gentemp();
        emit(temp->_name_,E->array->_name_,_ARRAY_DEREFERENCE,E->loc->_name_);
        E->loc = temp;
        E->is_array_id = 0;
	}
	symb_table* t = current_symb_table->gentemp();
	emit(t->_name_,E->loc->_name_,_INT_TO_CHAR);
	E->loc = t;
	E->width = 1;
	E->_type_->variable_data_type = strdup("char");
	current_symb_table->update(E->loc,E->_type_,1,current_symb_table->offset);
	current_symb_table->offset = current_symb_table->offset + 1;		
}

//This function converts a boolean expression into an integer expression by backpatching the truelists and the falselists
//and if boolean value is true, then new value is 1 else 0 (if it is false).
void convert_bool_to_int(e_attr* E)
{
	E->loc = current_symb_table->gentemp();
	E->_type_->variable_data_type = strdup("int");
	E->width = 4;
	current_symb_table->update(E->loc,E->_type_,4,current_symb_table->offset);
	current_symb_table->offset = current_symb_table->offset + 4;
	backpatch(E->truelist,nextinstr);
	E->truelist = NULL;
	emit(E->loc->_name_,1);
	char s[50];
	sprintf(s,"%d",nextinstr + 2);
	emit(_GOTO,s);
	backpatch(E->falselist,nextinstr);
	E->falselist = NULL;
	emit(E->loc->_name_,0);
}

//This function converts any expression to a boolean expression,
// if it is not equal to 0 then it is true else it is false.
void convert_exp_to_bool(e_attr* E)
{
	E->falselist = makelist(nextinstr);
	char str[] = "...";
	emit(str,E->loc->_name_,_CONDITIONAL_NOT_EXPRESSION);
	E->truelist = makelist(nextinstr);
	emit(_GOTO,str);
	E->_type_->variable_data_type = strdup("bool");
	E->_type_->_next_ = NULL;
}

//This function makes a paramter list with the symboltable entry of the parameter, type and size of the parameter of a function.
function_list* make_function_list(symb_table* sym_entry,_type* t,int width)
{
	function_list* new_list = new function_list;
	new_list->loc = sym_entry;
	_type *p,*q;
	p = new _type;
	new_list->_type_ = p;
	q = t;
	while(q->_next_ != NULL){
		p->variable_data_type = strdup(q->variable_data_type);
		p->size = q->size;
		p->_next_ = new _type;
		q = q->_next_;
		p = p->_next_;
	}
	p->variable_data_type = strdup(q->variable_data_type);
	p->size = q->size;
	p->_next_ = NULL;
	new_list->width = width;
	new_list->_next_ = NULL;
	return new_list;
}

//This function merges two parameter lists by concatenating p2 into function_list p1.
function_list* merge_function_list(function_list* p1,function_list* p2)
{
	if(p1 == NULL){
		return p2;
	}
	if(p2 == NULL){
		return p1;
	}
	function_list* p = p1;
	while(p->_next_ != NULL){
		p = p->_next_;
	}
	p->_next_ = p2;
	return p1;
}	
int main(int argc,char* argv[])
{

	
    //Parse the file to check for syntax errors.
	if(yyparse()){
		printf("Syntax error at line number %d\n",line_num);
		exit(1);
	}
    
    
   
    vector<pair<char *,symboltable *> > symbol_tables;
    vector<int> num_params_;
   
    symbol_tables.push_back(make_pair(strdup("Global"),Global_symb_table));
    num_params_.push_back(0);
    symb_table* sp;
	for(sp = Global_symb_table->_symboltable_;sp < &(Global_symb_table->_symboltable_[MAX_SIZE]);sp++){
		if(!sp->_name_){
			break;
		}
		if(sp->_nested_table_ == NULL){
		
		}
		else {
			symbol_tables.push_back(make_pair(sp->_name_,sp->_nested_table_));
			num_params_.push_back(sp->num_params);
		}
	}
	
	for(int i = 0;i < symbol_tables.size();i++){
		printf("\nSymbol Table of %s\n",symbol_tables[i].first);
		symbol_tables[i].second->print();
		
	}
	//Print the Quads.
	cout<<"\n\n++++++++++++\n\nQuads:\n+++++++++++\n\n";
	for(int i = 1;i < nextinstr;i++){
		cout<<(i)<<" :  ";
        Quad_array[i]->print();
    }
  
    //Assign the goto labels after generating new labels for each quad 
    //which is pointed to by a goto.
    for(int i = 1;i < nextinstr;i++){
		if(Quad_array[i]->op_code >= _CONDITIONAL_LESS && Quad_array[i]->op_code <= _GOTO){
			char* s = strdup(Quad_array[i]->result);
			int line_number = atoi(s);
			line_number = find_goto_label(line_number);
			if(line_number != -1){
				Quad_array[i]->result = strdup(goto_labels[line_number].second);	
			}
			else {
				char* str = strdup(gengotolabel());
				goto_labels.push_back(make_pair(atoi(s),str));
				Quad_array[i]->result = strdup(str);
			}
		}
	}	
	current_symb_table = Global_symb_table;
	
	return 0;
}