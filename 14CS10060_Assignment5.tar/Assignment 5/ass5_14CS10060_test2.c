//checking pointers and type conversion and global variables
void main()
{
  double d; 
  int a,b;
  int *c;
  c=&b;
  d=a+*c;
  double *e;
  e=&d;
  a=*e * *c;
  return;
}