Assignment 5

Name:Ashrujit Ghoshal
Roll No-14CS10060

ass5_14CS10060.l ,ass5_14CS10060.y are the relevant .l ,.y files
ass5_14CS10060_translator.h,ass5_14CS10060_translator.cxx are relevant translator files.


ass5_14CS10060_test1.c,
ass5_14CS10060_test2.c,
ass5_14CS10060_test3.c,
ass5_14CS10060_test4.c,
ass5_14CS10060_test5.c
are the 5 test files and the symbol tables and quads generated are stored in:

ass5_14CS10060_quads1.out,
ass5_14CS10060_quads2.out,
ass5_14CS10060_quads3.out,
ass5_14CS10060_quads4.out,
ass5_14CS10060_quads5.out



Type :
make to compile.
make clean to remove.
make test  to test all 5 test files



Note:
Grammar Augumentations and shortcomings have been included in a pdf
Rest explanations are in the code as comments.