//Program to calculate nth term of fibonacci series recursively
int recursive_fibonacci(int n);
 
int main() {
 
   int num,i;
    num = 6;
    i=recursive_fibonacci(num);
    
  return 0;

}
 
int recursive_fibonacci(int n) {
    if(n < 2) return 1;
    else return recursive_fibonacci(n-1)+recursive_fibonacci(n-2);

}
