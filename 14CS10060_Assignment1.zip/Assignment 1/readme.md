Assignment 1
Name:Ashrujit Ghoshal
Roll Number:14CS10060


The C file:ass1_14CS10060.c
The assembly code:ass1_14CS10060.s