/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    SINGLE_LINE_COMMENT = 258,
    MULTI_LINE_COMMENT = 259,
    KEYWORD_AUTO = 260,
    KEYWORD_ENUM = 261,
    KEYWORD_RESTRICT = 262,
    KEYWORD_UNSIGNED = 263,
    KEYWORD_BREAK = 264,
    KEYWORD_EXTERN = 265,
    KEYWORD_RETURN = 266,
    KEYWORD_VOID = 267,
    KEYWORD_CASE = 268,
    KEYWORD_FLOAT = 269,
    KEYWORD_SHORT = 270,
    KEYWORD_VOLATILE = 271,
    KEYWORD_CHAR = 272,
    KEYWORD_FOR = 273,
    KEYWORD_SIGNED = 274,
    KEYWORD_WHILE = 275,
    KEYWORD_CONST = 276,
    KEYWORD_GOTO = 277,
    KEYWORD_SIZEOF = 278,
    KEYWORD_BOOL = 279,
    KEYWORD_CONTINUE = 280,
    KEYWORD_IF = 281,
    KEYWORD_STATIC = 282,
    KEYWORD_COMPLEX = 283,
    KEYWORD_DEFAULT = 284,
    KEYWORD_INLINE = 285,
    KEYWORD_STRUCT = 286,
    KEYWORD_IMAGINARY = 287,
    KEYWORD_DO = 288,
    KEYWORD_INT = 289,
    KEYWORD_SWITCH = 290,
    KEYWORD_DOUBLE = 291,
    KEYWORD_LONG = 292,
    KEYWORD_TYPEDEF = 293,
    KEYWORD_ELSE = 294,
    KEYWORD_REGISTER = 295,
    KEYWORD_UNION = 296,
    IDENTIFIER = 297,
    INTEGER_CONSTANT = 298,
    FLOAT_CONSTANT = 299,
    ENUMERATOR = 300,
    CHAR_CONSTANT = 301,
    STRING_LITERAL = 302,
    OPENING_SQUARE_SQUARE_BRACKET = 303,
    CLOSING_SQUARE_BRACKET = 304,
    OPENING_PARENTHESIS = 305,
    CLOSING_PARENTHESIS = 306,
    OPENING_BRACE = 307,
    CLOSING_BRACE = 308,
    DOT = 309,
    AMPERSAND = 310,
    STAR = 311,
    PLUS = 312,
    MINUS = 313,
    BITWISE_NOT = 314,
    LOGICAL_NOT = 315,
    DIVIDE = 316,
    MODULO = 317,
    LESSER_THAN = 318,
    GREATER_THAN = 319,
    BITWISE_XOR = 320,
    BITWISE_OR = 321,
    QUESTION_MARK = 322,
    COLON = 323,
    SEMI_COLON = 324,
    ASSIGN = 325,
    COMMA = 326,
    HASH = 327,
    LEFT_SHIFT_ASSIGN = 328,
    ELLIPSES = 329,
    RIGHT_SHIFT_ASSIGN = 330,
    VALUE_AT = 331,
    INCREMENT = 332,
    DECREMENT = 333,
    LEFT_SHIFT = 334,
    RIGHT_SHIFT = 335,
    LESS_OR_EQUAL = 336,
    GREATER_OR_EQUAL = 337,
    EQUALITY_CHECK = 338,
    NOT_EQUAL = 339,
    LOGICAL_AND = 340,
    LOGICAL_OR = 341,
    MULTIPLY_ASSIGN = 342,
    DIVIDE_ASSIGN = 343,
    MODULO_ASSIGN = 344,
    ADD_ASSIGN = 345,
    SUBTACT_ASSIGN = 346,
    AND_ASSIGN = 347,
    XOR_ASSIGN = 348,
    OR_ASSIGN = 349
  };
#endif
/* Tokens.  */
#define SINGLE_LINE_COMMENT 258
#define MULTI_LINE_COMMENT 259
#define KEYWORD_AUTO 260
#define KEYWORD_ENUM 261
#define KEYWORD_RESTRICT 262
#define KEYWORD_UNSIGNED 263
#define KEYWORD_BREAK 264
#define KEYWORD_EXTERN 265
#define KEYWORD_RETURN 266
#define KEYWORD_VOID 267
#define KEYWORD_CASE 268
#define KEYWORD_FLOAT 269
#define KEYWORD_SHORT 270
#define KEYWORD_VOLATILE 271
#define KEYWORD_CHAR 272
#define KEYWORD_FOR 273
#define KEYWORD_SIGNED 274
#define KEYWORD_WHILE 275
#define KEYWORD_CONST 276
#define KEYWORD_GOTO 277
#define KEYWORD_SIZEOF 278
#define KEYWORD_BOOL 279
#define KEYWORD_CONTINUE 280
#define KEYWORD_IF 281
#define KEYWORD_STATIC 282
#define KEYWORD_COMPLEX 283
#define KEYWORD_DEFAULT 284
#define KEYWORD_INLINE 285
#define KEYWORD_STRUCT 286
#define KEYWORD_IMAGINARY 287
#define KEYWORD_DO 288
#define KEYWORD_INT 289
#define KEYWORD_SWITCH 290
#define KEYWORD_DOUBLE 291
#define KEYWORD_LONG 292
#define KEYWORD_TYPEDEF 293
#define KEYWORD_ELSE 294
#define KEYWORD_REGISTER 295
#define KEYWORD_UNION 296
#define IDENTIFIER 297
#define INTEGER_CONSTANT 298
#define FLOAT_CONSTANT 299
#define ENUMERATOR 300
#define CHAR_CONSTANT 301
#define STRING_LITERAL 302
#define OPENING_SQUARE_SQUARE_BRACKET 303
#define CLOSING_SQUARE_BRACKET 304
#define OPENING_PARENTHESIS 305
#define CLOSING_PARENTHESIS 306
#define OPENING_BRACE 307
#define CLOSING_BRACE 308
#define DOT 309
#define AMPERSAND 310
#define STAR 311
#define PLUS 312
#define MINUS 313
#define BITWISE_NOT 314
#define LOGICAL_NOT 315
#define DIVIDE 316
#define MODULO 317
#define LESSER_THAN 318
#define GREATER_THAN 319
#define BITWISE_XOR 320
#define BITWISE_OR 321
#define QUESTION_MARK 322
#define COLON 323
#define SEMI_COLON 324
#define ASSIGN 325
#define COMMA 326
#define HASH 327
#define LEFT_SHIFT_ASSIGN 328
#define ELLIPSES 329
#define RIGHT_SHIFT_ASSIGN 330
#define VALUE_AT 331
#define INCREMENT 332
#define DECREMENT 333
#define LEFT_SHIFT 334
#define RIGHT_SHIFT 335
#define LESS_OR_EQUAL 336
#define GREATER_OR_EQUAL 337
#define EQUALITY_CHECK 338
#define NOT_EQUAL 339
#define LOGICAL_AND 340
#define LOGICAL_OR 341
#define MULTIPLY_ASSIGN 342
#define DIVIDE_ASSIGN 343
#define MODULO_ASSIGN 344
#define ADD_ASSIGN 345
#define SUBTACT_ASSIGN 346
#define AND_ASSIGN 347
#define XOR_ASSIGN 348
#define OR_ASSIGN 349

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 11 "ass3_14CS10060.y" /* yacc.c:1909  */

  int intval;
  float floatval;
  char *charval;

#line 248 "y.tab.h" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
