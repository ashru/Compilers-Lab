#include <stdio.h>
#include "y.tab.h"
extern char* yytext;
int main() {
  int token;
  while (token = yylex()) {
    switch (token) {
      // Identifiers
      case IDENTIFIER: printf("<IDENTIFIER, %d, %s    >\n",token, yytext); break;
      // Constants
      case INTEGER_CONSTANT: printf("<INTEGER CONSTANT, %d, %s    >\n", token, yytext); break;
      case FLOAT_CONSTANT: printf("<FLOATING CONSTANT, %d, %s    >\n",token, yytext); break;
      case ENUMERATOR: printf("<ENUMERATION CONSTANT, %d, %s    >\n",token, yytext); break;
      case CHAR_CONSTANT: printf("<CHARACTER CONSTANT, %d, %s    >\n",token, yytext); break;
      case STRING_LITERAL: printf("<STRING LITERAL, %d, %s    >\n",token, yytext); break;
     
      // Comments 
     /* Multi line 
     comments are ignored*/
      case SINGLE_LINE_COMMENT: 
        printf("<SINGLE LINE COMMENT, %d , %s    > \n",token,yytext); break;
      case MULTI_LINE_COMMENT: 
        printf("<MULTI LINE COMMENT, %d , %s    > \n",token,yytext); break;
      // Keyword
      case KEYWORD_BREAK:
      case KEYWORD_AUTO:
      case KEYWORD_CASE:
      case KEYWORD_CHAR:
      case KEYWORD_CONST:
      case KEYWORD_CONTINUE:
      case KEYWORD_DEFAULT:
      case KEYWORD_DO:
      case KEYWORD_DOUBLE:
      case KEYWORD_ELSE:
      case KEYWORD_ENUM:
      case KEYWORD_EXTERN:
      case KEYWORD_FLOAT:
      case KEYWORD_FOR:
      case KEYWORD_GOTO:
      case KEYWORD_IF:
      case KEYWORD_INLINE:
      case KEYWORD_INT:
      case KEYWORD_LONG:
      case KEYWORD_REGISTER:
      case KEYWORD_RESTRICT:
      case KEYWORD_RETURN:
      case KEYWORD_SHORT:
      case KEYWORD_SIGNED:
      case KEYWORD_SIZEOF:
      case KEYWORD_STATIC:
      case KEYWORD_STRUCT:
      case KEYWORD_SWITCH:
      case KEYWORD_TYPEDEF:
      case KEYWORD_UNION:
      case KEYWORD_UNSIGNED:
      case KEYWORD_VOID:
      case KEYWORD_VOLATILE:
      case KEYWORD_WHILE:
      case KEYWORD_BOOL:
      case KEYWORD_COMPLEX:
      case KEYWORD_IMAGINARY:

      printf("<KEYWORD   %d, %s    >\n",token, yytext); break;
    // Punctuators
      default: printf("<PUNCTUATOR, %d, %s    >\n",
        token, yytext); break;
    }
  }
}