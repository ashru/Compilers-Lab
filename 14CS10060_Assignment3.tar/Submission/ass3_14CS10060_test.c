#include<complex.h>
inline void test()/*multiple line
                       comment  tested*/
{
	double _Complex a = 3.0 + 0.0I; 
	double _Imaginary z = 3*I;
}
typedef enum {RANDOM, IMMEDIATE, SEARCH} strategy;
strategy my_strategy = IMMEDIATE;
typedef union set{    //Union
	char type_string[200];
	short type_short;
  signed int type_int;
  long long type_long_long;
  long type_long;
  float type_float;
  double type_double;
  char type_char; 
}Set;
typedef struct node   /* Structure */
{ 
static unsigned int num_q = 0;//static variable storing the number of queries  
  auto Set data;
  
}node;
extern int test2(int,...);

int main(void){ 
  const int no = 8;    
  register signed int type_int = 250;
   short type_short = type_int - 780;
  float type_float = 1.2365;
  double type_double = -2.5625E-2;
  long type_long = type_short + 410;
  long long type_long_long=-250000;
  node total[2*no];
  char type_char = 'S';
  restrict char type_string = "Ashrujit";
  char test3='\n';
  char test4[]="Hello\t\n";
 
  volatile int v1 = 1,new;

  Zero:
  _Bool value = type_int==0? true:false;
  int size = sizeof(total);
  if(size&1){
    size^=1;
    size&=1;
    size|=1;
  }
  else{
    ~size;
    size = size ^ 1;
    size = size | 1;
    goto Zero;
  }
  type_int /= type_short;
      type_short %= 100;
      type_long = (type_long/type_int)%1000;
      type_int += 110;
      type_int *= 130;
      type_int = type_int<<type_short;
      type_int = type_int>>type_short;
      type_int<<=4;
      type_int>>=1;
      type_int -= 200;
   do{
    for(int i = no;i>=1;--i){
      switch(i){
      	case 8:(total+i-1)->type_long_long=type_long_long;
      	break;
        
        default : break;
      }
    }
    if(type_long_long == 0 || type_short < 0 || type_long <= 0 || (type_int>type_long)&&(!type_short))
      continue;
    else{
      
    } 
  }while((++(total[0].num_q))!=2);
  return 0;
}
